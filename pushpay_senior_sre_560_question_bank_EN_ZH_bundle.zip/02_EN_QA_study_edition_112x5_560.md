# Pushpay Senior SRE — 112 Topics × 5 Q&A Study Edition

> **560 short-answer interview questions with answers**

This edition is designed for systematic study and spoken interview practice. Each of the 112 topics contains exactly five questions:

1. **`.1` — Foundation**
2. **`.2` — Internals / Mechanism**
3. **`.3` — Production Scenario**
4. **`.4` — Troubleshooting / Failure**
5. **`.5` — Senior Trade-off / Edge Case**

The target progression is:

```text
Definition → Internals → Production → Failure Diagnosis → Senior Trade-off
```

Use the answers as **reference answers**, not scripts to memorize word-for-word. In a real interview, answer the question first, then explain your reasoning, evidence, and trade-offs.

---

# 01 — Git Internals

## Q1 — .git directory

### Q1.1 — Foundation

**Question:** Describe what is inside the `.git` directory and what the major files/directories are for.

**Answer:**

`.git` stores repository metadata. Key parts are `HEAD` (current ref), `config`, `index` (staging area), `objects/` (content-addressed Git objects), `refs/` (branch/tag pointers), `logs/` (reflogs), `hooks/`, and sometimes `packed-refs`.

### Q1.2 — Internals / Mechanism

**Question:** Explain how `HEAD`, `refs`, `index`, `objects`, `logs`, and `packed-refs` relate to one another.

**Answer:**

`HEAD` usually points symbolically to a branch ref; that ref points to a commit. The commit points to a tree, trees point to blobs/subtrees, while the index represents the staged snapshot between the working tree and `HEAD`. Reflogs record ref movements.

### Q1.3 — Production Scenario

**Question:** A developer says their working tree looks correct but Git reports unexpected staged changes. Which `.git` structures would you inspect and why?

**Answer:**

Inspect the index and compare `git diff`, `git diff --cached`, and `git status`. If the working tree is correct but staged state is wrong, the index is the likely source. Avoid deleting `.git/index` blindly until changes are understood.

### Q1.4 — Troubleshooting / Failure

**Question:** After a bad operation, branch pointers look wrong and several commits appear missing. Walk through a recovery investigation using Git internals.

**Answer:**

First preserve the repository. Inspect `git reflog`, branch refs, `HEAD`, and `git fsck --lost-found`. Compare with remotes and other clones. Restore refs only after identifying the intended commit graph, then verify history before pushing.

### Q1.5 — Senior Trade-off / Edge Case

**Question:** If reflogs are incomplete and garbage collection may have run, what recovery options remain, what evidence would you preserve first, and what are the limits?

**Answer:**

Recovery becomes harder once reflogs expire and unreachable objects are pruned by GC. Preserve clones and object directories immediately. Search dangling objects and other clones/backups. The hard limit is simple: once an object is physically deleted everywhere, Git cannot reconstruct it.

---

## Q2 — Git commit / tree / blob objects

### Q2.1 — Foundation

**Question:** What is a Git commit object?

**Answer:**

A commit object records metadata such as parent commit(s), author/committer, message, and the root tree hash. It does not embed a full mutable copy of the repository; it references an immutable snapshot through tree and blob objects.

### Q2.2 — Internals / Mechanism

**Question:** Explain how commit, tree, blob, and annotated tag objects are linked and content-addressed.

**Answer:**

Blobs store file contents, trees map names to blobs/subtrees, commits point to a root tree and parent commit(s), and annotated tags can point to other objects. Object IDs are hashes of object type, length, and content.

### Q2.3 — Production Scenario

**Question:** Two repositories contain identical file contents but different commit histories. Which objects can be shared conceptually and which will differ?

**Answer:**

Identical file contents can produce identical blob objects. Commit objects will differ if metadata, parent links, or root trees differ. Trees can also be shared where directory contents are identical.

### Q2.4 — Troubleshooting / Failure

**Question:** A repository appears corrupted. How would you use object structure and `git fsck` output to narrow the damage?

**Answer:**

Run `git fsck` and inspect which object type/hash is missing or corrupt. If a blob is missing, affected trees/commits may still exist but cannot materialize fully. Recover objects from a healthy remote, clone, backup, or packfile where possible.

### Q2.5 — Senior Trade-off / Edge Case

**Question:** What trade-offs does content-addressed immutable storage give Git, and where do hash collisions, packfiles, and GC complicate the model?

**Answer:**

Immutability and content addressing make deduplication, integrity checking, and cheap branching possible. Packfiles compress storage but complicate manual inspection. SHA collision risk is mitigated by modern Git protections, while GC can permanently remove unreachable objects.

---

## Q3 — `git add` and the index

### Q3.1 — Foundation

**Question:** What happens when you run `git add`?

**Answer:**

`git add` updates the index to represent the content you want in the next commit. Git hashes file contents into blob objects as needed and records paths, modes, and blob IDs in the index.

### Q3.2 — Internals / Mechanism

**Question:** What exactly is the Git index, and how does it differ from both the working tree and `HEAD`?

**Answer:**

The working tree is what is on disk, the index is the staged snapshot, and `HEAD` is the current committed snapshot. A commit is created from the index, not directly from arbitrary working-tree contents.

### Q3.3 — Production Scenario

**Question:** A file has partially staged changes. Explain how Git can represent that state.

**Answer:**

Partial staging works because the index can contain a blob representing only selected hunks, while the working-tree file can contain additional unstaged changes. Therefore one path can differ across `HEAD`, index, and working tree.

### Q3.4 — Troubleshooting / Failure

**Question:** A developer staged the wrong changes in a large incident-response patch. How would you safely inspect and correct the index without losing working-tree changes?

**Answer:**

Use `git diff --cached` to inspect staged content and `git diff` for unstaged content. Correct staging with `git restore --staged`, `git reset <path>`, or interactive staging, while preserving the working tree. Verify before committing.

### Q3.5 — Senior Trade-off / Edge Case

**Question:** Why is the index a powerful design choice, and what failure modes can occur when scripts manipulate it concurrently or incorrectly?

**Answer:**

The index is powerful because it enables precise commits and merge state, but scripts that mutate it carelessly can stage unintended data or race with other operations. CI should use isolated workspaces and avoid concurrent Git writers in one checkout.

---

## Q4 — Branches and refs

### Q4.1 — Foundation

**Question:** What exactly is a Git branch?

**Answer:**

A branch is fundamentally a named ref that points to a commit. It is not a container that physically stores commits; commits are reachable through the graph from that ref.

### Q4.2 — Internals / Mechanism

**Question:** Explain how branch refs move during commits, merges, resets, and fast-forwards.

**Answer:**

A normal commit advances the current branch ref. A fast-forward moves a ref to a descendant. A merge may create a new commit with multiple parents. Reset moves a ref directly. Rebase creates new commits and then moves the branch to them.

### Q4.3 — Production Scenario

**Question:** Two engineers disagree about whether a branch 'contains' commits. Explain the more precise model using reachability.

**Answer:**

Say that a commit is 'on' a branch when it is reachable from that branch tip. The same commit can be reachable from multiple branches, so branch membership is graph reachability, not exclusive ownership.

### Q4.4 — Troubleshooting / Failure

**Question:** A release branch was force-pushed and now points to the wrong commit. How would you determine the previous tip and restore it safely?

**Answer:**

Use local/remote reflogs, server audit data, other clones, and `git fsck` to locate the former tip. Create a temporary recovery branch first, validate it, coordinate with collaborators, then restore or force-push with lease if necessary.

### Q4.5 — Senior Trade-off / Edge Case

**Question:** When are force-pushes acceptable, and what controls would you use in a production engineering workflow to reduce ref-loss risk?

**Answer:**

Force-push is acceptable mainly on private or explicitly rewriteable branches. Protect shared/release branches, require reviews, use `--force-with-lease`, keep server-side reflogs/backups, and make destructive history changes auditable.

---

## Q5 — HEAD and detached HEAD

### Q5.1 — Foundation

**Question:** What is `HEAD` in Git?

**Answer:**

`HEAD` identifies the currently checked-out commit, usually indirectly through a symbolic reference such as `refs/heads/main`. In detached HEAD, `HEAD` points directly to a commit instead of a branch ref.

### Q5.2 — Internals / Mechanism

**Question:** Explain symbolic `HEAD` versus detached `HEAD` and what happens when you commit in each state.

**Answer:**

On a normal branch, a new commit advances that branch. In detached HEAD, the new commit exists but no branch automatically moves to it, so it can become unreachable after checkout unless you create a ref.

### Q5.3 — Production Scenario

**Question:** A CI job checks out a commit SHA directly and creates a commit during the build. Where does that commit live?

**Answer:**

CI often checks out an exact commit SHA for reproducibility, which creates detached HEAD. A commit produced there exists in the object database of that checkout but is not safely retained unless pushed or referenced.

### Q5.4 — Troubleshooting / Failure

**Question:** Someone created valuable work in detached HEAD and then switched branches. How do you recover it?

**Answer:**

Use `git reflog` to find the detached commit, then create a branch or tag pointing to it: for example `git branch recovery <sha>`. Verify the work before switching or pushing.

### Q5.5 — Senior Trade-off / Edge Case

**Question:** Why do CI/CD systems often use detached HEAD deliberately, and what workflow risks does that introduce for humans?

**Answer:**

Detached HEAD is useful in CI because builds target immutable commits. For humans it increases the risk of losing unreferenced work, so tooling and workflow should make branch creation/recovery obvious.

---

## Q6 — Merge vs rebase

### Q6.1 — Foundation

**Question:** What is the difference between merge and rebase?

**Answer:**

Merge combines histories by moving a ref via fast-forward or creating a merge commit. Rebase rewrites a sequence by replaying changes onto a new base, producing new commit IDs.

### Q6.2 — Internals / Mechanism

**Question:** Explain the object-graph changes caused by merge versus rebase.

**Answer:**

Merge preserves the original commit graph and parentage. Rebase copies the logical changes into new commit objects with new parents, so hashes change even if file content ends up similar.

### Q6.3 — Production Scenario

**Question:** A long-running feature branch has diverged heavily from main. How would you choose between merge, rebase, or rebuilding the branch?

**Answer:**

For a heavily diverged branch, choose based on collaboration and audit needs. Rebase can simplify private history; merge is safer when history is shared. Sometimes a fresh branch with selectively cherry-picked changes is lower risk.

### Q6.4 — Troubleshooting / Failure

**Question:** A rebase was performed on a shared branch and collaborators now have duplicated-looking commits. How do you untangle the situation?

**Answer:**

Duplicated-looking commits after rebasing a shared branch happen because old and rewritten commits both exist. Coordinate, identify the canonical line, reset/rebase collaborators carefully, and avoid blind merges that preserve both duplicate histories.

### Q6.5 — Senior Trade-off / Edge Case

**Question:** What are the maintainability, auditability, and incident-forensics trade-offs between linear history and preserved merge history?

**Answer:**

Linear history improves readability and bisecting, while merge history preserves integration context and forensic truth. In incident-heavy environments, preserving meaningful merge boundaries can be more valuable than aesthetic linearity.

---

## Q7 — Git repository corruption

### Q7.1 — Foundation

**Question:** What does it mean for a Git repository to be corrupted?

**Answer:**

Repository corruption means Git metadata or object data no longer satisfies expected integrity or reachability. Examples include damaged refs, malformed index files, missing objects, or corrupt packfiles.

### Q7.2 — Internals / Mechanism

**Question:** Which internal structures can be damaged, and how would corruption of refs differ from corruption of objects?

**Answer:**

Ref corruption can point branches at wrong/nonexistent commits while objects remain intact. Object corruption means the actual content/history object is missing or invalid, which is more serious. Pack/index corruption may affect access without all underlying data being lost.

### Q7.3 — Production Scenario

**Question:** A build agent reports intermittent Git object errors while other clones are healthy. How would you separate local disk issues from remote-repository issues?

**Answer:**

If only one build agent fails, suspect local disk/filesystem/cache corruption first. Compare object IDs with a clean clone, run `git fsck`, inspect storage errors, and test fresh clones from the same remote.

### Q7.4 — Troubleshooting / Failure

**Question:** Walk through a safe corruption investigation using backups, remotes, `git fsck`, reflogs, and object inspection.

**Answer:**

Preserve evidence, stop automated cleanup, compare with remotes/backups, run `git fsck`, inspect reflogs, and recover missing objects from healthy clones or packfiles. Repair refs only after object integrity is known.

### Q7.5 — Senior Trade-off / Edge Case

**Question:** In a regulated production environment, what evidence-preservation and recovery practices would you establish before attempting repair?

**Answer:**

In regulated environments, make a forensic copy first, record commands and hashes, restrict destructive repair, and restore from known-good immutable backups when possible. Recovery should preserve auditability, not just make Git commands work again.

---

## Q8 — Recovering lost commits

### Q8.1 — Foundation

**Question:** How can you recover commits after an accidental reset?

**Answer:**

After an accidental reset, the old commit is usually still present and discoverable through `git reflog`. Create a recovery branch/tag at the old SHA before making more changes.

### Q8.2 — Internals / Mechanism

**Question:** Explain how reflogs, unreachable objects, and reachability interact during recovery.

**Answer:**

Reflogs record movements of refs and `HEAD`. A commit can be unreachable from branches yet still exist as an object. Git GC may eventually prune unreachable objects after expiration policies.

### Q8.3 — Production Scenario

**Question:** A developer ran `reset --hard` and force-pushed. The remote branch no longer references three commits. What do you do?

**Answer:**

Check the reflog on the machine that had the branch before force-push, then inspect coworkers' clones and CI workspaces. Recover the commits under temporary refs, verify them, and only then update the shared branch.

### Q8.4 — Troubleshooting / Failure

**Question:** Assume the commits are not in any branch and the reflog is missing on the remote. How would you search for dangling commits locally or on other clones?

**Answer:**

If no ref or reflog remains, use `git fsck --dangling/--lost-found` and search other clones, build caches, patch files, and backups. The object graph can sometimes be reconstructed if the raw commit objects still exist.

### Q8.5 — Senior Trade-off / Edge Case

**Question:** How does garbage collection change the recovery window, and what repository policies reduce the probability of permanent loss?

**Answer:**

GC defines the practical recovery window for unreferenced objects. Protect important branches, retain reflogs/backups, prefer `--force-with-lease`, and make release refs immutable to reduce permanent history loss.

---

# 02 — Linux / Operating Systems

## Q9 — Process vs thread

### Q9.1 — Foundation

**Question:** Explain the difference between a process and a thread.

**Answer:**

A process is an isolated execution environment with its own virtual address space and resources. Threads are execution streams within a process and share much of that process state.

### Q9.2 — Internals / Mechanism

**Question:** Which resources are shared between threads, and which execution state is private?

**Answer:**

Threads share code, heap, open file descriptors, and many process resources, but each thread has its own registers, stack, scheduling state, and thread-local storage.

### Q9.3 — Production Scenario

**Question:** A multithreaded service is consuming high CPU but only one core is saturated. What mechanisms could explain that?

**Answer:**

One saturated core in a multithreaded service can indicate a single hot thread, lock contention, serialized work, affinity, GC/runtime behaviour, or a bottleneck that cannot parallelize.

### Q9.4 — Troubleshooting / Failure

**Question:** How would you determine whether contention, scheduling, or a single hot thread is the bottleneck?

**Answer:**

Inspect per-thread CPU with `top -H`, `pidstat -t`, runtime thread dumps, and profiling tools such as `perf`. Correlate with lock/wait data before assuming the scheduler is at fault.

### Q9.5 — Senior Trade-off / Edge Case

**Question:** When would you prefer multiple processes over multiple threads for reliability, isolation, and operational control?

**Answer:**

Processes give stronger fault/isolation boundaries and independent resource controls; threads are cheaper for communication and memory sharing. Choose based on isolation, workload parallelism, language runtime, and operational blast radius.

---

## Q10 — Linux process memory layout

### Q10.1 — Foundation

**Question:** Describe the typical memory layout of a Linux process.

**Answer:**

A typical process has executable text, initialized data, BSS, heap, thread stacks, shared libraries, and memory-mapped regions. The exact layout is controlled by the OS, loader, runtime, and ASLR.

### Q10.2 — Internals / Mechanism

**Question:** Explain text, data, BSS, heap, stacks, shared libraries, and memory-mapped regions.

**Answer:**

Text is executable code; data/BSS hold globals; heap supports dynamic allocation; stacks hold per-thread call frames; mmap regions back files, shared libraries, anonymous allocations, and shared memory.

### Q10.3 — Production Scenario

**Question:** A process RSS is high but heap usage is modest. What could account for the difference?

**Answer:**

High RSS with modest heap can come from native allocations, thread stacks, mmap, shared libraries, allocator fragmentation, direct buffers, or resident file-backed pages.

### Q10.4 — Troubleshooting / Failure

**Question:** How would you investigate anonymous mappings, shared mappings, page cache effects, and native allocations?

**Answer:**

Inspect `/proc/<pid>/smaps`, `pmap`, runtime/native-memory tools, cgroup counters, and allocation profiles. Separate anonymous/private memory from file-backed/shared mappings and from page cache counted at container level.

### Q10.5 — Senior Trade-off / Edge Case

**Question:** Which memory metrics are most misleading in containers, and how would you reason about real memory pressure at host and cgroup levels?

**Answer:**

RSS, working set, cache, and cgroup usage can tell different stories. In containers, always compare process memory with cgroup limits and host pressure; avoid treating a single runtime heap metric as total memory.

---

## Q11 — Load average

### Q11.1 — Foundation

**Question:** What does Linux load average measure?

**Answer:**

Linux load average is the average number of tasks that are runnable or in uninterruptible sleep, reported over roughly 1, 5, and 15 minutes. It is not CPU utilization.

### Q11.2 — Internals / Mechanism

**Question:** Why can load average be high even when CPU utilization is low?

**Answer:**

Load can be high with low CPU when many tasks are blocked in uninterruptible `D` state, often waiting on I/O. Short bursts of runnable work can also raise load even if sampled CPU looks modest.

### Q11.3 — Production Scenario

**Question:** A host has load average 30 on 16 CPUs, but CPU usage is only 25%. What hypotheses do you form?

**Answer:**

On 16 CPUs with load 30 and 25% CPU, suspect blocked I/O, storage/network filesystem latency, or large runnable bursts. Check task states before blaming CPU saturation.

### Q11.4 — Troubleshooting / Failure

**Question:** How would you prove whether uninterruptible I/O, runnable-task bursts, or another factor is driving the load?

**Answer:**

Use `ps`/`top` for `R` and `D` states, `vmstat`, `iostat`, `pidstat`, storage latency/queue metrics, and kernel logs. Correlate timestamps with storage or filesystem behaviour to prove the cause.

### Q11.5 — Senior Trade-off / Edge Case

**Question:** What operational thresholds would you use for alerting on load average, and why is a static threshold often weak?

**Answer:**

Alerting on raw load alone is noisy. Combine load-per-core with CPU saturation, runnable/D-state counts, I/O latency, and user impact. Page on service degradation; use load as a diagnostic or predictive signal.

---

## Q12 — CPU saturation

### Q12.1 — Foundation

**Question:** Production CPU suddenly reaches 100%. What is your first approach?

**Answer:**

Start by confirming user impact and whether CPU is host-wide, container-specific, or process/thread-specific. Correlate with traffic and recent changes before taking action.

### Q12.2 — Internals / Mechanism

**Question:** Explain how user time, system time, iowait, steal, IRQ, and softirq change your diagnosis.

**Answer:**

User time suggests application work; system time suggests kernel activity; iowait is CPU idle while waiting on I/O; steal suggests hypervisor contention; IRQ/softirq can indicate network or device processing.

### Q12.3 — Production Scenario

**Question:** A Kubernetes node is CPU-saturated after a deployment. How do you separate application CPU, kernel overhead, and noisy-neighbour effects?

**Answer:**

Compare Pod/container CPU, cgroup throttling, node CPU modes, per-process/thread usage, and deployment version. A new workload can saturate a core even if node average looks acceptable.

### Q12.4 — Troubleshooting / Failure

**Question:** Which commands and profiles would you use to identify hot processes, threads, syscalls, and code paths without making the incident worse?

**Answer:**

Use `top`, `pidstat`, `mpstat`, `perf`, runtime profilers, thread dumps, and syscall/network metrics with minimal overhead. Prefer sampling rather than heavy tracing during an incident.

### Q12.5 — Senior Trade-off / Edge Case

**Question:** When is throttling, scaling, rollback, or optimization the right mitigation, and how do you choose?

**Answer:**

Rollback when a change clearly caused harmful CPU. Scale if workload is valid and horizontally scalable. Throttle/load-shed to protect dependencies. Optimize only after profiling identifies a durable hot path.

---

## Q13 — Memory leak / memory growth

### Q13.1 — Foundation

**Question:** How do you distinguish a memory leak from normal memory growth?

**Answer:**

A leak is retained memory that is no longer useful and does not return to a stable baseline. Normal growth may reflect caches, warm-up, workload size, or allocator behaviour.

### Q13.2 — Internals / Mechanism

**Question:** Explain heap, native memory, page cache, mmap, allocator fragmentation, and cgroup accounting.

**Answer:**

Total memory includes managed heap, native allocations, stacks, mmap, direct buffers, allocator fragmentation, and page cache. Container accounting can include memory the language runtime does not report.

### Q13.3 — Production Scenario

**Question:** A Java container grows toward its memory limit while JVM heap remains at 60%. What are your main hypotheses?

**Answer:**

If JVM heap is only 60%, inspect native memory, direct buffers, thread count/stacks, metaspace, code cache, mmap, JNI/native libraries, and file cache.

### Q13.4 — Troubleshooting / Failure

**Question:** How would you use container metrics, JVM/native memory data, `/proc`, and system tooling to isolate the cause?

**Answer:**

Compare cgroup memory with JVM/NMT data, `/proc/<pid>/smaps`, thread counts, direct-buffer metrics, open files, and workload changes. Restart only as mitigation while preserving evidence if feasible.

### Q13.5 — Senior Trade-off / Edge Case

**Question:** What remediation is safest during an incident, and what long-term engineering controls would you add to prevent recurrence?

**Answer:**

During an incident, reduce load or restart safely if OOM risk is high. Long term, set memory budgets, limit native/direct allocations, monitor working set and cgroup headroom, and test under realistic load.

---

## Q14 — Zombie processes

### Q14.1 — Foundation

**Question:** What is a zombie process?

**Answer:**

A zombie is a process that has exited but whose parent has not yet collected its exit status with `wait()`. It keeps a PID table entry but no longer executes.

### Q14.2 — Internals / Mechanism

**Question:** Why does a zombie exist and why can't you simply kill it?

**Answer:**

You cannot 'kill' a zombie because it is already dead. The parent must reap it, or the parent must exit so another reaper such as init can adopt and reap the child.

### Q14.3 — Production Scenario

**Question:** A container accumulates thousands of zombies. What does that tell you about PID 1 and child reaping?

**Answer:**

Thousands of zombies in a container usually mean PID 1 or another parent is not reaping children correctly. Lightweight containers without a proper init often expose this problem.

### Q14.4 — Troubleshooting / Failure

**Question:** How would you identify the parent process, confirm the leak mechanism, and mitigate safely?

**Answer:**

Use `ps` to identify `Z` state and PPID, inspect the parent, and verify child-spawning behaviour. Fix or restart the faulty parent; adding a minimal init such as `tini` may help.

### Q14.5 — Senior Trade-off / Edge Case

**Question:** What container-entrypoint or init-system design choices prevent zombie accumulation in production?

**Answer:**

Container entrypoints should either reap children correctly or use an init process. Avoid spawning unmanaged subprocesses, and monitor PID pressure because zombie accumulation can exhaust the PID namespace.

---

## Q15 — File descriptors

### Q15.1 — Foundation

**Question:** What is a file descriptor?

**Answer:**

A file descriptor is a per-process integer handle that refers to an open kernel object such as a file, socket, pipe, eventfd, or device.

### Q15.2 — Internals / Mechanism

**Question:** Explain how files, sockets, pipes, and other kernel objects are represented through file descriptors.

**Answer:**

The process descriptor table maps integers to open-file descriptions/kernel objects. Sockets and pipes use the same descriptor abstraction as regular files, which is why network leaks can exhaust the same limit.

### Q15.3 — Production Scenario

**Question:** A service starts returning `Too many open files`. What are the likely causes?

**Answer:**

`Too many open files` usually means the process or system limit is reached because of leaks, too many concurrent connections/files, or slow closure. Determine whether growth is expected or unbounded.

### Q15.4 — Troubleshooting / Failure

**Question:** How would you use `/proc`, `lsof`, `ss`, limits, and application metrics to determine whether this is a leak or legitimate growth?

**Answer:**

Inspect `/proc/<pid>/fd`, `lsof`, `ss`, process limits, and descriptor counts over time. Group descriptors by type/destination to distinguish socket leaks, file leaks, and legitimate concurrency.

### Q15.5 — Senior Trade-off / Edge Case

**Question:** When is increasing `ulimit` appropriate, and when does it only hide a deeper design problem?

**Answer:**

Raising limits is valid when concurrency is legitimate and the rest of the system can handle it. If descriptor count rises without bound, increasing `ulimit` only delays failure and enlarges blast radius.

---

## Q16 — SIGTERM vs SIGKILL

### Q16.1 — Foundation

**Question:** What is the difference between SIGTERM and SIGKILL?

**Answer:**

SIGTERM is a catchable signal requesting graceful termination. SIGKILL cannot be caught, blocked, or handled and causes immediate kernel-enforced termination.

### Q16.2 — Internals / Mechanism

**Question:** Explain what the kernel and application can do for each signal.

**Answer:**

With SIGTERM, the application can stop accepting work, flush state, close connections, and exit. SIGKILL bypasses cleanup and may leave external work or in-flight operations incomplete.

### Q16.3 — Production Scenario

**Question:** A Kubernetes Pod repeatedly needs `kill -9` to terminate. What might be wrong?

**Answer:**

If a Pod needs SIGKILL, the process may ignore SIGTERM, deadlock during shutdown, block on I/O, or have incorrect PID 1 signal handling. Kubernetes eventually sends SIGKILL after the grace period.

### Q16.4 — Troubleshooting / Failure

**Question:** How would you investigate stuck shutdown, blocked I/O, deadlocks, preStop hooks, and termination grace periods?

**Answer:**

Inspect shutdown logs, thread dumps, preStop hooks, signal delivery, open connections, and blocked syscalls. Confirm whether the app receives SIGTERM and what prevents completion.

### Q16.5 — Senior Trade-off / Edge Case

**Question:** What shutdown contract should a production service implement to balance graceful completion against fast recovery?

**Answer:**

A production service should stop new work, finish or safely abort in-flight operations, release leases/connections, and exit within a bounded grace period. The bound must protect both correctness and recovery speed.

---

# 03 — Networking

## Q17 — What happens when you open an HTTPS URL

### Q17.1 — Foundation

**Question:** What happens when you type `https://example.com` into a browser?

**Answer:**

A browser typically resolves DNS, selects a route, resolves the next-hop neighbour if needed, establishes TCP, performs TLS, sends HTTP, then receives responses through load balancers/proxies/application layers.

### Q17.2 — Internals / Mechanism

**Question:** Walk through DNS, route selection, neighbour resolution, TCP, TLS, HTTP, proxies/load balancers, and application handling.

**Answer:**

Each layer adds state: DNS maps name to address; L2/L3 reach the destination; TCP provides a connection; TLS authenticates/encrypts; HTTP carries the request; intermediaries may terminate or forward connections.

### Q17.3 — Production Scenario

**Question:** The browser resolves DNS successfully but the page never loads. Which layers are still suspect?

**Answer:**

If DNS succeeds but the page never loads, routing, firewall, TCP handshake, TLS, proxy/load balancer, server application, or downstream dependencies can still fail.

### Q17.4 — Troubleshooting / Failure

**Question:** How would you narrow the fault domain using packet capture, socket state, TLS tools, and application telemetry?

**Answer:**

Narrow layer by layer: `dig`, route checks, `tcpdump`, `ss`, `curl -v`, `openssl s_client`, LB logs, backend telemetry, and traces. Stop when evidence first diverges from a known-good request.

### Q17.5 — Senior Trade-off / Edge Case

**Question:** Where would you place observability and timeouts across the path so failures are diagnosable rather than appearing as generic latency?

**Answer:**

Use explicit per-hop timeouts, trace/context propagation, LB/proxy access logs, DNS/network metrics, and synthetic end-to-end tests so generic 'timeout' symptoms can be localized quickly.

---

## Q18 — TCP three-way handshake

### Q18.1 — Foundation

**Question:** Explain the TCP three-way handshake.

**Answer:**

TCP uses SYN, SYN-ACK, ACK to establish bidirectional state and synchronize sequence numbers before data transfer.

### Q18.2 — Internals / Mechanism

**Question:** Why are sequence numbers exchanged and why isn't a two-message handshake sufficient?

**Answer:**

Both sides need independent initial sequence numbers and confirmation that the other side received them. Two messages cannot fully confirm bidirectional reachability and synchronized state in the same way.

### Q18.3 — Production Scenario

**Question:** Clients intermittently fail during connection establishment while established connections are fine. What does that suggest?

**Answer:**

Connection-establishment failures with healthy established sessions point toward SYN/SYN-ACK loss, listen backlog pressure, firewall/NAT issues, or connection-rate limits rather than application request handling.

### Q18.4 — Troubleshooting / Failure

**Question:** How would you distinguish SYN drops, backlog exhaustion, firewall issues, and server overload?

**Answer:**

Check SYN retransmits, listen backlog, `ss -s`, SYN cookies, firewall counters, LB metrics, packet captures, and server accept rate. Compare failing and healthy paths.

### Q18.5 — Senior Trade-off / Edge Case

**Question:** What tuning or architectural changes are appropriate for legitimate connection bursts versus an attack or retry storm?

**Answer:**

For legitimate bursts, scale listeners, reuse connections, tune backlogs, and distribute load. For abusive or retry-amplified traffic, rate limit and protect the edge instead of blindly raising kernel limits.

---

## Q19 — TIME_WAIT

### Q19.1 — Foundation

**Question:** What is `TIME_WAIT` and why does it exist?

**Answer:**

`TIME_WAIT` is a TCP state retained after close, commonly by the active closer, to prevent old delayed segments from corrupting a new connection and to allow retransmission of the final ACK.

### Q19.2 — Internals / Mechanism

**Question:** Explain why the active closer commonly enters `TIME_WAIT` and how it protects TCP correctness.

**Answer:**

The active closer keeps the tuple state for roughly twice the maximum segment lifetime. This protects sequence-space correctness when the same endpoints/ports might be reused.

### Q19.3 — Production Scenario

**Question:** A service has tens of thousands of TIME_WAIT sockets and begins failing outbound connections. What could be happening?

**Answer:**

Large TIME_WAIT counts can contribute to ephemeral-port exhaustion or NAT table pressure when clients create many short-lived outbound connections instead of reusing them.

### Q19.4 — Troubleshooting / Failure

**Question:** How would you investigate ephemeral-port exhaustion, connection reuse, NAT limits, and client behaviour?

**Answer:**

Inspect socket state, source-port usage, connection reuse/keepalive, NAT limits, and destination distribution. Determine whether the bottleneck is host ports, LB/NAT state, or remote limits.

### Q19.5 — Senior Trade-off / Edge Case

**Question:** Which mitigations are safe, and why can aggressive TIME_WAIT tuning create subtle correctness problems?

**Answer:**

Prefer connection pooling/keepalive and sensible client design. Kernel options that aggressively reuse TIME_WAIT can have correctness/network-device interactions, so tune only with full understanding and testing.

---

## Q20 — DNS works but TCP times out

### Q20.1 — Foundation

**Question:** A hostname resolves successfully but connections time out. What do you check next?

**Answer:**

After successful DNS, check route reachability, security/firewall policy, TCP handshake, NAT/proxy path, target health, and application listening state.

### Q20.2 — Internals / Mechanism

**Question:** Explain the layers between DNS success and successful application connectivity.

**Answer:**

DNS only supplies an address. The packet still needs a route, allowed policy, functioning transport, a reachable listener, and potentially TLS/proxy negotiation before the application can respond.

### Q20.3 — Production Scenario

**Question:** Only one subnet experiences the timeout while others work. How does that change your hypothesis set?

**Answer:**

If one subnet fails, compare its route table, NACL, NAT/egress path, security attachments, and network appliance policy with healthy subnets.

### Q20.4 — Troubleshooting / Failure

**Question:** Walk through route tables, SG/NACL/firewall policy, NAT, proxying, endpoint health, and packet evidence.

**Answer:**

Use route inspection, VPC/network flow logs, security policy review, `tcpdump`, SYN retransmit evidence, `nc/curl`, and server-side socket captures to see where packets stop.

### Q20.5 — Senior Trade-off / Edge Case

**Question:** How do you design network diagnostics so teams can distinguish DNS, routing, transport, TLS, and application failures quickly?

**Answer:**

Design diagnostics with separate DNS, connect, TLS, and request timing. This makes it possible to alert and troubleshoot by failure phase rather than one generic timeout metric.

---

## Q21 — Intermittent DNS failure

### Q21.1 — Foundation

**Question:** How would you investigate intermittent DNS timeouts?

**Answer:**

Intermittent DNS issues require correlation by node, resolver, hostname, and time. Check resolver latency/errors, cache behaviour, upstream health, packet loss, and query volume.

### Q21.2 — Internals / Mechanism

**Question:** Explain caching, recursive resolution, resolver configuration, TTLs, search domains, and retry behaviour.

**Answer:**

Stub resolvers may retry across configured servers. Search domains and `ndots` can multiply queries. TTLs affect cache hit rate, while recursive resolvers depend on upstream authoritative/recursive paths.

### Q21.3 — Production Scenario

**Question:** Only 2% of requests fail and failures cluster on a subset of nodes. What hypotheses become stronger?

**Answer:**

If failures cluster on certain nodes, suspect node-local networking, conntrack, resolver configuration, packet drops, or uneven CoreDNS reachability rather than the authoritative DNS data itself.

### Q21.4 — Troubleshooting / Failure

**Question:** How would you test resolver health, CoreDNS/upstream behaviour, packet loss, conntrack pressure, and `ndots`-related amplification?

**Answer:**

Inspect `/etc/resolv.conf`, CoreDNS metrics/logs, node conntrack, packet captures on UDP/TCP 53, query rates, upstream latency, and failing node paths. Test direct resolver queries from affected Pods.

### Q21.5 — Senior Trade-off / Edge Case

**Question:** What architectural changes reduce DNS as a systemic dependency without creating stale-discovery risks?

**Answer:**

Use caching carefully, scale resolvers, reduce unnecessary search expansions, monitor saturation, and consider local caches. Avoid excessive TTL overrides that make service changes slow to propagate.

---

## Q22 — HTTP 502 / 503 / 504

### Q22.1 — Foundation

**Question:** What is the operational difference between HTTP 502, 503, and 504?

**Answer:**

502 usually means a proxy received an invalid/failed upstream response, 503 usually means service unavailable/no healthy capacity, and 504 means the proxy timed out waiting for an upstream response.

### Q22.2 — Internals / Mechanism

**Question:** Explain which component commonly emits each status in reverse-proxy and load-balancer architectures.

**Answer:**

The exact emitter matters: ALB, ingress, API gateway, or app may map failures differently. Always inspect the component generating the status rather than relying on the number alone.

### Q22.3 — Production Scenario

**Question:** Users see 504s while backend CPU is low. What classes of failure would you investigate?

**Answer:**

504s with low backend CPU suggest waiting: downstream latency, connection-pool exhaustion, network stalls, queueing, or timeout mismatch. Low CPU does not imply healthy service.

### Q22.4 — Troubleshooting / Failure

**Question:** How would you correlate load-balancer logs, upstream timing, retries, queueing, and dependency latency to identify the source?

**Answer:**

Correlate LB/proxy access logs, upstream connect/response times, traces, queue depth, pool waits, retry counts, and dependency timings. Identify which hop consumes the timeout budget.

### Q22.5 — Senior Trade-off / Edge Case

**Question:** How should timeout budgets and error mapping be designed so the status code gives useful operational meaning?

**Answer:**

Set consistent timeout budgets from outer to inner layers, return meaningful status codes, and avoid retries that exceed caller deadlines. Good error mapping should preserve where failure occurred.

---

## Q23 — Packet loss

### Q23.1 — Foundation

**Question:** What is packet loss and how does it affect TCP applications?

**Answer:**

Packet loss means packets are dropped before reaching the intended endpoint. TCP reacts with retransmission and congestion control, which can increase latency and reduce throughput sharply.

### Q23.2 — Internals / Mechanism

**Question:** Explain retransmissions, congestion control, latency inflation, and throughput collapse.

**Answer:**

Loss triggers retransmissions, duplicate ACKs, and congestion-window reduction. Even small loss can hurt long-distance/high-throughput flows because TCP interprets loss as congestion.

### Q23.3 — Production Scenario

**Question:** Application latency rises but CPU and memory look normal. What evidence would make packet loss a leading hypothesis?

**Answer:**

Rising latency with healthy app CPU/memory becomes suspicious when retransmits, interface drops, TCP recovery counters, or path-specific failures also increase.

### Q23.4 — Troubleshooting / Failure

**Question:** How would you use `ping`, `mtr`, `ss`, TCP retransmit metrics, packet capture, and interface counters responsibly?

**Answer:**

Use `mtr` carefully, interface counters, `ss -i`, TCP retransmit metrics, cloud/network telemetry, and targeted packet capture. ICMP loss alone is not proof because devices may deprioritize ICMP.

### Q23.5 — Senior Trade-off / Edge Case

**Question:** How do you distinguish host, switch, overlay, WAN, and cloud-provider loss when you do not control the entire path?

**Answer:**

Compare endpoints and hops to isolate host, overlay, AZ, WAN, or provider path. Where you lack control, gather bidirectional evidence and timestamps strong enough for the network/provider team to act.

---

## Q24 — TLS handshake

### Q24.1 — Foundation

**Question:** Explain a TLS handshake at a practical engineering level.

**Answer:**

TLS negotiates protocol/cipher, authenticates the server with certificates, performs key agreement, derives symmetric session keys, and then encrypts application traffic. Modern TLS also uses SNI and ALPN.

### Q24.2 — Internals / Mechanism

**Question:** Describe certificate validation, key agreement, session keys, SNI, ALPN, and resumption.

**Answer:**

Certificate validation checks identity and chain trust; SNI selects the virtual host/cert; ALPN can negotiate HTTP/2; ephemeral key exchange provides forward secrecy; session resumption reduces handshake cost.

### Q24.3 — Production Scenario

**Question:** A client gets intermittent TLS failures only for one hostname behind a shared load balancer. What could cause that?

**Answer:**

One hostname failing behind a shared LB suggests SNI routing, certificate selection, chain configuration, hostname mismatch, or backend/edge inconsistency rather than generic TLS failure.

### Q24.4 — Troubleshooting / Failure

**Question:** How would you investigate certificate chains, SNI routing, clock skew, cipher/protocol mismatch, and termination points?

**Answer:**

Use `openssl s_client`, `curl -v`, certificate-chain inspection, SNI-specific tests, clock checks, LB configuration, protocol/cipher comparison, and logs at each termination point.

### Q24.5 — Senior Trade-off / Edge Case

**Question:** Where should TLS terminate in a multi-tier platform, and what are the security and operability trade-offs of re-encryption or mTLS?

**Answer:**

Terminate TLS where security ownership and observability make sense. Re-encryption/mTLS improves trust boundaries but adds certificate lifecycle and debugging complexity; plaintext internal traffic is simpler but weaker.

---

# 04 — Kubernetes Fundamentals & Internals

## Q25 — Pod creation lifecycle

### Q25.1 — Foundation

**Question:** What happens after `kubectl apply` creates a Pod?

**Answer:**

`kubectl apply` sends desired state to the API server. After admission and persistence, the scheduler selects a node; kubelet observes the Pod, asks the runtime to create containers, and CNI/storage components prepare dependencies.

### Q25.2 — Internals / Mechanism

**Question:** Walk through API server persistence, admission, scheduling, kubelet reconciliation, CRI, image pull, CNI, and readiness.

**Answer:**

The API server is the control-plane front door; etcd persists state; admission can mutate/validate; scheduler binds unscheduled Pods; kubelet reconciles node state; CRI/CNI/CSI integrate runtime, network, and storage.

### Q25.3 — Production Scenario

**Question:** A Pod object exists but no container starts. Which control-plane and node-side stages could be blocked?

**Answer:**

If the Pod object exists but no container starts, distinguish unscheduled Pod, image/runtime failure, volume setup, sandbox/CNI failure, or kubelet/node problems using status and events.

### Q25.4 — Troubleshooting / Failure

**Question:** How would you use events, scheduler data, kubelet logs, runtime state, and CNI evidence to find the failed stage?

**Answer:**

Follow the lifecycle: events and scheduler decisions, Pod conditions, kubelet logs, CRI state, image pull, sandbox/CNI, mount errors. Identify the earliest stage that fails rather than debugging the app first.

### Q25.5 — Senior Trade-off / Edge Case

**Question:** Which parts of this lifecycle would you make highly available or observable first in a production cluster, and why?

**Answer:**

Prioritize API/etcd availability, scheduler/controller health, kubelet/runtime health, and CNI/CSI observability. A production cluster needs per-stage metrics/events because a generic 'Pod Pending' hides many failure classes.

---

## Q26 — Deployment → ReplicaSet → Pod

### Q26.1 — Foundation

**Question:** Explain the relationship between a Deployment, ReplicaSet, and Pod.

**Answer:**

A Deployment manages ReplicaSets, and ReplicaSets maintain the desired number of Pods. This layering gives Deployments rollout and rollback semantics while ReplicaSets handle replica count.

### Q26.2 — Internals / Mechanism

**Question:** Why does a Deployment not directly manage Pods?

**Answer:**

A Deployment creates new ReplicaSets for Pod-template revisions, scales old/new sets according to rollout strategy, and records revision history. Pods remain directly owned by ReplicaSets.

### Q26.3 — Production Scenario

**Question:** A rollout creates a new ReplicaSet but never scales it fully. What mechanisms control progress?

**Answer:**

If a new ReplicaSet stalls, inspect readiness, scheduling, maxSurge/maxUnavailable, PDBs, quota, capacity, image pulls, and progress-deadline conditions.

### Q26.4 — Troubleshooting / Failure

**Question:** How would you investigate maxSurge/maxUnavailable, readiness, PDBs, quota, scheduling, and rollout status?

**Answer:**

Use `kubectl rollout status`, ReplicaSet/Pod events, scheduler messages, PDB state, resource availability, and probe results. Check whether old Pods cannot terminate or new Pods cannot become Ready.

### Q26.5 — Senior Trade-off / Edge Case

**Question:** What trade-offs would you choose for a critical API between rollout speed, capacity overhead, and availability?

**Answer:**

For critical APIs, keep enough surge capacity and conservative unavailability limits. Faster rollout reduces deployment time but increases simultaneous change; zero spare capacity can deadlock rollouts.

---

## Q27 — Kubernetes Service traffic

### Q27.1 — Foundation

**Question:** What is a Kubernetes Service?

**Answer:**

A Kubernetes Service provides stable virtual addressing and service discovery for a dynamic set of Pod endpoints selected through labels/EndpointSlices.

### Q27.2 — Internals / Mechanism

**Question:** Explain how Service VIPs, EndpointSlices, kube-proxy or eBPF datapaths, and Pod IPs fit together.

**Answer:**

Traffic is steered from the Service VIP to Pod IPs by kube-proxy rules or an alternative dataplane such as eBPF. EndpointSlices represent current backends; the Service itself is not a user-space proxy process.

### Q27.3 — Production Scenario

**Question:** DNS resolves the Service but clients cannot connect. Which layers do you inspect?

**Answer:**

If DNS resolves but connect fails, check EndpointSlices, target Pod readiness/listeners, network policy, kube-proxy/eBPF rules, node routing, and CNI connectivity.

### Q27.4 — Troubleshooting / Failure

**Question:** Same-node Service traffic works but cross-node traffic fails. How do you narrow the fault to CNI, routing, conntrack, policy, or node networking?

**Answer:**

Same-node success with cross-node failure strongly points toward overlay/routing/encapsulation/MTU/conntrack or node-specific policy. Capture traffic on source Pod/node and destination node to see where it disappears.

### Q27.5 — Senior Trade-off / Edge Case

**Question:** How would your diagnosis change in an eBPF-based cluster where kube-proxy is absent?

**Answer:**

In eBPF clusters, inspect BPF maps/programs and CNI-specific observability rather than iptables/IPVS. The reasoning remains endpoint → service translation → node path → Pod path.

---

## Q28 — Ready Pods but 503s

### Q28.1 — Foundation

**Question:** All Pods are Ready but users receive 503s. Where do you start?

**Answer:**

Start outside-in: confirm who returns 503, affected scope, load-balancer/ingress target health, Service endpoints, and application/dependency health. Pod `Ready=True` is only one signal.

### Q28.2 — Internals / Mechanism

**Question:** Explain why readiness alone does not guarantee end-to-end availability.

**Answer:**

Readiness checks a configured condition, not every user journey. A Pod may be ready yet fail certain routes, auth, downstream calls, or zone-specific dependencies.

### Q28.3 — Production Scenario

**Question:** Only one availability zone shows 503s. Which routing and dependency issues become likely?

**Answer:**

One-AZ 503s suggest zonal target registration, subnet/NAT issues, AZ-specific dependencies, node/CNI faults, or uneven deployment. Segment all telemetry by AZ.

### Q28.4 — Troubleshooting / Failure

**Question:** How would you correlate ingress/load-balancer targets, Service endpoints, app health, dependency health, and zonal networking?

**Answer:**

Compare LB target health, ingress logs, EndpointSlices, Pod versions, node placement, dependency endpoints, and traces from healthy versus failing AZs. Find the first divergent hop.

### Q28.5 — Senior Trade-off / Edge Case

**Question:** What changes would you make so readiness reflects true serving capability without making probes overly expensive or fragile?

**Answer:**

Readiness should test essential serving capability cheaply. Avoid probes that depend on every downstream service, or one dependency can cause cascading eviction; use layered health and synthetic end-to-end checks.

---

## Q29 — CrashLoopBackOff

### Q29.1 — Foundation

**Question:** What does `CrashLoopBackOff` mean?

**Answer:**

`CrashLoopBackOff` means a container repeatedly exits and Kubernetes is delaying restarts with backoff. It is a symptom, not a root cause.

### Q29.2 — Internals / Mechanism

**Question:** Explain restart policy, exponential backoff, container exit states, and how previous logs help.

**Answer:**

Kubelet restarts according to Pod restart policy and increases delay after repeated failures. Container status records last termination reason/exit code; `kubectl logs --previous` retrieves prior-instance logs.

### Q29.3 — Production Scenario

**Question:** A Pod starts successfully for 20 seconds and then crashes repeatedly. What categories of causes do you consider?

**Answer:**

Crashing after 20 seconds suggests startup success followed by runtime error, liveness failure, dependency/config issue, OOM, or scheduled/background task. Check last state and timeline.

### Q29.4 — Troubleshooting / Failure

**Question:** How would you inspect events, exit codes, OOMKilled, probes, config, secrets, dependencies, and application startup/shutdown behaviour?

**Answer:**

Inspect `describe`, events, previous logs, exit code, OOMKilled, probes, mounted config/secrets, dependency connectivity, and application metrics. Reproduce with the same image/config when safe.

### Q29.5 — Senior Trade-off / Edge Case

**Question:** When is disabling a liveness probe or increasing delays an acceptable mitigation, and when would that conceal the real fault?

**Answer:**

Temporarily relaxing a bad liveness probe can restore availability if the app is healthy. But masking genuine hangs only delays detection. Fix probe semantics and app failure handling after stabilization.

---

## Q30 — Pending Pod

### Q30.1 — Foundation

**Question:** What does it mean when a Pod remains Pending?

**Answer:**

`Pending` means the Pod has not yet reached a running container state, commonly because it is unscheduled or waiting on setup such as storage.

### Q30.2 — Internals / Mechanism

**Question:** Explain scheduling constraints, resource requests, affinity, taints/tolerations, PVC binding, quotas, and admission blockers.

**Answer:**

Causes include insufficient resources, affinity/anti-affinity, taints, quota, PVC binding, topology constraints, admission rules, image/sandbox setup, or scheduler policy.

### Q30.3 — Production Scenario

**Question:** Only new Pods are Pending while existing workloads run normally. What recent changes or capacity issues do you suspect?

**Answer:**

If existing Pods run but new ones stay Pending, suspect exhausted capacity/quota, changed scheduling rules, broken storage provisioning, admission changes, or unavailable nodes.

### Q30.4 — Troubleshooting / Failure

**Question:** How would you use scheduler events, node allocatable data, quotas, storage state, and affinity rules to identify the blocker?

**Answer:**

Read Pod events first, then scheduler messages, node allocatable vs requests, taints/affinity, quota, PVC/StorageClass status, and admission/controller logs. Let the scheduler tell you why.

### Q30.5 — Senior Trade-off / Edge Case

**Question:** How do you design capacity headroom and scheduling policy so a single placement constraint cannot create a large outage?

**Answer:**

Maintain headroom, test topology constraints, monitor unschedulable reasons, and avoid rigid anti-affinity/PDB combinations that require capacity you do not have during failures or rollouts.

---

## Q31 — Kubernetes DNS

### Q31.1 — Foundation

**Question:** How does DNS work inside a Kubernetes cluster?

**Answer:**

Kubernetes Pods typically use cluster DNS, commonly CoreDNS, to resolve Service and Pod-related names. Resolver search domains and `ndots` influence how names are expanded.

### Q31.2 — Internals / Mechanism

**Question:** Explain CoreDNS, Service discovery records, search domains, `ndots`, caching, and upstream resolution.

**Answer:**

Service records map names to ClusterIPs or headless endpoints. CoreDNS may cache and forward external queries upstream. Pod `/etc/resolv.conf` defines search paths and retry behaviour.

### Q31.3 — Production Scenario

**Question:** Only Pods on certain nodes intermittently fail to resolve Services. What does that suggest?

**Answer:**

Node-local concentration suggests node networking, conntrack, resolver config, or uneven access to CoreDNS. If all nodes fail equally, look more at CoreDNS/upstream saturation or config.

### Q31.4 — Troubleshooting / Failure

**Question:** How would you test CoreDNS, node networking, conntrack, resolver config, packet loss, and query amplification?

**Answer:**

Test queries from affected Pods to cluster DNS and upstream, inspect CoreDNS latency/error metrics, node conntrack, packet loss, resolver config, and query amplification from `ndots`/search domains.

### Q31.5 — Senior Trade-off / Edge Case

**Question:** What changes improve DNS resilience at scale without causing stale data or masking service-discovery failures?

**Answer:**

Scale/cache DNS, reduce unnecessary query expansion, use NodeLocal DNS where appropriate, and monitor saturation. Do not hide service-discovery changes with excessively long caching.

---

## Q32 — etcd unavailable

### Q32.1 — Foundation

**Question:** What is etcd used for in Kubernetes?

**Answer:**

etcd stores Kubernetes cluster state. The API server depends on it for persistent reads/writes of objects and coordination state.

### Q32.2 — Internals / Mechanism

**Question:** What happens to reads, writes, scheduling, controllers, and already-running workloads when etcd becomes unavailable?

**Answer:**

With etcd unavailable, control-plane writes fail and many fresh reads may fail; scheduling/controllers cannot persist changes. Existing Pods and data-plane traffic can continue because kubelets/runtime already have local state.

### Q32.3 — Production Scenario

**Question:** Your applications continue serving but no new Pods can be created. How would you confirm etcd is the control-plane bottleneck?

**Answer:**

Confirm API write failures, API-server etcd latency/errors, and inability to create/update objects while existing workloads still serve. This pattern strongly indicates control-plane persistence failure.

### Q32.4 — Troubleshooting / Failure

**Question:** How would you investigate quorum, disk latency, network partitions, certs, resource pressure, and member health?

**Answer:**

Check etcd member health, quorum, peer/client network, disk fsync latency, CPU/memory, certificate expiry, DB size, and alarms. Never 'fix' quorum by randomly removing members during an incident.

### Q32.5 — Senior Trade-off / Edge Case

**Question:** What backup, restore, quorum, and failure-domain design would you require for a production etcd cluster?

**Answer:**

Use odd-member quorum across failure domains, fast durable disks, regular tested snapshots, strict cert monitoring, and documented restore/member-replacement procedures. Backups are only useful if restore is rehearsed.

---

# 05 — Kubernetes Production Troubleshooting

## Q33 — Deployment regression

### Q33.1 — Foundation

**Question:** Error rate rises five minutes after a deployment. What do you do first?

**Answer:**

Confirm user impact, timeline, and correlation with the rollout. Compare old versus new version metrics and decide quickly whether safe rollback/traffic shift is available.

### Q33.2 — Internals / Mechanism

**Question:** Explain how you correlate rollout timeline, version, configuration, traffic, and dependency changes.

**Answer:**

Correlate deployment revision, config, feature flags, schema changes, traffic distribution, and dependency behaviour. Version-scoped metrics are especially valuable.

### Q33.3 — Production Scenario

**Question:** Only the new ReplicaSet shows elevated errors while old Pods remain healthy. What is your immediate mitigation?

**Answer:**

If only the new ReplicaSet is unhealthy, stop rollout and shift traffic/rollback if safe. Preserve enough failing instances or telemetry to diagnose after customer impact is reduced.

### Q33.4 — Troubleshooting / Failure

**Question:** If rollback does not restore health, how would you test whether schema changes, cache state, external dependencies, or irreversible side effects are involved?

**Answer:**

If rollback fails, investigate irreversible side effects: DB migrations, cache/schema state, queues, feature flags, external API changes, or a coincident dependency failure. Compare state, not just binaries.

### Q33.5 — Senior Trade-off / Edge Case

**Question:** How do you define rollback criteria and release guardrails so the decision is fast, safe, and not dependent on one person's intuition?

**Answer:**

Define automated rollback/abort thresholds on error/latency/SLO burn, test backwards compatibility, separate schema expansion from code switch, and make every release observable by version.

---

## Q34 — One slow Pod

### Q34.1 — Foundation

**Question:** One out of ten Pods has 3x higher latency. What could cause that?

**Answer:**

Compare the slow Pod with healthy peers: node, CPU throttling, memory/GC, network, disk, connection pools, cache warmth, version/config, and dependency endpoints.

### Q34.2 — Internals / Mechanism

**Question:** Explain node locality, CPU throttling, memory pressure, GC, network path, disk, connection pools, and cache-warmth effects.

**Answer:**

Per-instance latency can differ because containers share node resources and network paths. Cgroup throttling, noisy neighbours, GC, or node-local failures may affect only one replica.

### Q34.3 — Production Scenario

**Question:** The slow Pod becomes fast after rescheduling to another node. What does that tell you?

**Answer:**

If rescheduling fixes it, node-local causes become much more likely. Preserve node evidence before draining if user impact allows.

### Q34.4 — Troubleshooting / Failure

**Question:** How would you inspect node metrics, cgroup throttling, network counters, storage latency, and noisy-neighbour evidence?

**Answer:**

Inspect node and cgroup CPU, throttling, disk latency, NIC drops, conntrack, kernel logs, CNI state, and Pod dependency timings. Compare with a healthy node under similar load.

### Q34.5 — Senior Trade-off / Edge Case

**Question:** What automation would you add so single-instance degradation is detected and isolated before it impacts users?

**Answer:**

Automate outlier detection, readiness/traffic removal for degraded instances, and node health remediation. Avoid instant reboot automation without safeguards because it can erase evidence or amplify capacity loss.

---

## Q35 — HPA not scaling

### Q35.1 — Foundation

**Question:** CPU is high but the HPA is not scaling. What do you check?

**Answer:**

Check HPA status/events, metric availability, target definition, resource requests, min/max replicas, stabilization windows, and whether new Pods can actually schedule.

### Q35.2 — Internals / Mechanism

**Question:** Explain how HPA obtains metrics, computes desired replicas, applies stabilization, and interacts with requests/limits.

**Answer:**

For CPU HPA, utilization is typically measured relative to requested CPU, not node utilization. The controller computes desired replicas from current vs target metric and applies behaviour/stabilization rules.

### Q35.3 — Production Scenario

**Question:** CPU is 90% in `top`, but HPA reports 45% utilization. Why might the numbers differ?

**Answer:**

`top` may show absolute usage while HPA shows usage/request ratio across selected Pods, possibly with missing/not-ready samples. Incorrect CPU requests make HPA percentages misleading.

### Q35.4 — Troubleshooting / Failure

**Question:** How would you inspect metrics-server/custom metrics, resource requests, HPA events, maxReplicas, cooldown behaviour, and pending capacity?

**Answer:**

Inspect `kubectl describe hpa`, metrics APIs, resource requests, maxReplicas, scaling policies, events, and Pending Pods. Verify the metric timestamp and whether throttling is masking demand.

### Q35.5 — Senior Trade-off / Edge Case

**Question:** When would CPU be the wrong scaling signal, and what workload metric would you use instead?

**Answer:**

Use a metric that tracks demand or saturation. For queue workers, queue depth/age may be better than CPU; for I/O-bound APIs, concurrency or latency may be more predictive.

---

## Q36 — OOMKilled with normal JVM heap

### Q36.1 — Foundation

**Question:** A Java Pod is OOMKilled while JVM heap metrics look normal. Why?

**Answer:**

Container OOM is based on total cgroup memory, not JVM heap alone. Native memory, direct buffers, metaspace, thread stacks, code cache, mmap, JNI libraries, and page cache can consume the rest.

### Q36.2 — Internals / Mechanism

**Question:** Explain container memory accounting beyond the Java heap: metaspace, direct buffers, thread stacks, native libraries, page cache, and mmap.

**Answer:**

JVM heap is only one region. Container limits account for process and cgroup-charged memory. Native allocations can grow independently of GC and heap metrics.

### Q36.3 — Production Scenario

**Question:** The kernel reports cgroup OOM but heap dump shows no leak. What do you investigate next?

**Answer:**

With normal heap, check thread count, direct-buffer use, NMT, metaspace, native libraries, file mappings, and cgroup working set. Kernel OOM events confirm the cgroup boundary was hit.

### Q36.4 — Troubleshooting / Failure

**Question:** How would you correlate cgroup memory, Native Memory Tracking, process mappings, thread counts, direct buffers, and limits?

**Answer:**

Use `jcmd VM.native_memory`, `/proc/<pid>/smaps`, cgroup stats, thread dumps, direct-buffer metrics, and file/cache data. Compare growth over time and against workload characteristics.

### Q36.5 — Senior Trade-off / Edge Case

**Question:** How would you size JVM/container memory and enforce guardrails so native growth cannot unexpectedly consume the cgroup budget?

**Answer:**

Set `-Xmx` with headroom for non-heap/native memory, limit thread/direct-buffer growth, monitor cgroup headroom, and load-test with production-like concurrency instead of sizing only from heap.

---

## Q37 — Node NotReady

### Q37.1 — Foundation

**Question:** What does `NodeNotReady` mean?

**Answer:**

`NodeNotReady` means the control plane has stopped receiving healthy node status/leases within expected timing or the node reports unusable conditions.

### Q37.2 — Internals / Mechanism

**Question:** Explain heartbeats/leases, kubelet status, node conditions, and controller eviction behaviour.

**Answer:**

Kubelet sends status/leases; node controllers track freshness and may add taints/evict Pods. Causes include kubelet failure, API connectivity, runtime problems, resource pressure, or host/network failure.

### Q37.3 — Production Scenario

**Question:** A node becomes NotReady during peak traffic but remains reachable by SSH. What possibilities do you consider?

**Answer:**

If SSH works, the host is alive. Investigate kubelet/runtime health, API-server connectivity, disk/PID pressure, DNS/network, certificate/auth problems, and extreme CPU starvation.

### Q37.4 — Troubleshooting / Failure

**Question:** How would you investigate kubelet, runtime, disk pressure, PID pressure, network, API-server reachability, and resource starvation before rebooting?

**Answer:**

Check node conditions/events, kubelet/container-runtime logs, systemd state, disk/inodes, PID count, cgroup pressure, network routes, and API reachability. Cordon first if the node is dangerous.

### Q37.5 — Senior Trade-off / Edge Case

**Question:** What node-remediation automation is safe, and what safeguards prevent an automated reboot loop from amplifying an outage?

**Answer:**

Safe remediation needs rate limits, quorum/capacity awareness, and confirmation before reboot/drain. Automated reboot loops can remove too much capacity during a shared network or control-plane incident.

---

## Q38 — Cross-node traffic failure

### Q38.1 — Foundation

**Question:** Same-node Pod traffic works but cross-node traffic intermittently fails. What does that suggest?

**Answer:**

Same-node success and cross-node failure point to the inter-node dataplane: CNI routing/overlay, encapsulation, MTU, node firewall, conntrack, or underlay networking.

### Q38.2 — Internals / Mechanism

**Question:** Explain the packet path across nodes for your CNI and where encapsulation/routing/NAT/policy can fail.

**Answer:**

Cross-node packets may be routed directly or encapsulated through VXLAN/Geneve/etc. They cross veth, CNI rules, host routing/BPF/iptables, physical NIC, underlay, then reverse on destination.

### Q38.3 — Production Scenario

**Question:** Failures are concentrated on one worker pair. How does that narrow your scope?

**Answer:**

One worker pair suggests a path-specific route, MTU, interface, policy, or node state problem. Compare that pair with healthy node pairs.

### Q38.4 — Troubleshooting / Failure

**Question:** How would you use route tables, CNI state, MTU checks, conntrack, packet capture, interface drops, and network policy inspection?

**Answer:**

Inspect CNI routes/BPF/iptables, tunnel state, MTU, interface drops, conntrack, node firewall, and packet capture at source Pod, source node, destination node, and destination Pod.

### Q38.5 — Senior Trade-off / Edge Case

**Question:** What cluster-network architecture choices reduce these failure modes, and what observability would you require at the dataplane?

**Answer:**

Choose a CNI with strong observability, keep MTU consistent with underlay, monitor drops/conntrack/tunnel health, and test cross-node networking continuously rather than only Service health.

---

## Q39 — Rollout stuck at 8/10

### Q39.1 — Foundation

**Question:** A Deployment rollout is stuck at 8/10 replicas. What do you inspect?

**Answer:**

Inspect Deployment/ReplicaSet/Pod status, events, readiness, scheduling, PDBs, surge/unavailable limits, capacity, quota, image pulls, and topology constraints.

### Q39.2 — Internals / Mechanism

**Question:** Explain rollout progress conditions and how readiness, scheduling, PDBs, maxSurge/maxUnavailable, and quotas affect it.

**Answer:**

A rollout needs room to create new Pods and permission to remove old ones. PDBs, no spare resources, anti-affinity, or maxSurge settings can create a progress deadlock.

### Q39.3 — Production Scenario

**Question:** Two new Pods remain Pending while old Pods cannot be terminated. What interaction could cause this?

**Answer:**

If two new Pods are Pending and old Pods cannot terminate, likely the rollout requires extra capacity that scheduling cannot provide while PDB/availability policy blocks removal.

### Q39.4 — Troubleshooting / Failure

**Question:** How would you prove whether capacity, PDB, affinity, quota, image pull, or probe failure is the blocker?

**Answer:**

Read unschedulable events, PDB disruptions allowed, node allocatable vs requests, affinity, quota, and rollout strategy. Identify whether capacity or policy is the binding constraint.

### Q39.5 — Senior Trade-off / Edge Case

**Question:** How would you design rollout policy to avoid deadlock when the cluster has little spare capacity?

**Answer:**

Reserve rollout headroom or use strategies compatible with capacity. Validate PDB + anti-affinity + maxSurge combinations in failure scenarios; zero spare capacity is operationally fragile.

---

## Q40 — Control plane healthy, workloads unhealthy

### Q40.1 — Foundation

**Question:** Kubernetes control-plane metrics are healthy but application availability is dropping. How do you narrow the fault domain?

**Answer:**

Start from the user symptom and move inward: edge/ingress, Service/endpoints, Pods, node, network/storage, app, and dependencies. Healthy control-plane metrics only say Kubernetes management is functioning.

### Q40.2 — Internals / Mechanism

**Question:** Explain why API-server health does not imply node, network, storage, ingress, or application health.

**Answer:**

API-server/etcd health is distinct from data-plane and workload health. Nodes, CNI, ingress, storage, DNS, and applications can fail while control plane is fully healthy.

### Q40.3 — Production Scenario

**Question:** Only one service is affected while other workloads on the same nodes are healthy. What does that imply?

**Answer:**

If only one service fails while peers on the same nodes are healthy, focus on that service's version/config/endpoints/dependencies before blaming the cluster.

### Q40.4 — Troubleshooting / Failure

**Question:** How would you move from external symptom to ingress, Service, Pod, node, dependency, and application evidence without random command execution?

**Answer:**

Compare failing vs healthy services, external synthetic checks, ingress logs, traces, Pod metrics, dependency calls, and node placement. Use evidence to reduce the fault domain at each step.

### Q40.5 — Senior Trade-off / Edge Case

**Question:** What layered SLOs and synthetic checks would let you distinguish platform health from workload health automatically?

**Answer:**

Define separate platform SLOs and product/service SLOs. Add synthetic transactions and dependency/service-level telemetry so a green control plane cannot be mistaken for healthy customer experience.

---

# 06 — AWS / Cloud

## Q41 — ALB to application timeout

### Q41.1 — Foundation

**Question:** Requests reach an ALB but never reach the application. What do you check?

**Answer:**

Start with the ALB layer: confirm listener/rule match, target-group health, target registration, security-group reachability, and whether the backend is listening on the expected port. Then correlate ALB logs with backend logs.

### Q41.2 — Internals / Mechanism

**Question:** Explain target groups, health checks, listeners, security groups, routing, subnets, and backend connection flow.

**Answer:**

ALB accepts the client connection, evaluates listener rules, chooses a target, opens/reuses a backend connection, and waits within configured timeouts. Subnets, routes, SGs, target health, and app sockets all matter.

### Q41.3 — Production Scenario

**Question:** Targets are healthy but requests still time out intermittently. What deeper issues do you consider?

**Answer:**

If targets are healthy but requests intermittently time out, suspect slow application/dependencies, connection-pool exhaustion, backend resets, uneven targets, NAT/network issues, or timeout mismatch. Health checks can be much simpler than real requests.

### Q41.4 — Troubleshooting / Failure

**Question:** How would you correlate ALB access logs, target response times, SG/NACLs, subnet routing, application sockets, and dependency latency?

**Answer:**

Use ALB access logs and target response time, target health reason codes, VPC flow logs, SG/NACL review, backend `ss`/logs, traces, and dependency metrics. Compare one failing request end-to-end.

### Q41.5 — Senior Trade-off / Edge Case

**Question:** What timeout, health-check, and connection-management settings would you design to avoid ambiguous ALB failures?

**Answer:**

Set realistic health checks and layered timeouts, use keepalive/connection pooling, expose per-target telemetry, and avoid making ALB idle timeout shorter than legitimate backend work unless the API contract demands it.

---

## Q42 — Security Groups vs NACLs

### Q42.1 — Foundation

**Question:** Explain the difference between Security Groups and Network ACLs.

**Answer:**

Security Groups are stateful virtual firewalls attached to ENIs/resources; NACLs are stateless subnet-level filters. SGs use allow rules only, while NACLs support ordered allow and deny rules.

### Q42.2 — Internals / Mechanism

**Question:** Which are stateful, which are stateless, and how are rules evaluated?

**Answer:**

Stateful SGs automatically allow return traffic for an allowed flow. Stateless NACLs evaluate inbound and outbound directions independently, so ephemeral return ports must also be permitted.

### Q42.3 — Production Scenario

**Question:** An outbound connection succeeds from one subnet but fails from another with identical SGs. What could explain it?

**Answer:**

If identical SGs work in one subnet but not another, compare NACLs, route tables, NAT/IGW path, subnet associations, and network appliances. The subnet layer is the differentiator.

### Q42.4 — Troubleshooting / Failure

**Question:** How would you prove whether NACLs, routes, SGs, ephemeral ports, or another layer is responsible?

**Answer:**

Use Reachability Analyzer where applicable, VPC Flow Logs, route-table inspection, NACL rule order, SG references, and packet-level tests. Confirm both directions for stateless controls.

### Q42.5 — Senior Trade-off / Edge Case

**Question:** What policy-management approach reduces accidental network outages while keeping least privilege?

**Answer:**

Prefer SGs for most workload policy and keep NACLs coarse to reduce complexity. Manage rules as code, use reusable references/prefix lists, test connectivity changes, and avoid broad emergency rules that become permanent.

---

## Q43 — Multi-AZ design

### Q43.1 — Foundation

**Question:** What does Multi-AZ protect you from?

**Answer:**

Multi-AZ protects against many single-AZ failures by distributing compute and dependencies across independent availability zones. It does not automatically protect against regional, application, data, or shared-service failures.

### Q43.2 — Internals / Mechanism

**Question:** Explain which failures AZ separation handles and which shared dependencies remain.

**Answer:**

True AZ resilience requires capacity, routing, state, and dependencies to survive losing one zone. Merely placing instances in multiple zones is insufficient if the database, NAT, queue, or load distribution remains a single point.

### Q43.3 — Production Scenario

**Question:** Your application spans three AZs but loses availability when one AZ fails. What design mistakes could cause that?

**Answer:**

If one AZ loss still causes outage, inspect remaining-zone capacity, zonal load-balancer behaviour, cross-zone traffic, quorum, zonal storage, NAT/egress, and whether clients/dependencies are pinned to the failed zone.

### Q43.4 — Troubleshooting / Failure

**Question:** How would you investigate uneven capacity, zonal load-balancing, NAT, stateful dependencies, quorum, and cross-AZ traffic?

**Answer:**

Simulate or analyze an AZ removal: confirm autoscaling headroom, target health, DB failover/quorum, subnet/NAT paths, queue/storage placement, and error rates by zone. Find dependencies that were not actually redundant.

### Q43.5 — Senior Trade-off / Edge Case

**Question:** What capacity and dependency rules would you enforce so the system can actually survive an AZ loss rather than just claim Multi-AZ?

**Answer:**

Run N+1 capacity, spread stateful quorum correctly, avoid hidden zonal dependencies, and game-day AZ loss. Multi-AZ should be demonstrated through failure testing, not inferred from architecture diagrams.

---

## Q44 — AWS API throttling

### Q44.1 — Foundation

**Question:** What is AWS API throttling?

**Answer:**

AWS API throttling occurs when request rate exceeds service, account, resource, or regional limits. Clients should respond with bounded retries using exponential backoff and jitter.

### Q44.2 — Internals / Mechanism

**Question:** Explain rate limits, burst limits, retries, exponential backoff, jitter, and token-bucket-style behaviour.

**Answer:**

Many AWS control-plane APIs enforce token/burst-style limits. Uncoordinated clients can synchronize retries and worsen throttling, so concurrency control and jitter matter as much as retry count.

### Q44.3 — Production Scenario

**Question:** An automation fleet suddenly sees throttling after a scale-out event. What do you do?

**Answer:**

After a scale-out event, reduce nonessential calls, cap concurrency, batch/cache reads, and identify which service/action is throttled. Do not let every worker retry independently at full speed.

### Q44.4 — Troubleshooting / Failure

**Question:** How would you identify the offending API/client, distinguish per-account/per-region limits, and stop retry amplification?

**Answer:**

Use CloudTrail/service metrics, SDK error codes, per-action request telemetry, and account/region quota data. Identify caller identity and call pattern, then verify whether throttling is a documented quota or adaptive protection.

### Q44.5 — Senior Trade-off / Edge Case

**Question:** When should you request quota increases versus redesign batching, caching, concurrency, and control-plane access?

**Answer:**

Request quota increases only when legitimate sustained demand requires them. Prefer architecture that avoids polling, caches stable metadata, batches operations, uses event-driven updates, and enforces centralized retry budgets.

---

## Q45 — S3 consistency

### Q45.1 — Foundation

**Question:** What consistency guarantees does Amazon S3 provide?

**Answer:**

S3 provides strong read-after-write consistency for PUT/DELETE and LIST operations in a region. After a successful write, subsequent reads and listings should reflect it.

### Q45.2 — Internals / Mechanism

**Question:** Explain strong read-after-write/list consistency and why application-level behaviour can still appear inconsistent.

**Answer:**

Strong S3 consistency does not make the entire application workflow strongly consistent. DNS/CDN caches, application caches, async replication, event delivery, metadata databases, or race conditions can still create stale behaviour.

### Q45.3 — Production Scenario

**Question:** A pipeline writes an object, then another component claims it is missing. What else besides S3 consistency could be wrong?

**Answer:**

If a consumer cannot find a just-written object, verify key/bucket/version, IAM, region/account, retry handling, conditional writes, caching, and whether the writer actually received success. Do not assume S3 eventual consistency.

### Q45.4 — Troubleshooting / Failure

**Question:** How would you investigate stale caches, eventual metadata outside S3, versioning, retries, IAM, replication, and application race conditions?

**Answer:**

Trace the object key/version from producer to consumer. Check CloudTrail/data events if enabled, S3 response/version IDs, cache layers, replication status, event timing, IAM/KMS, and application logs for key transformation.

### Q45.5 — Senior Trade-off / Edge Case

**Question:** How would you design idempotent object workflows so transient retries and duplicate events do not create inconsistent business state?

**Answer:**

Design object workflows with deterministic keys, versioning/ETags where useful, idempotent consumers, duplicate-event handling, and explicit workflow state. Treat S3 events as notifications, not exactly-once transactions.

---

## Q46 — IAM AccessDenied

### Q46.1 — Foundation

**Question:** An IAM policy appears to allow an action, but the request gets AccessDenied. What can override it?

**Answer:**

An allow in one IAM policy is not sufficient if another applicable policy contains an explicit deny or limits the permission. Check SCPs, permission boundaries, session policies, resource policies, conditions, and KMS policies.

### Q46.2 — Internals / Mechanism

**Question:** Explain identity policies, resource policies, SCPs, permission boundaries, session policies, explicit deny, and KMS policy interaction.

**Answer:**

A request is evaluated across identity and resource policy context, with boundaries/SCPs restricting the maximum permission set. Explicit deny wins. Cross-account access often requires both caller and resource-side permission.

### Q46.3 — Production Scenario

**Question:** Only one assumed role fails while another role with similar permissions succeeds. What do you compare?

**Answer:**

If one assumed role fails, compare role policy, session policy/tags, permission boundary, principal ARN conditions, source identity, SCP/account placement, resource policy, and KMS key policy.

### Q46.4 — Troubleshooting / Failure

**Question:** How would you use policy simulation, CloudTrail, role session context, resource policies, and KMS grants to isolate the denial?

**Answer:**

Use CloudTrail to capture the exact principal/action/resource/context, IAM Access Analyzer/policy simulator where applicable, decode authorization messages for supported services, and inspect all limiting policy layers.

### Q46.5 — Senior Trade-off / Edge Case

**Question:** What IAM design practices make authorization failures diagnosable without creating overly broad roles?

**Answer:**

Keep roles purpose-specific, use clear condition keys/tags, version policy-as-code, centralize SCP/boundary ownership, and make CloudTrail searchable. Avoid giant wildcard policies because they make both security and diagnosis worse.

---

## Q47 — Regional degradation / failover

### Q47.1 — Foundation

**Question:** AWS reports partial degradation in your primary region. When do you fail over?

**Answer:**

Fail over when expected customer harm in the primary region exceeds the risk and cost of failover. Use SLO/user impact, failure duration, dependency status, secondary readiness, and data correctness—not the provider status page alone.

### Q47.2 — Internals / Mechanism

**Question:** Explain the technical and business signals required before a regional failover.

**Answer:**

Regional failover is a business-continuity decision involving RTO/RPO, DNS/traffic control, data replication, capacity, third-party dependencies, and operational confidence. Partial degradation complicates the trade-off.

### Q47.3 — Production Scenario

**Question:** Some dependencies are healthy and others degraded. How do you determine whether failover improves or worsens user impact?

**Answer:**

If only some dependencies degrade, model the end-to-end path in each region. A failover can worsen things if the secondary depends on the same failing global service or lacks current data/capacity.

### Q47.4 — Troubleshooting / Failure

**Question:** How would you validate secondary-region capacity, data currency, DNS/traffic controls, external dependencies, and failback risk?

**Answer:**

Validate secondary health, capacity, replication lag, write authority, DNS/traffic mechanisms, credentials/secrets, external integrations, and rollback/failback. Use synthetic transactions before shifting full traffic when possible.

### Q47.5 — Senior Trade-off / Edge Case

**Question:** What RTO/RPO, game-day, and decision-authority model would you establish before the incident so failover is not improvised?

**Answer:**

Predefine decision authority, measurable triggers, RTO/RPO, runbooks, and tested game days. A failover mechanism that has never been exercised is itself a major incident risk.

---

## Q48 — Cloud cost anomaly

### Q48.1 — Foundation

**Question:** AWS cost increases 40% overnight without known traffic growth. Where do you start?

**Answer:**

Start by decomposing spend by account, service, region, usage type, resource/tag, and hour/day to find where the delta occurred. Then correlate the cost change with infrastructure and workload changes.

### Q48.2 — Internals / Mechanism

**Question:** Explain how you break cost down by service, account, region, tag, usage type, and time.

**Answer:**

Cost is usage × price and can change because of scale, data transfer, storage, logging, API usage, commitment coverage, or pricing/tier effects even when request count is flat.

### Q48.3 — Production Scenario

**Question:** Compute cost rises but request volume is flat. What technical causes might explain the difference?

**Answer:**

Flat traffic with higher compute spend can result from autoscaling stuck high, lower efficiency, larger instance types, runaway batch jobs, failed scale-in, or duplicated environments. Data/logging can also dominate unexpectedly.

### Q48.4 — Troubleshooting / Failure

**Question:** How would you correlate autoscaling, runaway jobs, data transfer, NAT, log ingestion, storage growth, and pricing changes?

**Answer:**

Use Cost Explorer/CUR, tags, CloudTrail/change history, autoscaling history, NAT/data-transfer metrics, log ingestion, storage growth, and resource inventory. Identify the concrete usage quantity that grew.

### Q48.5 — Senior Trade-off / Edge Case

**Question:** What FinOps guardrails and anomaly alerts would you implement without blocking legitimate scaling?

**Answer:**

Use budgets/anomaly detection, mandatory tagging, lifecycle policies, autoscaling bounds, log-retention controls, and cost-aware architecture reviews. Guardrails should alert or require review rather than block legitimate emergency scaling.

---

# 07 — Terraform / Infrastructure as Code

## Q49 — Terraform state

### Q49.1 — Foundation

**Question:** Why does Terraform need state?

**Answer:**

Terraform state maps resource addresses in configuration to real remote objects and stores attributes needed for planning, dependency handling, and lifecycle decisions.

### Q49.2 — Internals / Mechanism

**Question:** Explain resource addressing, dependency tracking, refresh, remote objects, and why config alone is insufficient.

**Answer:**

Terraform configuration describes desired state but often cannot rediscover identity, provider-generated IDs, dependency metadata, or prior resource relationships reliably. State is the working memory that connects config to actual objects.

### Q49.3 — Production Scenario

**Question:** Two teams accidentally use different state files for overlapping infrastructure. What can happen?

**Answer:**

If two states manage the same resource, each may believe it owns it and generate conflicting changes or destroys. Stop applies immediately, establish a single owner, and reconcile carefully.

### Q49.4 — Troubleshooting / Failure

**Question:** How would you detect ownership conflict, prevent destructive plans, and safely consolidate or import resources?

**Answer:**

Back up both states, inspect plans and remote IDs, choose the canonical state boundary, then use `state mv`, import, or `state rm` as appropriate. Never resolve ownership by blindly applying both configurations.

### Q49.5 — Senior Trade-off / Edge Case

**Question:** What state-boundary strategy would you use for a large organization to balance blast radius, dependencies, and team autonomy?

**Answer:**

Use state boundaries aligned to ownership and blast radius. Too-large state couples teams and slows plans; too-small state creates dependency sprawl. Prefer explicit outputs/interfaces instead of cross-team shared mutation.

---

## Q50 — Lost Terraform state

### Q50.1 — Foundation

**Question:** What happens if Terraform state is lost?

**Answer:**

If state is lost, Terraform loses its ownership mapping even though infrastructure may still exist. A fresh apply can attempt duplicate creation or destructive reconciliation.

### Q50.2 — Internals / Mechanism

**Question:** Explain why recreating the same configuration does not necessarily recover ownership safely.

**Answer:**

Configuration alone does not prove which existing object corresponds to each Terraform address. Provider defaults and generated attributes may also differ from the original creation state.

### Q50.3 — Production Scenario

**Question:** State is deleted but infrastructure still exists. What are your immediate safety steps?

**Answer:**

Freeze applies, preserve infrastructure, locate remote-state versions/backups, and make a copy of configuration/provider versions. Do not run `apply` from an empty state against production.

### Q50.4 — Troubleshooting / Failure

**Question:** How would you restore from remote-state versioning/backups or rebuild with imports while minimizing destructive actions?

**Answer:**

Restore the latest valid state if possible and run a read-only plan. If rebuilding, import resources systematically, verify each address/ID, compare plans, and resolve drift before allowing mutation.

### Q50.5 — Senior Trade-off / Edge Case

**Question:** What controls should make permanent state loss extremely unlikely, and how would you test the recovery procedure?

**Answer:**

Use versioned encrypted remote state, locking, least-privilege access, backups, and restore drills. Treat the state backend as production data with recovery objectives, not as a disposable cache.

---

## Q51 — Infrastructure drift

### Q51.1 — Foundation

**Question:** What is Terraform drift?

**Answer:**

Drift is a difference between Terraform's desired/state representation and real infrastructure, commonly caused by manual changes, external automation, or provider-side changes.

### Q51.2 — Internals / Mechanism

**Question:** How does refresh/plan reveal drift and what kinds of drift may be intentional?

**Answer:**

Terraform refresh/read operations observe current remote attributes, and plan compares them with configuration. Some changes are computed/defaulted and may not represent harmful drift.

### Q51.3 — Production Scenario

**Question:** An engineer makes an emergency console change during an outage. What should happen after stabilization?

**Answer:**

After an emergency console change, document why it was made, stabilize the incident, then decide whether the desired end state is to codify the change or revert it through Terraform.

### Q51.4 — Troubleshooting / Failure

**Question:** How would you determine whether to revert the manual change, codify it, import it, or redesign the resource?

**Answer:**

Run a plan, inspect the exact drift, understand dependencies, and update code/import/state only with review. Avoid editing state manually unless necessary and backed up.

### Q51.5 — Senior Trade-off / Edge Case

**Question:** What governance model allows emergency changes without normalizing unmanaged infrastructure?

**Answer:**

Allow break-glass changes with audit trails and post-incident reconciliation deadlines. Continuous drift detection plus ownership makes emergency flexibility possible without normalizing configuration divergence.

---

## Q52 — `terraform plan` internals

### Q52.1 — Foundation

**Question:** What does `terraform plan` do?

**Answer:**

`terraform plan` evaluates configuration, reads relevant provider/remote state, builds dependencies, computes proposed actions, and shows how actual/known state would move toward desired configuration.

### Q52.2 — Internals / Mechanism

**Question:** Explain config evaluation, provider reads, state refresh, dependency graph construction, diffing, and unknown values.

**Answer:**

Providers contribute schemas and refresh data; Terraform constructs a graph and marks unknown values where results depend on apply-time data. Replacement occurs when changed attributes are ForceNew or lifecycle requires it.

### Q52.3 — Production Scenario

**Question:** A plan shows an unexpected replacement for a critical resource. What do you do before apply?

**Answer:**

If a critical resource will be replaced unexpectedly, stop. Inspect exactly which attribute changed, provider/version changes, lifecycle rules, state, data sources, and whether the plan is stale.

### Q52.4 — Troubleshooting / Failure

**Question:** How would you inspect provider schema, lifecycle rules, changed attributes, state, and upstream dependencies to understand the replacement?

**Answer:**

Use `terraform show` on saved plans, provider docs/schema, state inspection, config/git diff, and previous plans. Determine whether replacement is real, a provider behaviour change, or unintended drift.

### Q52.5 — Senior Trade-off / Edge Case

**Question:** What CI checks should gate a plan containing destroys/replacements in production?

**Answer:**

Production CI should require saved-plan review, policy checks for destroy/replace, ownership approval, provider lockfiles, and separate plan/apply identities. High-risk replacements should need explicit human approval.

---

## Q53 — State locking

### Q53.1 — Foundation

**Question:** Why does Terraform state need locking?

**Answer:**

State locking prevents two Terraform writers from concurrently reading the same old state and then overwriting each other's updates.

### Q53.2 — Internals / Mechanism

**Question:** Explain the race conditions that can occur if two applies mutate the same state concurrently.

**Answer:**

Without locking, concurrent applies can create duplicate/conflicting resources and produce state that reflects only one writer's view, breaking ownership and dependency tracking.

### Q53.3 — Production Scenario

**Question:** Two pipelines are waiting on a lock and one lock appears stale. What is your response?

**Answer:**

If a lock appears stale, first identify the lock holder/run ID and whether the pipeline/process is still executing. Never force-unlock solely because it has been held 'too long'.

### Q53.4 — Troubleshooting / Failure

**Question:** How would you confirm whether an apply is still active before force-unlocking, and what evidence would you preserve?

**Answer:**

Check CI job state, process/cloud activity, backend lock metadata, Terraform logs, and operator communication. If confirmed abandoned, back up state and force-unlock using the exact lock ID.

### Q53.5 — Senior Trade-off / Edge Case

**Question:** How would you design pipeline serialization and workspace/state ownership to make force-unlock almost unnecessary?

**Answer:**

Serialize applies per state, use remote backends with reliable locks, cancel pipelines cleanly, and split state by ownership. Force-unlock should be a rare break-glass action with audit.

---

## Q54 — Secrets in Terraform

### Q54.1 — Foundation

**Question:** Does `sensitive = true` make a Terraform secret secure?

**Answer:**

`sensitive = true` mainly suppresses display in Terraform CLI/UI contexts. It does not encrypt or remove the value from state, and providers/downstream APIs may still receive it in plaintext.

### Q54.2 — Internals / Mechanism

**Question:** Explain where sensitive values can still appear: state, provider APIs, logs, plans, and downstream systems.

**Answer:**

Secrets can leak through state versions, plan files, logs, CI environment variables, provider debug output, or resource attributes. Remote-state access therefore becomes secret access.

### Q54.3 — Production Scenario

**Question:** A secret was committed to state and later rotated. What exposure remains?

**Answer:**

If a secret was stored in state, rotate/revoke it first. Then restrict backend access, inspect logs/artifacts, and consider historical state versions/backups as potentially containing the old value.

### Q54.4 — Troubleshooting / Failure

**Question:** How would you rotate credentials, secure remote state, limit access, scrub logs, and assess whether historical state versions contain the value?

**Answer:**

Use encrypted remote state, least privilege, secret managers, short-lived credentials, sanitized CI logs, and controlled plan artifacts. Do not casually rewrite state history without understanding recovery/audit impact.

### Q54.5 — Senior Trade-off / Edge Case

**Question:** When should Terraform reference a secret manager rather than manage secret values directly?

**Answer:**

Prefer Terraform to provision secret containers/policies and reference secret identifiers, while runtime systems fetch values directly. Manage secret material in Terraform only when no safer integration exists.

---

## Q55 — Partial Terraform apply failure

### Q55.1 — Foundation

**Question:** Terraform creates 15 resources and fails on resource 16. What state are you left in?

**Answer:**

Terraform records successful resource changes as it progresses, so after a partial failure state should generally include operations that completed and were acknowledged before the failure.

### Q55.2 — Internals / Mechanism

**Question:** Explain how successful operations are recorded and how a subsequent plan reconciles partial progress.

**Answer:**

On the next plan Terraform refreshes remote objects and computes what remains. However, provider/API failures can leave ambiguous cases where an external side effect occurred but state recording failed.

### Q55.3 — Production Scenario

**Question:** The failure occurs after an external side effect but before the provider records state correctly. What complications arise?

**Answer:**

If an API created a resource but Terraform failed before storing its ID, a retry may attempt a duplicate or encounter 'already exists'. Verify the real system before repeating the apply.

### Q55.4 — Troubleshooting / Failure

**Question:** How would you inspect real infrastructure versus state and recover without blindly re-running the apply?

**Answer:**

Back up state, inspect provider logs and cloud/API resources, refresh/plan, then import or reconcile ambiguous resources. Avoid hand-editing state when supported import/state commands can preserve structure safely.

### Q55.5 — Senior Trade-off / Edge Case

**Question:** What provider and module design choices improve idempotency and recovery from partial failures?

**Answer:**

Design modules/resources for idempotent APIs, deterministic names where sensible, and small blast radius. Providers should handle eventual consistency and partial creation robustly; tests should include failure injection.

---

## Q56 — Terraform at organizational scale

### Q56.1 — Foundation

**Question:** How would you manage Terraform for hundreds of production resources across many teams?

**Answer:**

At scale, use clear state/module ownership, remote backends, locked provider versions, CI-only applies, reusable modules, policy-as-code, reviewable plans, drift detection, and well-defined interfaces between stacks.

### Q56.2 — Internals / Mechanism

**Question:** Explain module boundaries, remote state, CI/CD, policy-as-code, provider/version pinning, and ownership.

**Answer:**

A shared module is source code, not a magic global object. Version it, test it, and let consumers upgrade intentionally. Remote-state/data dependencies should be minimized and explicit.

### Q56.3 — Production Scenario

**Question:** One shared module change can alter dozens of stacks. How do you reduce blast radius?

**Answer:**

For a module affecting many stacks, release a new version, test it in representative environments, canary upgrades, inspect plans, and avoid automatic fleet-wide version jumps.

### Q56.4 — Troubleshooting / Failure

**Question:** How would you stage validation, canary applies, policy checks, drift detection, and rollback/recovery for infrastructure changes?

**Answer:**

Use static validation, unit/module tests where useful, integration environments, policy checks, saved plans, staged applies, post-apply verification, and clear recovery paths. Track which stacks consume each module version.

### Q56.5 — Senior Trade-off / Edge Case

**Question:** What should be centralized versus delegated to product teams in a mature platform organization?

**Answer:**

Centralize platform standards, security/policy, module frameworks, and CI patterns; delegate workload-specific resources to owning teams. Over-centralization creates bottlenecks, while total decentralization creates inconsistency and risk.

---

# 08 — Observability

## Q57 — Metrics vs logs vs traces

### Q57.1 — Foundation

**Question:** When would you use metrics, logs, and traces?

**Answer:**

Metrics summarize numerical behaviour over time, logs capture discrete events/context, and traces show a request's path across components. Use them together rather than treating one as universally best.

### Q57.2 — Internals / Mechanism

**Question:** Explain the strengths, costs, and information model of each telemetry type.

**Answer:**

Metrics are cheap for trends/alerts, logs provide rich event detail, and traces expose causality/latency across distributed calls. Each has different retention, cardinality, and cost characteristics.

### Q57.3 — Production Scenario

**Question:** A service has high latency but no obvious errors. Which signal do you start with and why?

**Answer:**

For high latency, start with user-facing latency/error metrics to scope impact, then traces to find slow spans, then logs/component metrics for the suspected service. The exact order depends on available signal quality.

### Q57.4 — Troubleshooting / Failure

**Question:** How would you combine RED metrics, traces, structured logs, and infrastructure metrics to move from symptom to cause?

**Answer:**

Use RED at the edge, traces to identify the slow hop, dependency/infrastructure metrics to test saturation, and structured logs for request/error detail. Correlate with trace/request IDs.

### Q57.5 — Senior Trade-off / Edge Case

**Question:** What telemetry would you deliberately not collect because of cost, privacy, or cardinality risk?

**Answer:**

Do not put secrets/PII in telemetry, avoid unbounded labels, and sample high-volume traces/logs. Collect signals that answer operational questions; more telemetry is not automatically better observability.

---

## Q58 — RED and USE

### Q58.1 — Foundation

**Question:** Explain the RED and USE methods.

**Answer:**

RED means Rate, Errors, Duration and is useful for request-driven services. USE means Utilization, Saturation, Errors and is useful for resources such as CPU, disks, pools, and network links.

### Q58.2 — Internals / Mechanism

**Question:** Which systems are better suited to each method and why?

**Answer:**

RED tells you what users/work is experiencing; USE tells you whether underlying resources are near capacity or failing. Together they connect symptoms to resource causes.

### Q58.3 — Production Scenario

**Question:** An API is slow but CPU is low. How would RED and USE guide different parts of your investigation?

**Answer:**

If API latency is high but CPU is low, RED confirms which requests are affected; USE then checks other resources such as thread pools, DB connections, disk, network, queues, or dependency capacity.

### Q58.4 — Troubleshooting / Failure

**Question:** How would you map rate/errors/duration and utilization/saturation/errors across app, node, network, and storage layers?

**Answer:**

Map RED to ingress/service/dependencies and USE to node CPU, memory pressure, disk queues, network drops, connection pools, and worker queues. Compare affected time windows and dimensions.

### Q58.5 — Senior Trade-off / Edge Case

**Question:** How do you avoid turning RED/USE into dashboard checklists that still fail to explain user impact?

**Answer:**

Frameworks are prompts, not diagnostic scripts. Start with user impact and hypotheses; do not build dashboards containing every RED/USE metric without clear ownership and actionability.

---

## Q59 — P99 up, P50 stable

### Q59.1 — Foundation

**Question:** P99 latency doubles while P50 stays unchanged. What does that tell you?

**Answer:**

Stable P50 with worse P99 means the typical request remains normal while a small tail has become much slower. This often indicates localized contention, retries, specific routes/tenants/nodes, or rare dependency paths.

### Q59.2 — Internals / Mechanism

**Question:** Explain percentiles and why tail latency can change without moving the median.

**Answer:**

Percentiles describe distribution rather than average. P99 can move dramatically when the slowest ~1% changes even if the median is unchanged.

### Q59.3 — Production Scenario

**Question:** Only a small subset of requests is slow after a deployment. What dimensions would you segment by?

**Answer:**

Segment by endpoint, version, AZ, node/Pod, customer class, request size, cache hit/miss, and downstream path. Look for the smallest dimension explaining the tail.

### Q59.4 — Troubleshooting / Failure

**Question:** How would you use traces, endpoint/version/zone/node dimensions, queueing metrics, and dependency timing to isolate the tail?

**Answer:**

Use trace exemplars for slow requests, compare span timing, queue/pool waits, GC, retries, node placement, and dependencies. Avoid aggregating across unlike request types.

### Q59.5 — Senior Trade-off / Edge Case

**Question:** What SLO and alerting approach would detect harmful tail latency without overreacting to tiny sample noise?

**Answer:**

Alert on user-relevant tail latency with sufficient traffic/sample windows and SLO context. Very low-volume endpoints may need histogram windows or separate thresholds to avoid noisy percentile math.

---

## Q60 — Average latency looks healthy

### Q60.1 — Foundation

**Question:** Why can average latency look healthy while users report slowness?

**Answer:**

Averages hide skew and outliers. A small customer segment can suffer severe latency while the global mean remains healthy, especially when high-volume fast requests dominate.

### Q60.2 — Internals / Mechanism

**Question:** Explain skew, outliers, percentiles, aggregation windows, and request weighting.

**Answer:**

Mean latency weights every request but does not reveal distribution. Percentiles and segmented histograms expose tail behaviour and cohort-specific degradation.

### Q60.3 — Production Scenario

**Question:** One customer cohort sees 3-second latency while global average is 150 ms. How do you expose that?

**Answer:**

Break metrics down by bounded, operationally meaningful dimensions such as region, endpoint, plan tier, version, or shard—not arbitrary user IDs. Then compare affected cohorts.

### Q60.4 — Troubleshooting / Failure

**Question:** How would you slice telemetry by tenant/region/endpoint/version while managing cardinality?

**Answer:**

Use trace/log queries for high-cardinality identifiers while keeping metrics labels controlled. Link metrics to exemplars/traces so you can pivot into per-request detail without exploding metric cardinality.

### Q60.5 — Senior Trade-off / Edge Case

**Question:** What aggregation strategy gives leadership simple KPIs without hiding serious localized failures?

**Answer:**

Leadership can see global SLO/percentiles plus worst-cohort indicators, while operators retain segmented dashboards. A simple KPI should never be the only lens used for incident detection.

---

## Q61 — High-cardinality metrics

### Q61.1 — Foundation

**Question:** What is metric cardinality?

**Answer:**

Cardinality is the number of unique label combinations in a metric. Unbounded dimensions such as user ID, request ID, URL with IDs, or raw error text can create millions of time series.

### Q61.2 — Internals / Mechanism

**Question:** Why do dimensions such as user ID or request ID create operational and cost problems?

**Answer:**

Each time series consumes memory/index/storage and query cost. High churn can overload Prometheus/remote backends even if scrape volume looks modest.

### Q61.3 — Production Scenario

**Question:** A team adds `customer_id` to every Prometheus metric and the monitoring system degrades. What happened?

**Answer:**

Adding `customer_id` creates a series per customer × every other label combination. Remove/drop the label at ingestion, aggregate where possible, and protect the metrics backend first.

### Q61.4 — Troubleshooting / Failure

**Question:** How would you identify the cardinality explosion, mitigate it quickly, and preserve diagnostic value through logs/traces instead?

**Answer:**

Use TSDB cardinality tools/top label counts, identify the offending metric/release, relabel/drop or roll back, and move per-customer/request detail to logs/traces. Preserve coarse service metrics.

### Q61.5 — Senior Trade-off / Edge Case

**Question:** What rules would you establish for labels, exemplars, aggregation, and retention?

**Answer:**

Define label allowlists, bound values, review metric schemas, enforce budgets, and use exemplars or logs for unique IDs. Cardinality should be treated as an API/design concern.

---

## Q62 — No useful logs during failure

### Q62.1 — Foundation

**Question:** Production is failing but application logs show nothing unusual. What do you do?

**Answer:**

First verify where the failure occurs. If the application never receives the request, its logs can be perfectly normal while users fail at DNS, LB, proxy, network, auth, or another dependency.

### Q62.2 — Internals / Mechanism

**Question:** Explain why absence of logs does not mean absence of failure.

**Answer:**

Logs are only emitted by instrumented code paths. Kernel drops, process kills, proxy-generated errors, missing logging, or sampling can create silent failures from the application's perspective.

### Q62.3 — Production Scenario

**Question:** Metrics show 5xx responses generated by a proxy before requests reach the app. How does that change your investigation?

**Answer:**

If a proxy generates 5xx before forwarding, pivot to proxy/load-balancer metrics and access logs, target health, routing, and network data instead of searching application logs harder.

### Q62.4 — Troubleshooting / Failure

**Question:** How would you use traces, load-balancer/proxy logs, kernel/network telemetry, dependency metrics, and synthetic tests?

**Answer:**

Use edge metrics/logs, traces with missing-span analysis, system/network telemetry, synthetic probes, and dependency data. Compare a known-good and failing request to locate the first missing/slow hop.

### Q62.5 — Senior Trade-off / Edge Case

**Question:** What logging contract would you establish so critical state transitions and failures are observable without excessive noise?

**Answer:**

Log important lifecycle/error decisions structurally, propagate correlation IDs, and monitor 'absence of expected events' through metrics. Do not rely on log volume itself as a health signal.

---

## Q63 — Distributed tracing

### Q63.1 — Foundation

**Question:** How does distributed tracing help diagnose microservices?

**Answer:**

Distributed tracing follows one logical request across services using trace/span context, showing timing, hierarchy, errors, retries, and service relationships.

### Q63.2 — Internals / Mechanism

**Question:** Explain trace IDs, spans, parent/child relationships, context propagation, sampling, and baggage.

**Answer:**

A trace contains spans with start/end times and attributes; context propagation links children to parents. Sampling controls cost, while baggage can propagate selected request context but must be bounded.

### Q63.3 — Production Scenario

**Question:** A request crosses eight services and takes four seconds. How do you identify the dominant contributor?

**Answer:**

For a four-second trace, inspect the critical path and self/duration of spans. Identify whether time is spent inside one service, waiting for dependencies, retries, queues, or parallel branches.

### Q63.4 — Troubleshooting / Failure

**Question:** How would you distinguish service time, queue time, retries, network delay, and missing spans?

**Answer:**

Look for repeated spans/retries, gaps before child spans, queue-consumer timing, network/connect timing, and missing instrumentation. Correlate the slow trace with host/service metrics and logs.

### Q63.5 — Senior Trade-off / Edge Case

**Question:** What sampling strategy preserves incident value while controlling cost and avoiding biased traces?

**Answer:**

Use head sampling for predictable cost plus tail/error/latency-biased strategies if the platform supports it. Preserve rare failures without collecting every normal request; avoid sampling rules that hide the very incidents you need.

---

## Q64 — Alert design

### Q64.1 — Foundation

**Question:** CPU is 95% for ten minutes. Should that page an SRE?

**Answer:**

Not necessarily. High CPU is a resource condition; paging should depend on likely/actual user impact or imminent exhaustion. If latency/errors/SLO remain healthy, it may warrant observation or a ticket.

### Q64.2 — Internals / Mechanism

**Question:** Explain the difference between symptom alerts and cause/resource alerts.

**Answer:**

Symptom alerts reflect customer outcomes such as error/latency/SLO burn. Cause alerts reflect resource states. Cause alerts are useful when they reliably predict urgent failure and have an actionable response.

### Q64.3 — Production Scenario

**Question:** CPU is 95% but latency and error rate are normal. What action, if any, is appropriate?

**Answer:**

If CPU is 95% but service behaviour is healthy, check saturation/throttling/headroom and trend. Scale proactively if needed, but avoid waking someone solely because a threshold crossed.

### Q64.4 — Troubleshooting / Failure

**Question:** How would you use SLO burn rate, saturation trends, queue depth, and user impact to decide paging versus ticketing?

**Answer:**

Combine SLO burn, latency/errors, CPU saturation/throttling, queue depth, and capacity forecasts. Page when immediate action can protect users; ticket chronic inefficiency or capacity planning.

### Q64.5 — Senior Trade-off / Edge Case

**Question:** What characteristics make an alert actionable, low-noise, and safe for an on-call rotation?

**Answer:**

An actionable page has clear ownership, urgency, likely customer consequence, diagnostic context, and a known first response. If nobody knows what to do at 3 AM, it probably should not page.

---

# 09 — SLI / SLO / Reliability

## Q65 — SLI

### Q65.1 — Foundation

**Question:** What is an SLI?

**Answer:**

An SLI is a quantitative measure of service behaviour relevant to users, such as successful request ratio, latency under a threshold, freshness, correctness, or durability.

### Q65.2 — Internals / Mechanism

**Question:** Explain how an SLI is derived from user-visible behaviour rather than internal component health.

**Answer:**

A good SLI is measured at a boundary close to user experience. Internal CPU or Pod readiness may support diagnosis, but they are usually poor availability SLIs because users can fail while they look healthy.

### Q65.3 — Production Scenario

**Question:** For a payment API, which candidate SLIs would you consider and which would you reject?

**Answer:**

For payments, consider valid requests successfully accepted/committed, end-to-end latency, duplicate/correctness rate, and perhaps processing freshness. Exclude malformed client requests if they are not a service failure.

### Q65.4 — Troubleshooting / Failure

**Question:** How would you validate that the SLI query correctly handles retries, partial failures, client errors, and missing telemetry?

**Answer:**

Validate query semantics against raw events: retries, duplicate requests, async completion, client cancellations, missing telemetry, and status-code mapping. Test known incidents to ensure the SLI moved as expected.

### Q65.5 — Senior Trade-off / Edge Case

**Question:** What makes an SLI stable enough for long-term governance while still representing changing user journeys?

**Answer:**

Keep definitions versioned and reviewable, with stable business meaning. If product flows change, migrate the SLI intentionally rather than silently changing queries and destroying historical comparability.

---

## Q66 — SLO vs SLA

### Q66.1 — Foundation

**Question:** What is the difference between an SLO and an SLA?

**Answer:**

An SLO is an internal reliability objective for an SLI over a window; an SLA is a contractual/business commitment that may include remedies or penalties. SLOs are usually stricter than SLAs.

### Q66.2 — Internals / Mechanism

**Question:** Explain internal reliability targets, contractual commitments, and error budgets.

**Answer:**

The gap provides operating margin. Error budgets derived from SLOs guide engineering trade-offs, while SLA breaches are external contractual events and should not be the daily reliability target.

### Q66.3 — Production Scenario

**Question:** A service has a 99.9% SLO but a 99.5% SLA. Why might that be intentional?

**Answer:**

A 99.9% SLO with 99.5% SLA gives the engineering team buffer before customers reach contractual impact and supports proactive reliability work.

### Q66.4 — Troubleshooting / Failure

**Question:** How would you handle a situation where internal telemetry says the SLO is met but customers claim SLA impact?

**Answer:**

If internal telemetry says SLO is met but customers report failures, investigate measurement coverage and SLA definition. The SLI may miss a cohort, endpoint, geography, or correctness failure.

### Q66.5 — Senior Trade-off / Edge Case

**Question:** What organizational behaviour should SLOs drive beyond simply reporting a percentage?

**Answer:**

SLOs should influence release pace, reliability investment, prioritization, and incident review. A dashboard percentage that never changes engineering decisions is not delivering much value.

---

## Q67 — Choosing 99.9% vs 99.99%

### Q67.1 — Foundation

**Question:** Why might a team choose 99.9% instead of 99.99%?

**Answer:**

Choose an SLO based on user/business need and achievable cost. 99.99% allows roughly one-tenth the error budget of 99.9% and often requires stronger dependencies, redundancy, testing, and operations.

### Q67.2 — Internals / Mechanism

**Question:** Translate both targets into engineering cost, allowable failure, and dependency requirements.

**Answer:**

Higher reliability increases engineering and opportunity cost: more redundancy, conservative changes, capacity, failover, on-call maturity, and dependency requirements. Each extra nine can be disproportionately expensive.

### Q67.3 — Production Scenario

**Question:** A low-revenue internal service requests four nines because 'reliability is important'. How do you challenge that?

**Answer:**

Ask what user harm occurs at 99.9%, what business value four nines creates, and whether dependencies can support it. Reliability targets should solve a real problem, not signal prestige.

### Q67.4 — Troubleshooting / Failure

**Question:** How would you estimate whether architecture, staffing, dependency SLOs, and operational maturity can support the target?

**Answer:**

Model historical availability, incident frequency, dependency SLOs, maintenance, architecture, and staffing. If the target is routinely impossible, it produces bad incentives rather than better reliability.

### Q67.5 — Senior Trade-off / Edge Case

**Question:** What business evidence should justify increasing an SLO, and when should you deliberately keep it lower?

**Answer:**

Raise the SLO when user/revenue/regulatory evidence justifies it and the system can support it. Keep it lower when extra reliability costs more than the user benefit or blocks valuable product work.

---

## Q68 — Error budgets

### Q68.1 — Foundation

**Question:** What is an error budget?

**Answer:**

An error budget is the amount of unreliability allowed by an SLO over a measurement window. For a 99.9% SLO, roughly 0.1% of eligible events/time can fail.

### Q68.2 — Internals / Mechanism

**Question:** Explain how it connects SLO targets to allowed unreliability and delivery velocity.

**Answer:**

It converts reliability into a consumable budget. Healthy budget supports normal delivery; rapid exhaustion signals that change velocity or reliability work may need adjustment.

### Q68.3 — Production Scenario

**Question:** A team burns 80% of its monthly budget in two days. What should change?

**Answer:**

If 80% burns in two days, stabilize first, identify the incident/systemic cause, and tighten risky releases until burn normalizes. Do not wait until the last 20% is gone.

### Q68.4 — Troubleshooting / Failure

**Question:** How would you distinguish a one-off incident from a structural reliability problem and decide release policy?

**Answer:**

Compare whether burn came from one resolved event or ongoing defects. Use burn-rate trends, recurrence, change failure, and known risks to decide freeze, partial restriction, or targeted remediation.

### Q68.5 — Senior Trade-off / Edge Case

**Question:** What error-budget policy balances reliability and product delivery without becoming a rigid freeze mechanism?

**Answer:**

Use policy as a decision framework, not punishment. Allow exceptions with explicit risk ownership, distinguish service classes, and restore delivery when evidence shows reliability is under control.

---

## Q69 — Availability for a payment API

### Q69.1 — Foundation

**Question:** How would you define availability for a payment API?

**Answer:**

For a payment API, define availability around valid user payment intents receiving a correct, timely, unambiguous outcome—not merely HTTP 200 responses.

### Q69.2 — Internals / Mechanism

**Question:** Explain numerator/denominator choices and which requests should count.

**Answer:**

Choose numerator/denominator carefully: exclude invalid client requests, include server/dependency failures, define latency boundaries, and consider whether asynchronous acceptance counts as successful availability.

### Q69.3 — Production Scenario

**Question:** A request times out client-side but the server later completes the payment. Is that available?

**Answer:**

If a client times out but the payment later completes, the user experienced an ambiguous failure. Depending on product contract, that may count as unavailable even though the backend completed successfully.

### Q69.4 — Troubleshooting / Failure

**Question:** How would you handle idempotency, async processing, retries, partial success, and duplicate submissions in the SLI?

**Answer:**

Use idempotency keys and transaction state to distinguish accepted, committed, duplicate, failed, and unknown outcomes. Measure from the user-facing gateway plus durable business state where necessary.

### Q69.5 — Senior Trade-off / Edge Case

**Question:** What user outcome should ultimately define availability for a transactional system?

**Answer:**

The ultimate SLI should reflect whether a user can safely complete the intended transaction without duplicate charge or uncertainty. Correctness is as important as raw endpoint reachability.

---

## Q70 — Dependency SLO mismatch

### Q70.1 — Foundation

**Question:** Your service has a 99.95% SLO but depends on a service with a 99.9% SLO. What is the issue?

**Answer:**

A service cannot simply promise higher end-to-end availability than a mandatory weaker dependency unless architecture masks dependency failures through caching, redundancy, degradation, or decoupling.

### Q70.2 — Internals / Mechanism

**Question:** Explain how dependency reliability composes and why your SLO may be mathematically or operationally impossible.

**Answer:**

Serial dependencies roughly compound availability. A 99.9% mandatory dependency can consume more error budget than a 99.95% service is allowed, making the target structurally inconsistent.

### Q70.3 — Production Scenario

**Question:** The dependency is not replaceable. What architectural options do you have?

**Answer:**

Options include alternate providers, cached/stale data, asynchronous workflows, local fallback, bulkheads, reduced functionality, or renegotiating the SLO. The right choice depends on business semantics.

### Q70.4 — Troubleshooting / Failure

**Question:** How would you test whether caching, graceful degradation, retries, hedging, or asynchronous decoupling can protect your SLO?

**Answer:**

Failure-test the dependency and measure whether fallback actually preserves the user SLI. Validate cache age, queue backlog, recovery surge, data correctness, and retry/load behaviour.

### Q70.5 — Senior Trade-off / Edge Case

**Question:** When should you renegotiate your own SLO instead of adding complexity to mask a weaker dependency?

**Answer:**

Do not add complex resilience solely to defend an unrealistic number. If the product genuinely cannot function without the weaker dependency, align the SLO and communicate the constraint.

---

## Q71 — SLO violation alerting

### Q71.1 — Foundation

**Question:** Why is paging on every SLO violation a bad idea?

**Answer:**

Paging on every instantaneous SLO miss creates noise because SLOs are windowed objectives. A brief spike may consume negligible budget and require no human action.

### Q71.2 — Internals / Mechanism

**Question:** Explain short-window noise, long-window significance, and burn-rate concepts.

**Answer:**

Burn rate measures how fast the budget is being consumed relative to the allowed rate. Multi-window alerts catch both severe fast failures and persistent slow degradation.

### Q71.3 — Production Scenario

**Question:** A service briefly exceeds its error target for five minutes but has abundant monthly budget. Should anyone be paged?

**Answer:**

A five-minute spike with abundant budget and full recovery may only need recording/analysis. Page if the burn rate and user impact indicate the budget will be exhausted quickly.

### Q71.4 — Troubleshooting / Failure

**Question:** How would you design multi-window burn-rate alerts to catch fast and slow burns?

**Answer:**

Use a short+long window pair for fast burn and another pair for slow burn, with thresholds tied to budget consumption. The exact numbers should reflect SLO window and on-call response needs.

### Q71.5 — Senior Trade-off / Edge Case

**Question:** What secondary signals would you include to prevent both alert fatigue and silent budget exhaustion?

**Answer:**

Supplement burn alerts with traffic validity, major correctness/security events, and hard capacity risks. SLO alerting is powerful but cannot represent every kind of urgent incident.

---

## Q72 — Burn-rate alerting

### Q72.1 — Foundation

**Question:** What is SLO burn rate?

**Answer:**

Burn rate is current error-budget consumption speed divided by the sustainable rate. `1x` would consume the budget exactly over the SLO window; `10x` consumes it ten times faster.

### Q72.2 — Internals / Mechanism

**Question:** Explain what 1x, 10x, or 100x burn means relative to the budget.

**Answer:**

A very high burn predicts rapid budget exhaustion and needs immediate response; a modest >1x burn can still be serious if sustained for hours or days.

### Q72.3 — Production Scenario

**Question:** How would you interpret a fast 50x burn versus a persistent 2x burn?

**Answer:**

A 50x burn is an acute incident; page quickly using a short window confirmed by a longer one. A persistent 2x burn may need a slower alert/ticket before it silently exhausts the monthly budget.

### Q72.4 — Troubleshooting / Failure

**Question:** Design a multi-window alert strategy that detects both catastrophic and slow reliability loss.

**Answer:**

Design multiple window pairs, for example short/long confirmation for fast and slow burns, and express thresholds as allowed budget consumed. Test against historical incidents and noise.

### Q72.5 — Senior Trade-off / Edge Case

**Question:** What are the trade-offs between mathematical precision, operational simplicity, and explainability to on-call engineers?

**Answer:**

Mathematical sophistication should not make alerts incomprehensible. Prefer a small, documented set of burn alerts that on-call engineers understand and can act on.

---

# 10 — Programming / Concurrency

## Q73 — Deadlock

### Q73.1 — Foundation

**Question:** What is a deadlock? Draw a simple example.

**Answer:**

A deadlock occurs when participants wait forever for resources held by one another. A simple example is Thread A holding lock X and waiting for Y while Thread B holds Y and waits for X.

### Q73.2 — Internals / Mechanism

**Question:** Explain the resource dependency cycle and how threads become permanently blocked.

**Answer:**

Each thread is blocked because progress depends on the other releasing a resource, but neither can reach the release point. The wait-for graph contains a cycle.

### Q73.3 — Production Scenario

**Question:** A Java service stops making progress while CPU remains low. What evidence would make deadlock likely?

**Answer:**

Low CPU plus no request progress, increasing blocked threads, and stable memory can indicate deadlock. Thread dumps showing reciprocal lock ownership provide strong evidence.

### Q73.4 — Troubleshooting / Failure

**Question:** How would you use thread dumps, lock ownership, JVM tools, and application telemetry to confirm the deadlock?

**Answer:**

Capture multiple thread dumps, inspect `BLOCKED` states and owned/waited locks, use JVM tooling/profilers, and correlate with the code path and request timeline. Preserve dumps before restarting.

### Q73.5 — Senior Trade-off / Edge Case

**Question:** What design patterns prevent deadlocks, and what trade-offs come with lock ordering, timeouts, or lock-free structures?

**Answer:**

Prevent with consistent lock ordering, reduced shared mutable state, bounded lock acquisition, immutable/message-passing designs, or higher-level concurrency primitives. Timeouts avoid infinite blocking but do not fix data-consistency design.

---

## Q74 — Deadlock conditions

### Q74.1 — Foundation

**Question:** What four conditions are required for deadlock?

**Answer:**

The Coffman conditions are mutual exclusion, hold-and-wait, no preemption, and circular wait. All four must hold for a classic resource deadlock.

### Q74.2 — Internals / Mechanism

**Question:** Explain mutual exclusion, hold-and-wait, no preemption, and circular wait.

**Answer:**

Mutual exclusion makes a resource single-owner; hold-and-wait retains resources while requesting more; no preemption prevents forced release; circular wait creates the dependency cycle.

### Q74.3 — Production Scenario

**Question:** Which condition would you most realistically break in typical application code?

**Answer:**

In application code, enforcing a global lock acquisition order is often the most practical way to break circular wait. Reducing nested locks is even better.

### Q74.4 — Troubleshooting / Failure

**Question:** Given a production locking design, how would you identify whether a cycle can form before it happens?

**Answer:**

Model lock-order graphs, review nested critical sections, use static/runtime lock diagnostics where available, and stress concurrent paths. Production thread dumps can reveal unexpected orders.

### Q74.5 — Senior Trade-off / Edge Case

**Question:** How would you document and enforce concurrency invariants across a large codebase with many contributors?

**Answer:**

Document lock hierarchy, encapsulate locking behind APIs, keep critical sections small, and enforce conventions in code review/tests. Better still, design components so fewer locks are required.

---

## Q75 — Race condition vs deadlock

### Q75.1 — Foundation

**Question:** What is the difference between a race condition and a deadlock?

**Answer:**

A race condition is a correctness bug whose result depends on timing/interleaving. A deadlock is a progress failure where participants cannot continue because of cyclic waiting.

### Q75.2 — Internals / Mechanism

**Question:** Explain how timing affects correctness in a race while deadlock affects progress.

**Answer:**

Races often allow the program to continue with wrong state; deadlocks stop affected work. Both arise from concurrency but require different detection and prevention techniques.

### Q75.3 — Production Scenario

**Question:** A counter occasionally loses updates but the service never hangs. What class of bug is likely?

**Answer:**

Lost increments with no hang indicate a race such as non-atomic read-modify-write. Verify whether multiple threads/processes update shared state without synchronization.

### Q75.4 — Troubleshooting / Failure

**Question:** How would you reproduce, instrument, and prove a race that occurs once in a million requests?

**Answer:**

Create high-concurrency stress tests, add counters/invariants, use thread sanitizers where supported, reduce nondeterminism, and inspect atomicity boundaries. Reproduce around the smallest shared state.

### Q75.5 — Senior Trade-off / Edge Case

**Question:** When do atomics, locks, immutability, actor models, or database constraints provide the cleanest fix?

**Answer:**

Use immutable data/message passing when possible, atomics for simple independent state, locks for compound invariants, and database constraints/transactions when the invariant belongs in persistent data.

---

## Q76 — Thread safety

### Q76.1 — Foundation

**Question:** What makes code thread-safe?

**Answer:**

Thread-safe code preserves its invariants under valid concurrent execution. It usually controls shared mutable state through immutability, confinement, atomics, synchronization, or concurrency-safe abstractions.

### Q76.2 — Internals / Mechanism

**Question:** Explain synchronization, atomicity, visibility, immutability, and shared mutable state.

**Answer:**

Correctness needs atomicity and visibility, not just 'no exceptions'. Language memory models define when writes by one thread become visible to others and which operations can reorder.

### Q76.3 — Production Scenario

**Question:** A singleton cache works in tests but corrupts data under production load. What do you inspect?

**Answer:**

A singleton cache that corrupts under load may use non-thread-safe collections, check-then-act races, unsafe publication, mutable shared entries, or insufficient synchronization.

### Q76.4 — Troubleshooting / Failure

**Question:** How would you use stress tests, thread analyzers, synchronization review, and memory-model reasoning to find the bug?

**Answer:**

Stress the cache with concurrent operations, capture failures/invariants, inspect synchronization and publication, use runtime concurrency tools, and reduce to a minimal race. Do not add random locks until the invariant is understood.

### Q76.5 — Senior Trade-off / Edge Case

**Question:** What design choices reduce the need for explicit locking altogether?

**Answer:**

Favor immutable values, concurrent collections, ownership/confinement, and message passing. Locks remain appropriate for compound invariants, but large shared critical sections reduce throughput and increase deadlock risk.

---

## Q77 — Lost update / database concurrency

### Q77.1 — Foundation

**Question:** How can two concurrent writers cause a lost update?

**Answer:**

A lost update happens when two writers read the same old value, independently compute new values, and the later write overwrites the earlier one without detecting the conflict.

### Q77.2 — Internals / Mechanism

**Question:** Explain optimistic locking, pessimistic locking, MVCC, compare-and-set, and version columns.

**Answer:**

Optimistic locking uses versions/compare-and-set; pessimistic locking serializes access; MVCC gives snapshots; database constraints can enforce invariants even across application replicas.

### Q77.3 — Production Scenario

**Question:** Two service instances update the same order nearly simultaneously. How do you preserve correctness?

**Answer:**

For concurrent order updates, use a version column/conditional update when conflicts are rare, or appropriate row locking/transaction isolation when the invariant requires serialization. Make retries idempotent.

### Q77.4 — Troubleshooting / Failure

**Question:** How would you reproduce the race, choose an isolation/control mechanism, and prove the fix under concurrency?

**Answer:**

Reproduce with concurrent transactions, inspect isolation and SQL, add version/constraint checks, and test conflict/retry behaviour. Verify the invariant under load, not only that exceptions disappear.

### Q77.5 — Senior Trade-off / Edge Case

**Question:** When is application-level locking inferior to letting the database enforce the invariant?

**Answer:**

Let the database enforce data invariants when possible because it sees all writers. Application locks can fail across instances and are weaker unless backed by a durable coordination mechanism.

---

## Q78 — Distributed locks

### Q78.1 — Foundation

**Question:** When would you use a distributed lock?

**Answer:**

Use a distributed lock when multiple independent processes must serialize access to a resource and no simpler atomic database/queue/ownership primitive can enforce the invariant.

### Q78.2 — Internals / Mechanism

**Question:** Explain ownership, lease expiry, fencing tokens, clock/partition concerns, and failure modes.

**Answer:**

A correct design must handle lease expiry, process pause, network partitions, duplicate ownership, and stale holders. A lease alone does not guarantee an old holder stops acting.

### Q78.3 — Production Scenario

**Question:** A lock holder pauses for longer than its lease, resumes, and writes stale data. What went wrong?

**Answer:**

If a paused holder resumes after its lease expired, it may still write. Use monotonically increasing fencing tokens that the protected resource validates, rejecting stale owners.

### Q78.4 — Troubleshooting / Failure

**Question:** How would you design the protected resource so an expired lock holder cannot corrupt state?

**Answer:**

Test process pauses, partitions, lease expiry, clock anomalies, and lock-service failure. Verify the downstream resource enforces ownership/version rather than trusting the client.

### Q78.5 — Senior Trade-off / Edge Case

**Question:** When should you redesign the workflow to avoid distributed locks entirely?

**Answer:**

Prefer partitioned ownership, queues, unique constraints, compare-and-swap, or database transactions when they fit. Distributed locks add another availability/consistency dependency and are easy to misuse.

---

## Q79 — Idempotency

### Q79.1 — Foundation

**Question:** What is idempotency and why does it matter in distributed systems?

**Answer:**

An idempotent operation can be repeated with the same logical request without producing additional unintended effects. It is essential because clients retry after timeouts and networks duplicate uncertainty.

### Q79.2 — Internals / Mechanism

**Question:** Explain request keys, deduplication state, replay semantics, and response persistence.

**Answer:**

A common API design accepts an idempotency key, stores the request fingerprint/status/result, and returns the same result for duplicate keys. Concurrent duplicates require atomic reservation/uniqueness.

### Q79.3 — Production Scenario

**Question:** Design an idempotent payment endpoint that may receive retries after timeouts.

**Answer:**

For payments, persist the idempotency key before/with the payment state, validate repeated payloads match, and return the original outcome. Never charge again merely because the first response was lost.

### Q79.4 — Troubleshooting / Failure

**Question:** How would you handle duplicate requests that arrive concurrently, partial downstream success, and key expiry?

**Answer:**

Handle concurrent duplicates with a unique constraint/transaction, represent `IN_PROGRESS/SUCCEEDED/FAILED` carefully, reconcile uncertain downstream outcomes, and choose key retention longer than realistic retry/replay windows.

### Q79.5 — Senior Trade-off / Edge Case

**Question:** What guarantees can you realistically provide across multiple systems when true atomicity is unavailable?

**Answer:**

End-to-end exactly-once effects are difficult across independent systems. Aim for at-least-once messaging/requests plus durable idempotency and reconciliation at every side-effect boundary.

---

## Q80 — Retry storm

### Q80.1 — Foundation

**Question:** What happens when every client retries a slow dependency three times?

**Answer:**

When every client retries, total offered load can multiply just as the dependency has less capacity, producing retry amplification, longer queues, timeouts, pool exhaustion, and cascading failure.

### Q80.2 — Internals / Mechanism

**Question:** Explain retry amplification, queue growth, resource saturation, timeout coupling, and cascading failure.

**Answer:**

Retries consume the same resources as original calls. If deadlines are not bounded and layers each retry, one user request can fan out into many backend attempts.

### Q80.3 — Production Scenario

**Question:** A downstream service slows from 50 ms to 2 s and upstream QPS triples due to retries. What do you do immediately?

**Answer:**

Immediately reduce retry pressure: disable/limit nonessential retries, load shed, circuit-break the dependency, extend capacity only if it helps, and protect queues/pools. Stabilize before tuning.

### Q80.4 — Troubleshooting / Failure

**Question:** How would you tune timeouts, exponential backoff, jitter, retry budgets, circuit breakers, and load shedding?

**Answer:**

Inspect retry counts by layer, timeout hierarchy, queue depth, pool saturation, dependency capacity, and success probability. Add exponential backoff, jitter, max attempts, retry budgets, and only retry safe/transient errors.

### Q80.5 — Senior Trade-off / Edge Case

**Question:** Where should retries live in a multi-layer architecture so independent layers do not multiply one another?

**Answer:**

Place retries at the layer with enough context to know safety and deadline. Avoid independent retries at SDK + service mesh + application + caller, because multiplication can be catastrophic.

---

# 11 — Software Engineering Fundamentals

## Q81 — SOLID

### Q81.1 — Foundation

**Question:** Which SOLID principle is most useful to you, and why?

**Answer:**

A strong answer picks one SOLID principle and explains why it improves changeability or correctness in real systems. For example, Dependency Inversion can isolate business logic from infrastructure and make testing and replacement easier.

### Q81.2 — Internals / Mechanism

**Question:** Explain that principle beyond the textbook definition and how it affects dependency structure.

**Answer:**

Go beyond definitions: explain dependency direction, boundaries, contracts, and how the principle reduces coupling. The interviewer should hear design reasoning, not an acronym recital.

### Q81.3 — Production Scenario

**Question:** Give a real production example where violating it made change or testing difficult.

**Answer:**

Use a real example where violating the principle made deployment, testing, or incident response harder—for example business rules tightly coupled to a database or cloud SDK.

### Q81.4 — Troubleshooting / Failure

**Question:** How would you refactor the design safely while preserving behaviour and deployment confidence?

**Answer:**

Refactor incrementally behind tests and stable interfaces. Introduce seams/adapters, move dependencies outward, preserve behaviour, and deploy in small steps rather than rewrite the whole service.

### Q81.5 — Senior Trade-off / Edge Case

**Question:** When can strict SOLID application make a system worse through over-abstraction or unnecessary indirection?

**Answer:**

Overusing SOLID can create excessive interfaces, indirection, and tiny classes that obscure flow. Apply principles where they reduce real change/risk, not as mandatory ceremony.

---

## Q82 — Maintainable code

### Q82.1 — Foundation

**Question:** What makes code maintainable?

**Answer:**

Maintainable code is easy to understand, change, test, operate, and delete. Important traits include clear naming, cohesive modules, limited coupling, stable boundaries, useful tests, observability, and simple control flow.

### Q82.2 — Internals / Mechanism

**Question:** Discuss cohesion, coupling, naming, tests, boundaries, observability, dependency direction, and simplicity.

**Answer:**

Maintainability is an economic property: how safely and quickly engineers can change the system. Architecture, documentation, dependency direction, deployment model, and runtime diagnosability all contribute.

### Q82.3 — Production Scenario

**Question:** You inherit a reliable but difficult-to-change service. What evidence tells you where maintainability is actually hurting the business?

**Answer:**

Look for evidence such as long lead time, repeated regressions, high change-failure rate, fragile releases, duplicated fixes, onboarding difficulty, or incidents that are hard to diagnose.

### Q82.4 — Troubleshooting / Failure

**Question:** How would you refactor incrementally without turning a cleanup effort into a risky rewrite?

**Answer:**

Refactor around the highest-cost seams, add characterization tests, improve interfaces, split risky changes, and continuously deploy small improvements. Avoid pausing product work for a speculative full rewrite.

### Q82.5 — Senior Trade-off / Edge Case

**Question:** How do you balance maintainability, performance, delivery speed, and local team skill level?

**Answer:**

Optimize for the system's actual constraints. Sometimes a slightly duplicated but obvious implementation is more maintainable than a highly abstract framework; performance-critical code may justify localized complexity.

---

## Q83 — Test-first vs test-second

### Q83.1 — Foundation

**Question:** What are the pros and cons of test-first versus test-second development?

**Answer:**

Test-first gives fast design feedback and encourages testable interfaces; test-second can be faster for exploration and lets implementation shape the test strategy. Both can produce excellent or poor tests.

### Q83.2 — Internals / Mechanism

**Question:** Explain how each approach affects design feedback, coverage, coupling, and developer flow.

**Answer:**

Test-first often exposes coupling early, but can overfit design to tests. Test-second risks missing edge cases or being skipped, but can produce more realistic tests after behaviour is understood.

### Q83.3 — Production Scenario

**Question:** For a legacy production incident fix, which approach would you choose and why?

**Answer:**

For a production incident fix, first write a minimal regression test reproducing the failure if feasible, then implement the fix. If the system is too coupled, an integration/characterization test may be more practical than strict unit-first TDD.

### Q83.4 — Troubleshooting / Failure

**Question:** How would you add a regression test when the code is difficult to isolate and the failure spans multiple components?

**Answer:**

Capture the failure at the narrowest reliable layer, use fakes/containers/test environments where needed, and add unit coverage after isolating logic. The goal is preventing recurrence with trustworthy evidence.

### Q83.5 — Senior Trade-off / Edge Case

**Question:** When does insisting on TDD become counterproductive, and what engineering outcome matters more than process purity?

**Answer:**

Process purity is secondary to confidence. Spikes, incident mitigation, UI/prototype work, or integration-heavy systems may not fit strict TDD; what matters is rapid feedback and a test suite that predicts production behaviour.

---

## Q84 — Unit vs integration tests

### Q84.1 — Foundation

**Question:** What should be covered by unit tests versus integration tests?

**Answer:**

Unit tests exercise small logic in isolation and should be fast/deterministic. Integration tests verify contracts between real components such as database, network, serialization, configuration, or external adapters.

### Q84.2 — Internals / Mechanism

**Question:** Explain confidence, execution speed, dependency realism, and failure localization.

**Answer:**

Unit tests localize logic bugs cheaply; integration tests catch wiring, schema, runtime, and dependency behaviour that mocks cannot reproduce. End-to-end tests give higher realism but are slower and harder to diagnose.

### Q84.3 — Production Scenario

**Question:** A service passes thousands of unit tests but repeatedly fails in production due to configuration and dependency issues. What is missing?

**Answer:**

If thousands of unit tests pass while production fails on config/dependencies, the portfolio lacks integration/contract/environment tests. Add tests at the boundaries where incidents actually happen.

### Q84.4 — Troubleshooting / Failure

**Question:** How would you redesign the test pyramid or test portfolio to catch the real failures?

**Answer:**

Use production incident history to rebalance tests: database migrations, API contracts, configuration loading, auth, queues, container startup, and deployment smoke tests. Keep unit tests for core logic.

### Q84.5 — Senior Trade-off / Edge Case

**Question:** What should run on every commit, pre-merge, pre-deploy, and post-deploy in a mature delivery system?

**Answer:**

Run fast unit/static checks on every commit; selected integration/contract tests pre-merge; broader environment tests before release; and smoke/synthetic checks after deployment. Optimize for feedback time and risk.

---

## Q85 — Mocking

### Q85.1 — Foundation

**Question:** When is mocking useful?

**Answer:**

Mocking is useful when a boundary is slow, nondeterministic, expensive, or outside the test's purpose. It should isolate behaviour without pretending to validate the real dependency contract.

### Q85.2 — Internals / Mechanism

**Question:** Explain the difference between mocking behaviour, faking dependencies, stubbing responses, and using real integrations.

**Answer:**

A stub returns predefined data; a mock often asserts interactions; a fake is a working lightweight implementation. Over-mocking internal classes couples tests to implementation instead of outcomes.

### Q85.3 — Production Scenario

**Question:** A test suite has hundreds of brittle mocks and passes while production contracts drift. What went wrong?

**Answer:**

If production contracts drift while mocks stay green, tests are validating invented behaviour. Replace critical mocks with consumer/provider contract tests or real dependency integration tests.

### Q85.4 — Troubleshooting / Failure

**Question:** How would you replace high-risk mocks with contract tests, fakes, or integration environments without making CI unusably slow?

**Answer:**

Prioritize risky external boundaries, create reusable test containers/fakes, keep a small set of real integration suites, and delete interaction-heavy mocks that only mirror implementation details.

### Q85.5 — Senior Trade-off / Edge Case

**Question:** What boundaries are appropriate to mock, and which should be tested against real implementations?

**Answer:**

Mock boundaries you own only when isolation improves feedback. For protocols, databases, serializers, and APIs where real semantics matter, include tests against realistic implementations.

---

## Q86 — API versioning

### Q86.1 — Foundation

**Question:** How would you evolve an API without breaking existing consumers?

**Answer:**

Evolve APIs additively where possible: add optional fields/endpoints, preserve semantics, version when incompatible change is unavoidable, and publish deprecation timelines with observability.

### Q86.2 — Internals / Mechanism

**Question:** Explain additive changes, deprecation, versioning, compatibility, schema evolution, and feature negotiation.

**Answer:**

Compatibility includes syntax and semantics. A field that still exists but changes meaning can break clients just as badly as removal. Schema evolution must consider old and new producers/consumers simultaneously.

### Q86.3 — Production Scenario

**Question:** A field semantics change is required but thousands of clients cannot upgrade quickly. What strategy do you use?

**Answer:**

If clients cannot upgrade quickly, run compatibility logic or dual versions, add the new semantic under a new field/endpoint, and keep the old contract until usage data shows safe retirement.

### Q86.4 — Troubleshooting / Failure

**Question:** How would you measure client usage, roll out compatibility logic, detect breakage, and retire the old contract?

**Answer:**

Measure client/version usage, deploy changes behind compatibility paths, use contract tests and canaries, monitor error patterns, communicate deprecation, then remove only after explicit readiness criteria.

### Q86.5 — Senior Trade-off / Edge Case

**Question:** When is a new API version justified versus maintaining backward-compatible evolution?

**Answer:**

Versioning creates long-term support cost, so prefer backward-compatible evolution for normal changes. Introduce a new major version when semantics truly cannot coexist cleanly.

---

## Q87 — REST to GraphQL migration

### Q87.1 — Foundation

**Question:** How would you migrate a REST API to GraphQL?

**Answer:**

Introduce GraphQL alongside REST, define a stable schema around domain needs, implement resolvers/adapters to existing services, migrate clients incrementally, and retire REST only when evidence supports it.

### Q87.2 — Internals / Mechanism

**Question:** Explain schema design, resolver boundaries, data loading, authorization, caching, and N+1 risks.

**Answer:**

GraphQL adds schema/type tooling and client-selectable fields, but resolver design must handle authorization, N+1 queries, batching, caching, query complexity, and observability.

### Q87.3 — Production Scenario

**Question:** Clients already depend on REST and cannot migrate simultaneously. How do you run both safely?

**Answer:**

Keep REST and GraphQL backed by shared domain/service logic rather than duplicating business rules. Migrate selected clients or read paths first and compare correctness/performance.

### Q87.4 — Troubleshooting / Failure

**Question:** How would you observe performance regressions, resolver failures, query complexity, and data-source load during migration?

**Answer:**

Instrument resolver latency/errors, query shape, depth/complexity, backend call count, DataLoader/cache hit rate, and database load. Canary GraphQL traffic and protect expensive queries.

### Q87.5 — Senior Trade-off / Edge Case

**Question:** When is GraphQL the wrong choice despite client flexibility benefits?

**Answer:**

GraphQL may be wrong for simple stable APIs, highly cacheable REST resources, file transfer, or teams unable to manage query-cost/security complexity. Choose it for concrete client flexibility needs.

---

## Q88 — Technical debt

### Q88.1 — Foundation

**Question:** How do you decide whether technical debt is worth fixing?

**Answer:**

Prioritize technical debt when its recurring cost or risk exceeds the cost of remediation. Use evidence such as incidents, slow delivery, change failures, security risk, cloud cost, and engineer time.

### Q88.2 — Internals / Mechanism

**Question:** Explain debt principal, interest, risk, opportunity cost, and evidence of recurring friction.

**Answer:**

Think of debt as principal plus interest: the fix has a cost, while leaving it creates recurring friction or probability-weighted failure. Not all ugly code creates meaningful interest.

### Q88.3 — Production Scenario

**Question:** A team wants a three-month rewrite because the current service is 'messy'. How do you evaluate the proposal?

**Answer:**

For a three-month rewrite, ask which measurable problems it solves, whether incremental options exist, migration risk, opportunity cost, and how success will be measured. 'Messy' alone is not enough.

### Q88.4 — Troubleshooting / Failure

**Question:** How would you identify the highest-leverage debt items using incident, change-failure, delivery, and maintenance data?

**Answer:**

Rank debt items by incident contribution, frequency of changes, lead-time impact, ownership pain, security/compliance risk, and blast radius. Fix high-leverage bottlenecks before aesthetic cleanup.

### Q88.5 — Senior Trade-off / Edge Case

**Question:** When is consciously carrying debt the correct business decision?

**Answer:**

Carrying debt is rational when the system is stable, rarely changed, near retirement, or the business opportunity elsewhere is more valuable. Record the decision and trigger conditions for revisiting it.

---

# 12 — Databases / Distributed Systems

## Q89 — Database suddenly slow

### Q89.1 — Foundation

**Question:** Database-backed requests suddenly become slow. What do you check?

**Answer:**

Start by confirming scope and whether slowdown is query-specific or database-wide. Check latency/waits, slow queries, locks, connection pools, CPU, memory/cache, disk I/O, network, and recent data/schema changes.

### Q89.2 — Internals / Mechanism

**Question:** Explain query plans, locks, I/O, CPU, cache, connection pools, statistics, and workload changes.

**Answer:**

A query can be slow from bad plans/statistics, blocking locks, cold cache, storage latency, connection queueing, resource saturation, or changed cardinality even when application code is unchanged.

### Q89.3 — Production Scenario

**Question:** DB CPU is low but latency is high. What hypotheses become more likely?

**Answer:**

Low DB CPU with high latency points more toward waits: locks, disk/network I/O, connection acquisition, external storage, or serialized contention rather than raw CPU saturation.

### Q89.4 — Troubleshooting / Failure

**Question:** How would you inspect waits, locks, disk latency, network, connection queues, slow queries, and recent schema/data changes?

**Answer:**

Inspect DB wait events, lock graphs, active sessions, execution plans, I/O latency/queue, pool wait time, network, slow-query logs, and deploy/migration timeline. Compare healthy baseline.

### Q89.5 — Senior Trade-off / Edge Case

**Question:** What mitigations are safest during an incident, and which optimizations require careful post-incident testing?

**Answer:**

During an incident prefer rollback, query cancellation, traffic reduction, index/statistics repair, or capacity only when evidence supports it. Major schema/index rewrites need testing because they can worsen lock/I/O pressure.

---

## Q90 — Database index

### Q90.1 — Foundation

**Question:** What does a database index do?

**Answer:**

An index is an auxiliary data structure that helps locate rows without scanning the whole table, commonly a B-tree ordered by indexed keys. It trades storage and write work for faster reads.

### Q90.2 — Internals / Mechanism

**Question:** Explain B-tree-style lookup, selectivity, ordering, write amplification, storage, and optimizer choices.

**Answer:**

Indexes improve selective lookup, joins, sorting, and range scans when the optimizer can use them. Every insert/update/delete may need index maintenance, and poor indexes increase cache/storage footprint.

### Q90.3 — Production Scenario

**Question:** Why can adding an index make some workloads worse?

**Answer:**

Adding an index can slow writes, increase vacuum/maintenance work, consume memory/storage, and sometimes encourage a suboptimal plan. Too many overlapping indexes are expensive.

### Q90.4 — Troubleshooting / Failure

**Question:** How would you determine whether a slow query needs a new index, a different query, updated statistics, or a schema change?

**Answer:**

Use `EXPLAIN/EXPLAIN ANALYZE`, row/cardinality estimates, filter/join/order patterns, current indexes, statistics, and workload frequency. Fix query/data modeling when the problem is not simply missing access path.

### Q90.5 — Senior Trade-off / Edge Case

**Question:** What indexing strategy balances read performance against write cost and operational complexity?

**Answer:**

Index for important workload patterns, not every column. Remove unused/redundant indexes, use composite order deliberately, and monitor write amplification and plan regressions as data distribution changes.

---

## Q91 — Connection pool exhaustion

### Q91.1 — Foundation

**Question:** How can an application time out waiting for DB connections while database CPU remains low?

**Answer:**

Applications can time out waiting for a pool connection even when DB CPU is low because all pooled connections are checked out, leaked, blocked in long transactions, or the pool is too small relative to concurrency.

### Q91.2 — Internals / Mechanism

**Question:** Explain pool sizing, connection leaks, long transactions, queueing, and server limits.

**Answer:**

A pool bounds DB connections and queues callers. Aggregate capacity equals per-instance pool size × replica count, so scaling application replicas can unexpectedly exhaust the database connection limit.

### Q91.3 — Production Scenario

**Question:** All DB connections are in use but query latency is normal. What does that suggest?

**Answer:**

If queries are fast after acquisition, focus on connection hold time, leaks, transaction scope, slow non-query work inside transactions, or insufficient pool size—not query execution CPU.

### Q91.4 — Troubleshooting / Failure

**Question:** How would you inspect pool wait time, transaction duration, leaked connections, thread dumps, and per-query/session state?

**Answer:**

Measure pool active/idle/wait, checkout duration, DB session state, long/idle transactions, thread dumps, connection leak traces, and replica counts. Compare pool totals with DB max connections.

### Q91.5 — Senior Trade-off / Edge Case

**Question:** How do you size pools across many replicas so aggregate connections do not overwhelm the database?

**Answer:**

Size pools from DB capacity and workload concurrency, not arbitrary defaults. Use short transaction scopes, acquisition timeouts, leak detection, backpressure, and a global connection budget across replicas.

---

## Q92 — Transaction isolation

### Q92.1 — Foundation

**Question:** What are transaction isolation levels?

**Answer:**

Isolation levels define which concurrent transaction effects are visible. Common levels are read uncommitted, read committed, repeatable read/snapshot variants, and serializable.

### Q92.2 — Internals / Mechanism

**Question:** Explain dirty reads, non-repeatable reads, phantoms, snapshot isolation, and serialization anomalies.

**Answer:**

Anomalies include dirty reads, non-repeatable reads, phantoms, lost updates, and write skew. MVCC lets readers see snapshots while writers create versions; exact semantics differ by database.

### Q92.3 — Production Scenario

**Question:** A financial workflow occasionally double-processes an item under concurrency. How could isolation be involved?

**Answer:**

Double-processing can occur when two transactions both observe 'unprocessed' and then act. A stronger isolation level, conditional update, unique constraint, or explicit lock may be required.

### Q92.4 — Troubleshooting / Failure

**Question:** How would you reproduce the anomaly and choose between stronger isolation, explicit locking, constraints, or application idempotency?

**Answer:**

Reproduce with concurrent transactions and capture SQL/isolation. Identify the invariant, then test candidate controls under concurrency. Verify retries because serialization/deadlock errors are normal at stronger isolation.

### Q92.5 — Senior Trade-off / Edge Case

**Question:** When is serializable isolation worth the throughput and contention cost?

**Answer:**

Serializable offers the strongest abstraction but can increase aborts/contention and require retries. Prefer the weakest mechanism that provably enforces the business invariant.

---

## Q93 — Redis/cache failure

### Q93.1 — Foundation

**Question:** If Redis becomes unavailable, should the whole application fail?

**Answer:**

Whether Redis failure should take down the app depends on semantics. If it is only a cache, the app should often degrade gracefully—but fallback must not overload the primary database.

### Q93.2 — Internals / Mechanism

**Question:** Explain cache-aside, write-through, TTLs, cache misses, fallback, and stampede risk.

**Answer:**

Cache-aside reads the cache then source of truth on miss. During outage, every request can become a miss, producing a cache stampede and turning an optional dependency into a database overload amplifier.

### Q93.3 — Production Scenario

**Question:** A cache outage sends all traffic to the database and the DB begins failing. What happened?

**Answer:**

Protect the database: rate limit/load shed, use stale cache if safe, coalesce duplicate misses, cap concurrency, and restore cache gradually. Do not instantly send full traffic to a weaker backend.

### Q93.4 — Troubleshooting / Failure

**Question:** How would you use rate limits, stale reads, request coalescing, circuit breakers, and staged cache recovery to protect the DB?

**Answer:**

Observe cache hit rate, miss amplification, DB QPS/latency/connections, retry behaviour, and hot keys. Validate whether the cache contains data that cannot actually be reconstructed quickly.

### Q93.5 — Senior Trade-off / Edge Case

**Question:** When is a cache actually a critical dependency despite being described as 'optional'?

**Answer:**

A cache is operationally critical when origin capacity assumes a high hit rate or when it stores sessions/locks/state rather than disposable copies. Architecture documentation should state the real dependency.

---

## Q94 — Duplicate messages

### Q94.1 — Foundation

**Question:** A consumer receives the same message twice. What should it do?

**Answer:**

Assume messages may be delivered more than once. Make consumers idempotent using a stable event/message ID or business key and ensure duplicate processing cannot repeat side effects.

### Q94.2 — Internals / Mechanism

**Question:** Explain at-least-once delivery, acknowledgements, deduplication, idempotent consumers, and transactional outbox patterns.

**Answer:**

At-least-once systems can redeliver after ack loss, consumer crash, or rebalance. Deduplication records or business uniqueness constraints must be committed atomically with the side effect when possible.

### Q94.3 — Production Scenario

**Question:** Two duplicate messages are processed concurrently by different replicas. What protection is required?

**Answer:**

Concurrent duplicates require a unique constraint/conditional write or transaction so only one consumer obtains the right to process. In-memory deduplication is insufficient across replicas/restarts.

### Q94.4 — Troubleshooting / Failure

**Question:** How would you persist deduplication state, handle crashes between side effects and acknowledgements, and test replay safety?

**Answer:**

Model crash points: before side effect, after side effect before dedup record, before/after ack. Use transactional DB updates, outbox/inbox patterns, idempotent downstream calls, and replay tests.

### Q94.5 — Senior Trade-off / Edge Case

**Question:** What retention window and key design would you choose for deduplication at scale?

**Answer:**

Retain dedup keys long enough to cover broker retry/replay windows and business risk. Use compact business/event IDs and archive strategy rather than unbounded per-message state.

---

## Q95 — Exactly-once processing

### Q95.1 — Foundation

**Question:** Can distributed messaging guarantee exactly-once processing?

**Answer:**

'Exactly once' needs careful scope. A broker may provide exactly-once semantics within its own transactional model, but end-to-end side effects across external systems can still duplicate or become ambiguous.

### Q95.2 — Internals / Mechanism

**Question:** Explain the difference between exactly-once delivery, processing semantics, transactional boundaries, and idempotency.

**Answer:**

Delivery, processing, and business effect are different guarantees. Once a consumer calls a non-transactional external database/API, the broker cannot atomically control that side effect unless there is a shared protocol.

### Q95.3 — Production Scenario

**Question:** A broker claims exactly-once semantics but your consumer writes to an external database. Where can duplicates still appear?

**Answer:**

If the DB commit succeeds and the consumer crashes before broker offset/transaction commit, the message may be replayed. The DB operation therefore must be idempotent or coordinated via a transactional pattern.

### Q95.4 — Troubleshooting / Failure

**Question:** How would you design the workflow so replays are safe across broker and database failure boundaries?

**Answer:**

Use idempotent writes, unique constraints, transactional outbox/inbox, broker transactions where appropriate, and reconciliation. Test crashes at every boundary instead of trusting marketing terminology.

### Q95.5 — Senior Trade-off / Edge Case

**Question:** When is at-least-once plus idempotency simpler and more reliable than chasing exactly-once?

**Answer:**

At-least-once plus explicit idempotency is often easier to reason about and works across heterogeneous systems. Use broker exactly-once features when their scope clearly matches the required invariant.

---

## Q96 — Cascading failure

### Q96.1 — Foundation

**Question:** How can a slow Service D eventually bring down upstream Service A?

**Answer:**

A slow downstream consumes upstream threads, connections, and deadlines. Upstream queues grow; callers time out and retry; those retries increase downstream load, eventually exhausting multiple services.

### Q96.2 — Internals / Mechanism

**Question:** Explain timeout stacking, thread/connection-pool exhaustion, retry amplification, queue growth, and backpressure.

**Answer:**

Latency failures are dangerous because resources remain occupied. Timeout stacking, retry multiplication, pool exhaustion, and unbounded queues turn one slow dependency into system-wide saturation.

### Q96.3 — Production Scenario

**Question:** D latency rises from 100 ms to 3 s, but D never fully fails. Why can this be more dangerous than a hard failure?

**Answer:**

A hard failure may trigger fast circuit breaking; a 3-second 'successful' response can hold resources long enough to collapse throughput while appearing partially healthy.

### Q96.4 — Troubleshooting / Failure

**Question:** How would you use timeouts, bulkheads, circuit breakers, load shedding, queue limits, and dependency SLOs to contain the blast radius?

**Answer:**

Apply bounded timeouts, circuit breakers, bulkheads/pool limits, load shedding, bounded queues, retry budgets, and backpressure. Reduce incoming load before adding retries.

### Q96.5 — Senior Trade-off / Edge Case

**Question:** How should timeout budgets be allocated across a call chain to avoid contradictory retry and latency policies?

**Answer:**

Allocate end-to-end deadlines so inner calls have shorter budgets than outer callers and enough time for cleanup. Retry only when remaining deadline and success probability justify another attempt.

---

# 13 — Incident Management

## Q97 — First actions in a production outage

### Q97.1 — Foundation

**Question:** Production is down. What do you do first?

**Answer:**

First establish customer impact, scope, severity, and ownership. Start incident coordination, stabilize the system, and preserve key evidence. Avoid jumping straight into random logs without knowing what is broken.

### Q97.2 — Internals / Mechanism

**Question:** Explain impact assessment, severity, ownership, stabilization, communication, and evidence preservation.

**Answer:**

Separate roles: incident command/coordination, technical investigation, communications, and timeline/scribe when severity warrants it. Keep one source of truth for status and decisions.

### Q97.3 — Production Scenario

**Question:** Multiple dashboards are red but customer impact is unclear. What do you prioritize?

**Answer:**

If dashboards are broadly red but impact is unclear, verify user journeys and external symptoms first. Determine which alerts are causes, consequences, or unrelated noise.

### Q97.4 — Troubleshooting / Failure

**Question:** How would you establish scope, define an incident commander, create a timeline, and stop uncoordinated changes?

**Answer:**

Declare the incident, assign an IC, capture start/timeline/recent changes, identify affected services/regions/tenants, stop risky changes, and prioritize reversible mitigation while investigations run in parallel.

### Q97.5 — Senior Trade-off / Edge Case

**Question:** What incident process gives enough structure without slowing expert responders during a fast-moving outage?

**Answer:**

Use lightweight structure proportional to severity. The process should reduce duplicate work and unsafe changes, not require responders to fill forms while customers are down.

---

## Q98 — Rollback vs investigate

### Q98.1 — Foundation

**Question:** Error rate jumps immediately after a deployment. Do you rollback or investigate first?

**Answer:**

Rollback when there is strong change correlation, meaningful customer impact, and rollback is safe/reversible. Investigate first when rollback itself is risky or the correlation is weak. Often both activities run in parallel.

### Q98.2 — Internals / Mechanism

**Question:** Explain the decision factors: customer impact, rollback safety, reversibility, data/schema changes, and confidence in correlation.

**Answer:**

Consider error-budget burn, blast radius, time-to-mitigate, data/schema compatibility, stateful side effects, and whether old binaries can run against new state.

### Q98.3 — Production Scenario

**Question:** The release includes a backward-incompatible DB migration. How does that change your decision?

**Answer:**

A backward-incompatible DB migration may make binary rollback unsafe. Use forward fix, traffic reduction, feature disablement, or restore-compatible schema paths instead of blindly deploying the old version.

### Q98.4 — Troubleshooting / Failure

**Question:** How would you assess rollback feasibility, mitigate traffic, compare versions, and preserve evidence in parallel?

**Answer:**

Check migration and compatibility matrix, old/new version metrics, data/state changes, feature flags, queue/cache changes, and rollback runbook. Preserve evidence while another responder prepares mitigation.

### Q98.5 — Senior Trade-off / Edge Case

**Question:** What pre-deployment design makes rollback a reliable option rather than an assumption?

**Answer:**

Use expand-contract migrations, version-compatible schemas, feature flags, canaries, immutable artifacts, and tested rollback. 'We can always roll back' should be proven in deployment design.

---

## Q99 — Unknown root cause

### Q99.1 — Foundation

**Question:** You do not know what is causing an outage. Walk through your troubleshooting method.

**Answer:**

Use structured hypothesis-driven diagnosis: define symptom and scope, build a timeline, identify recent changes, divide the system into fault domains, rank hypotheses, test them with evidence, and mitigate safely.

### Q99.2 — Internals / Mechanism

**Question:** Explain symptom, scope, timeline, recent changes, fault-domain narrowing, hypotheses, evidence, and mitigation.

**Answer:**

Each check should answer a question and change confidence. Compare failing vs healthy dimensions and use binary narrowing rather than enumerating every possible component.

### Q99.3 — Production Scenario

**Question:** The first three hypotheses are disproven. How do you prevent random-walk debugging?

**Answer:**

If several hypotheses fail, revisit assumptions and scope, inspect the timeline, seek a known-good comparison, and choose the next test that best discriminates between remaining fault domains.

### Q99.4 — Troubleshooting / Failure

**Question:** How would you use binary fault-domain reduction, comparative analysis, controlled experiments, and known-good baselines?

**Answer:**

Use synthetic requests, version/zone/tenant comparisons, dependency isolation, packet/trace paths, and controlled traffic changes. Keep a written hypothesis/evidence log to prevent repeated dead ends.

### Q99.5 — Senior Trade-off / Edge Case

**Question:** What habits distinguish strong incident reasoning from simply knowing many diagnostic commands?

**Answer:**

Strong responders explain why they run a command, what outcomes mean, and what they will do next. Command memorization without a causal model produces random-walk debugging.

---

## Q100 — Multiple correlated symptoms

### Q100.1 — Foundation

**Question:** CPU is high, DB latency is high, 5xx is rising, and queue depth is growing. Which is the root cause?

**Answer:**

You cannot identify root cause from those four simultaneous symptoms alone. Build a timeline and causal model; one may be the cause while others are downstream effects.

### Q100.2 — Internals / Mechanism

**Question:** Explain why correlation alone is insufficient to establish causality.

**Answer:**

Correlation does not prove causation. CPU can rise because retries increase after DB latency; DB latency can rise because queue-driven concurrency grows; queue depth can be the first symptom or a consequence.

### Q100.3 — Production Scenario

**Question:** The timeline shows queue growth began first, then DB latency, then CPU. What hypotheses does that support?

**Answer:**

If queue growth clearly precedes DB latency and CPU, investigate why arrival rate exceeded service rate: traffic spike, stuck consumers, slower processing, or downstream backpressure.

### Q100.4 — Troubleshooting / Failure

**Question:** How would you construct and test a causal chain using timestamps, per-component telemetry, and controlled mitigation?

**Answer:**

Overlay high-resolution timestamps, request/queue rates, DB wait events, CPU modes, retry counts, and deployment/change events. Apply a controlled mitigation such as reducing concurrency to see whether the chain reverses.

### Q100.5 — Senior Trade-off / Edge Case

**Question:** How do you communicate uncertainty to stakeholders without sounding indecisive?

**Answer:**

Say explicitly: 'My current leading hypothesis is X because A preceded B, but I have not proven causality.' Clear uncertainty plus a test plan is stronger than false confidence.

---

## Q101 — Mitigation before permanent fix

### Q101.1 — Foundation

**Question:** You know the likely root cause but the permanent fix will take two hours. What do you do?

**Answer:**

Mitigate customer impact first with the safest reversible option while the permanent fix is developed. Incident response optimizes time-to-stability, not architectural perfection.

### Q101.2 — Internals / Mechanism

**Question:** Explain why incident mitigation and root-cause correction are separate objectives.

**Answer:**

Mitigation might be rollback, traffic shaping, feature disablement, capacity, failover, stale data, queue pause, or rate limiting. Each changes risk and may introduce secondary effects.

### Q101.3 — Production Scenario

**Question:** You can reduce traffic, disable a feature, or increase capacity. How do you choose?

**Answer:**

Choose by expected user benefit, reversibility, confidence, execution time, data/correctness risk, and capacity of downstream systems. Prefer the smallest action with high probability of restoring service.

### Q101.4 — Troubleshooting / Failure

**Question:** How would you estimate risk, reversibility, customer impact, and secondary effects before applying the mitigation?

**Answer:**

State the hypothesis, predicted effect, rollback plan, owner, and success metric before executing. Watch SLO/error/latency and secondary resource signals immediately after the change.

### Q101.5 — Senior Trade-off / Edge Case

**Question:** What criteria tell you the system is stable enough to move from incident response to recovery and follow-up?

**Answer:**

Once impact is stable, error rate/latency stay within acceptable bounds, queues/resources recover, and no new damage appears, transition to recovery/root-cause work with continued monitoring.

---

## Q102 — Rollback did not fix it

### Q102.1 — Foundation

**Question:** A deployment caused an outage. You rolled back, but the problem remains. What now?

**Answer:**

If rollback does not restore health, update the hypothesis. The release may have changed persistent state, triggered an external condition, or merely coincided with another failure.

### Q102.2 — Internals / Mechanism

**Question:** Explain irreversible side effects, schema/data changes, cache/state changes, external dependencies, and coincident failures.

**Answer:**

Examples include DB/schema migration, corrupted data, warmed/poisoned caches, queue backlog, feature-flag/config changes, third-party changes, or infrastructure state that old code still consumes.

### Q102.3 — Production Scenario

**Question:** The old version now fails identically. How does that update your confidence in the deployment hypothesis?

**Answer:**

Identical failure on the old version weakens 'new binary logic' as the root cause. Compare state and environment before/after the release instead of repeatedly redeploying.

### Q102.4 — Troubleshooting / Failure

**Question:** How would you compare state before/after, inspect migrations, caches, queues, config, and dependency health?

**Answer:**

Inspect migrations, DB/data diffs, config/secrets, cache keys, queue state, external APIs, infrastructure changes, and dependency metrics. Reconstruct the exact release timeline and side effects.

### Q102.5 — Senior Trade-off / Edge Case

**Question:** What release controls reduce the number of changes that cannot be safely reversed?

**Answer:**

Separate schema expand/contract, make migrations reversible or forward-compatible, version config, use feature flags, and stage stateful changes so application rollback remains meaningful.

---

## Q103 — Partial outage

### Q103.1 — Foundation

**Question:** Only 5% of users are affected. How do you investigate?

**Answer:**

Partial outages require segmentation. Identify the common dimension among affected users: tenant, region/AZ, node/Pod, version, ISP, endpoint, shard, account type, data partition, or dependency path.

### Q103.2 — Internals / Mechanism

**Question:** Explain why segmentation by tenant, AZ, region, node, version, endpoint, ISP, or data partition matters.

**Answer:**

Global averages hide localized failure. The goal is to find the smallest dimension that strongly separates healthy and unhealthy requests.

### Q103.3 — Production Scenario

**Question:** Failures cluster on one customer shard but infrastructure metrics are globally healthy. What do you inspect?

**Answer:**

If one shard is affected, inspect shard health, DB/storage placement, routing/hash mapping, data anomalies, capacity, leader/follower state, and services colocated with that shard.

### Q103.4 — Troubleshooting / Failure

**Question:** How would you find the smallest common dimension using logs, traces, routing, shard placement, and comparative queries?

**Answer:**

Query traces/logs for affected IDs, compare routing and placement, inspect shard/node metrics, reproduce against known affected/unaffected entities, and verify whether the boundary is data or infrastructure.

### Q103.5 — Senior Trade-off / Edge Case

**Question:** What telemetry architecture is required to debug partial failures without exploding cardinality?

**Answer:**

Keep bounded dimensions in metrics and use logs/traces for high-cardinality IDs. Support fast pivots from a customer/session to shard/node/version without labeling every metric by customer.

---

## Q104 — Incident Commander

### Q104.1 — Foundation

**Question:** What should an Incident Commander do?

**Answer:**

An Incident Commander owns coordination and decision flow: clarify severity/scope, assign roles, maintain priorities, manage risk, ensure communication, and keep technical responders unblocked.

### Q104.2 — Internals / Mechanism

**Question:** Explain coordination, decision ownership, communication, role separation, and keeping responders focused.

**Answer:**

The IC should maintain the big picture and avoid being consumed by one hypothesis. They track decisions, owners, status cadence, and whether mitigation is working.

### Q104.3 — Production Scenario

**Question:** The IC is the strongest technical expert in the room. Should they also do the deepest debugging?

**Answer:**

Usually the strongest technical expert should investigate rather than IC if the incident needs their depth. If they act as IC, delegate deep debugging to avoid tunnel vision and coordination gaps.

### Q104.4 — Troubleshooting / Failure

**Question:** How would you structure roles for operations, investigation, communications, scribe, and subject-matter experts?

**Answer:**

Use IC, operations/mitigation lead, investigation SMEs, communications, and scribe depending on incident size. One person can hold multiple roles for smaller events.

### Q104.5 — Senior Trade-off / Edge Case

**Question:** What makes an IC effective under uncertainty, and how do you avoid command-and-control behaviour that suppresses useful expertise?

**Answer:**

A good IC invites evidence and dissent, summarizes decisions, prevents unsafe parallel changes, and changes course when evidence changes. Authority should organize expertise, not silence it.

---

# 14 — Hands-on / Day in the Office

## Q105 — Broken Kubernetes service — 12% 504

### Q105.1 — Foundation

**Question:** Users receive 12% HTTP 504s through ALB → Ingress → Service → Pods → PostgreSQL. Where do you start?

**Answer:**

Start by quantifying the 12%: time, endpoints, versions, Pods/nodes/AZs, and who emits 504. Then trace one failing request through ALB, ingress, Service, Pods, and PostgreSQL.

### Q105.2 — Internals / Mechanism

**Question:** Map the timeout budget and observable boundaries across every hop.

**Answer:**

Define connect/request/idle timeouts at each hop and observe where time is spent. A 504 means an intermediary deadline expired, so the key is identifying which upstream did not respond in time.

### Q105.3 — Production Scenario

**Question:** Failures occur only on two Pods. What comparisons do you make against healthy Pods?

**Answer:**

If two Pods dominate failures, compare their node placement, CPU throttling, GC, connection pools, network, config/version, and DB sessions with healthy replicas. Remove them from traffic if needed.

### Q105.4 — Troubleshooting / Failure

**Question:** Use metrics, logs, traces, endpoint state, node/network evidence, DB sessions, and targeted tests to isolate the bottleneck.

**Answer:**

Use LB/ingress timing logs, traces, EndpointSlices, per-Pod metrics, node/CNI data, DB waits/connections, and targeted `curl` tests from multiple points. Find the first layer where healthy/failing paths diverge.

### Q105.5 — Senior Trade-off / Edge Case

**Question:** Once mitigated, what permanent design, alerting, and test changes would prevent the same partial timeout from escaping again?

**Answer:**

After mitigation, add per-instance tail-latency detection, timeout-budget documentation, connection-pool telemetry, canary/load tests, and automatic traffic removal/rollout abort for degraded replicas.

---

## Q106 — Release regression timeline

### Q106.1 — Foundation

**Question:** A release deploys at 13:04; errors rise at 13:08; CPU rises at 13:10; queue depth rises at 13:12. What do you infer?

**Answer:**

The timeline suggests release-related latency/errors may be primary, with CPU and queue depth potentially secondary effects. Do not assume CPU caused the errors merely because it is high later.

### Q106.2 — Internals / Mechanism

**Question:** Construct possible causal chains rather than treating all metrics as independent.

**Answer:**

Construct causal chains: slower requests increase concurrency; concurrency increases CPU; service rate drops; queue depth grows; retries may amplify everything. Compare exact onset and version-specific metrics.

### Q106.3 — Production Scenario

**Question:** Only the new version shows elevated request duration before CPU rises. What is your leading hypothesis?

**Answer:**

If new-version request duration rises first, suspect code path/dependency behaviour introduced by the release. Compare traces and resource use old vs new under the same traffic.

### Q106.4 — Troubleshooting / Failure

**Question:** How would you validate whether slower code caused queueing and CPU amplification versus an external dependency slowdown?

**Answer:**

Analyze version-scoped latency, traces, CPU profiles, queue arrival/service rate, retries, and downstream timings. Roll back/canary-shift if safe and verify whether the entire chain reverses.

### Q106.5 — Senior Trade-off / Edge Case

**Question:** What release guardrails would have detected or automatically stopped this before full rollout?

**Answer:**

Use progressive delivery with automated SLO/error/latency gates, representative canary traffic, version labels in telemetry, and queue/saturation guardrails so regression stops before full rollout.

---

## Q107 — Intermittent DNS — 2% failures

### Q107.1 — Foundation

**Question:** 98% of requests succeed; 2% fail with `Temporary failure in name resolution`. How do you start?

**Answer:**

First segment failures by node, Pod, resolver, hostname, time, and query type. Confirm whether the error is from the application resolver and whether retries hide additional failures.

### Q107.2 — Internals / Mechanism

**Question:** Identify which DNS layers and retry/caching behaviours can create intermittent failures.

**Answer:**

Potential layers include Pod stub resolver, search/`ndots`, CoreDNS/service routing, node networking/conntrack, upstream recursive resolver, and authoritative DNS. Intermittency often indicates saturation or packet loss.

### Q107.3 — Production Scenario

**Question:** Failures are concentrated on a subset of Kubernetes nodes. What becomes likely?

**Answer:**

If failures concentrate on a node subset, node-local conntrack/network/CNI or resolver configuration becomes more likely than global CoreDNS data. Compare affected nodes directly.

### Q107.4 — Troubleshooting / Failure

**Question:** How would you inspect CoreDNS, node resolver path, conntrack, packet loss, `ndots`, search domains, and upstream DNS?

**Answer:**

Run repeated `dig`/`nslookup` to cluster DNS and upstream, inspect `/etc/resolv.conf`, CoreDNS latency/errors, node conntrack and drops, packet captures on port 53, and `ndots` query multiplication.

### Q107.5 — Senior Trade-off / Edge Case

**Question:** What resilience changes would you make while avoiding excessive DNS caching or stale discovery?

**Answer:**

Scale and cache DNS responsibly, consider NodeLocal DNS, tune search/`ndots`, monitor query saturation, and keep application retries bounded. Avoid huge TTLs that break dynamic service discovery.

---

## Q108 — One bad Kubernetes node

### Q108.1 — Foundation

**Question:** Pods scheduled on one worker node are consistently slow. What do you do?

**Answer:**

Cordon the suspicious node if user impact is significant, then compare all node-local resources: CPU modes/throttling, disk, network, kernel, CNI, conntrack, runtime, interrupts, and hardware/cloud health.

### Q108.2 — Internals / Mechanism

**Question:** List node-local resources and datapaths that can create workload-specific latency.

**Answer:**

Pods share the host kernel, NIC, routes, storage path, conntrack table, CNI state, runtime, and resource controls, so a node issue can affect unrelated Pods together.

### Q108.3 — Production Scenario

**Question:** CPU and memory look normal, but all Pods on the node have network latency. What next?

**Answer:**

If CPU/memory are normal but all Pods have network latency, focus on NIC drops/errors, CNI/overlay, routes, MTU, conntrack, softirq/interrupt saturation, and underlying host/network path.

### Q108.4 — Troubleshooting / Failure

**Question:** How would you inspect NIC errors, CNI state, routes, MTU, conntrack, kernel logs, interrupts, and packet loss?

**Answer:**

Inspect `ip -s link`, `ethtool` where available, `ss`, conntrack stats, routes, CNI/BPF/iptables state, `dmesg`, softirq, packet captures, and cloud network metrics. Compare with a healthy node.

### Q108.5 — Senior Trade-off / Edge Case

**Question:** When should you cordon/drain immediately versus continue investigation on the live node?

**Answer:**

Drain quickly when the node is actively harming users and redundancy is sufficient. Preserve investigation when safe, but never prioritize forensic curiosity over availability; automate with capacity/rate safeguards.

---

## Q109 — JVM 60% heap, container 98% memory

### Q109.1 — Foundation

**Question:** JVM heap is 60% but container memory is 98%. Explain possible causes.

**Answer:**

Container memory includes far more than Java heap: metaspace, code cache, direct byte buffers, native/JNI allocations, thread stacks, allocator overhead, memory maps, and file/page cache.

### Q109.2 — Internals / Mechanism

**Question:** Break down native memory, metaspace, direct buffers, thread stacks, code cache, mmap, and page cache.

**Answer:**

`-Xmx` controls heap, not total RSS/cgroup usage. High concurrency can create many stacks/direct buffers; Netty/native libraries can allocate outside the heap; mmap/file I/O can increase charged memory.

### Q109.3 — Production Scenario

**Question:** The Pod is close to OOMKill but GC metrics are normal. What evidence do you gather?

**Answer:**

Normal GC plus high container usage means investigate non-heap/native memory first. Also check whether cgroup cache/accounting is contributing and whether thread/direct-buffer counts recently changed.

### Q109.4 — Troubleshooting / Failure

**Question:** How would you correlate NMT, `/proc`, cgroup counters, thread count, direct-buffer usage, and file mappings?

**Answer:**

Use `jcmd VM.native_memory`, `jcmd GC.heap_info`, thread dumps, `/proc/<pid>/smaps`, cgroup `memory.stat/current`, direct-buffer/runtime metrics, open mappings/files, and historical trends.

### Q109.5 — Senior Trade-off / Edge Case

**Question:** What memory-budgeting policy would you implement for Java on Kubernetes to avoid this class of failure?

**Answer:**

Size heap as a fraction of container memory with evidence-based native headroom, cap direct memory/threads where appropriate, monitor cgroup working set, and load-test the full runtime under production concurrency.

---

## Q110 — All services healthy, user journey fails

### Q110.1 — Foundation

**Question:** Services A, B, and C all report healthy, but the end-to-end user journey fails. How is that possible?

**Answer:**

Component health checks usually test local liveness/readiness, not business composition. A user journey can fail due to API contract mismatch, auth context, routing, stale state, timing, or interaction across healthy services.

### Q110.2 — Internals / Mechanism

**Question:** Explain component health versus interaction health, contract mismatch, routing, auth, state, and dependency sequencing.

**Answer:**

Health is multidimensional: A can answer `/health`, B can access its DB, and C can be Ready while the A→B→C transaction violates a contract or carries wrong identity/state.

### Q110.3 — Production Scenario

**Question:** Each service passes its own health check but the composed transaction returns an error. What evidence do you need?

**Answer:**

Collect a real failing transaction with correlation/trace ID and compare it to a successful one. Identify where the expected state or response first differs.

### Q110.4 — Troubleshooting / Failure

**Question:** How would you trace the journey, validate contracts, auth context, state transitions, timing, and cross-service assumptions?

**Answer:**

Use distributed traces, structured business events, auth/token claims, request/response schema validation, routing/version data, and state-transition records. Reproduce with the same tenant/input when safe.

### Q110.5 — Senior Trade-off / Edge Case

**Question:** What synthetic or business-transaction checks should exist so 'green components' cannot hide a broken product flow?

**Answer:**

Add synthetic end-to-end transactions for critical journeys plus contract tests between services. Keep component health for orchestration, but measure product availability at the user outcome boundary.

---

## Q111 — Dangerous Terraform apply

### Q111.1 — Foundation

**Question:** You take over a terminal where `terraform apply` is about to recreate a critical production resource. What do you do first?

**Answer:**

Stop or pause before destructive action if possible, confirm whether an apply is already executing, preserve the exact plan/state/terminal context, and establish the resource's business criticality. Do not type another `apply` impulsively.

### Q111.2 — Internals / Mechanism

**Question:** Explain state locking, plan interpretation, lifecycle semantics, provider behaviour, and replacement triggers.

**Answer:**

Replacement usually comes from a ForceNew attribute, lifecycle rule, address/state mismatch, provider change, or dependency. State lock protects concurrent writers but does not protect against a bad reviewed plan.

### Q111.3 — Production Scenario

**Question:** The replacement is due to one changed attribute that may be safe to modify manually. Do you proceed?

**Answer:**

Do not manually mutate production merely to avoid replacement until you know whether the provider can adopt that change safely. Manual drift may create a more dangerous future plan.

### Q111.4 — Troubleshooting / Failure

**Question:** How would you stop safely, preserve state/plan, compare real infrastructure, determine whether the replacement is necessary, and create a recovery path?

**Answer:**

Save the plan, back up state, inspect the changed attribute/provider docs/state/real resource, stop CI writers, determine safe alternatives such as config correction/import/state move, then generate a fresh reviewed plan.

### Q111.5 — Senior Trade-off / Edge Case

**Question:** What organizational controls should make accidental destructive production applies exceptionally hard?

**Answer:**

Use CI-only applies, saved-plan approval, policy blocking critical destroys/replacements, protected state, least privilege, ownership metadata, canary stacks, and break-glass procedures. Destructive production intent should be explicit.

---

## Q112 — Database connection exhaustion

### Q112.1 — Foundation

**Question:** DB CPU is 30%, DB connections are 100%, and app latency is 15 seconds. What is your first hypothesis?

**Answer:**

Leading hypothesis: application connection pools are exhausted or connections are held too long. Requests queue for a connection, so latency rises even though the DB has CPU headroom.

### Q112.2 — Internals / Mechanism

**Question:** Explain how pool exhaustion and queueing can occur without high DB CPU.

**Answer:**

Database CPU measures execution work, not callers waiting in the application pool. Long transactions, leaks, slow external work while holding a connection, or aggregate pools larger than DB capacity can consume all connections.

### Q112.3 — Production Scenario

**Question:** Queries are fast once a connection is acquired. What application behaviours become likely?

**Answer:**

If SQL is fast once a connection is acquired, inspect connection checkout duration, transaction scope, leaks, idle-in-transaction sessions, and application concurrency. Increasing DB CPU capacity may not help.

### Q112.4 — Troubleshooting / Failure

**Question:** How would you inspect pool wait time, leaked/long-held connections, transactions, thread dumps, replica counts, and server limits?

**Answer:**

Measure pool active/idle/wait, acquisition timeouts, per-request connection hold time, DB sessions/transactions, thread dumps, replica count × pool max, and leak traces. Identify who holds connections and why.

### Q112.5 — Senior Trade-off / Edge Case

**Question:** What pool-sizing, timeout, leak-detection, and backpressure policy prevents connection exhaustion from cascading across the system?

**Answer:**

Set a global connection budget, small bounded pools per replica, short transactions, acquisition/query timeouts, leak detection, and backpressure. Application autoscaling must not automatically multiply DB connections beyond safe capacity.

---

# Training Standard

- **Bronze:** Can answer `.1` and `.2` accurately without notes.
- **Silver:** Can answer through `.3` and give a concrete production example.
- **Gold:** Can answer through `.4` with hypothesis-driven troubleshooting.
- **Pushpay-ready:** Can answer all five layers and defend trade-offs under follow-up questions.

For troubleshooting answers, use this mental structure:

```text
Impact → Scope → Timeline → Hypotheses → Evidence → Mitigation → Root Cause → Prevention
```

Avoid random command dumping. Every command or check should answer a specific question and change your confidence in a hypothesis.

# Self-rating Warning

If an interviewer asks you to rate a technology from 1–5, a useful interpretation is:

```text
1/5 — Awareness only
2/5 — Basic exposure; needs help for non-trivial work
3/5 — Independent day-to-day production work
4/5 — Deep production use; can troubleshoot and guide others
5/5 — Subject-matter expert; comfortable with internals and edge cases
```

Treat **5/5** as permission for implementation-level internals, failure modes, production troubleshooting, and design trade-offs.