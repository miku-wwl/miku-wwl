# Pushpay Senior SRE — 112 Core Topics × 5-Layer Drill Bank

> **560 interview prompts** designed for Pushpay-style deep-dive practice.

## How to use this bank

Every topic has exactly five layers:

1. **Layer 1 — Foundation**  
   Confirm the basic concept. A Senior SRE should answer cleanly and quickly.

2. **Layer 2 — Internals / Mechanism**  
   Explain how it actually works underneath the abstraction.

3. **Layer 3 — Production Scenario**  
   Apply the concept to a realistic production environment.

4. **Layer 4 — Troubleshooting / Failure**  
   Diagnose a failure with evidence, hypotheses, and targeted checks.

5. **Layer 5 — Senior Trade-off / Edge Case**  
   Discuss design choices, safeguards, limits, and operational trade-offs.

The objective is not to memorize 560 independent answers. The objective is to train one continuous reasoning chain:

```text
Foundation
   ↓
Internals
   ↓
Production behaviour
   ↓
Failure diagnosis
   ↓
Senior trade-off
```

For each topic, practise answering all five layers **without notes**.  
If a layer exposes a weakness, stop and learn that mechanism before continuing.

---

## Recommended interview answering pattern

For troubleshooting prompts:

```text
1. Establish customer impact and scope
2. Establish timeline and recent changes
3. Narrow the fault domain
4. Form 2–4 explicit hypotheses
5. Test hypotheses with evidence
6. Mitigate safely
7. Confirm root cause
8. Prevent recurrence
```

Avoid random command dumping. Explain **why** each check changes your confidence.

---


# 01 — Git Internals

## Q1 — .git directory

### Layer 1 — Foundation

> Describe what is inside the `.git` directory and what the major files/directories are for.

### Layer 2 — Internals / Mechanism

> Explain how `HEAD`, `refs`, `index`, `objects`, `logs`, and `packed-refs` relate to one another.

### Layer 3 — Production Scenario

> A developer says their working tree looks correct but Git reports unexpected staged changes. Which `.git` structures would you inspect and why?

### Layer 4 — Troubleshooting / Failure

> After a bad operation, branch pointers look wrong and several commits appear missing. Walk through a recovery investigation using Git internals.

### Layer 5 — Senior Trade-off / Edge Case

> If reflogs are incomplete and garbage collection may have run, what recovery options remain, what evidence would you preserve first, and what are the limits?

---

## Q2 — Git commit / tree / blob objects

### Layer 1 — Foundation

> What is a Git commit object?

### Layer 2 — Internals / Mechanism

> Explain how commit, tree, blob, and annotated tag objects are linked and content-addressed.

### Layer 3 — Production Scenario

> Two repositories contain identical file contents but different commit histories. Which objects can be shared conceptually and which will differ?

### Layer 4 — Troubleshooting / Failure

> A repository appears corrupted. How would you use object structure and `git fsck` output to narrow the damage?

### Layer 5 — Senior Trade-off / Edge Case

> What trade-offs does content-addressed immutable storage give Git, and where do hash collisions, packfiles, and GC complicate the model?

---

## Q3 — `git add` and the index

### Layer 1 — Foundation

> What happens when you run `git add`?

### Layer 2 — Internals / Mechanism

> What exactly is the Git index, and how does it differ from both the working tree and `HEAD`?

### Layer 3 — Production Scenario

> A file has partially staged changes. Explain how Git can represent that state.

### Layer 4 — Troubleshooting / Failure

> A developer staged the wrong changes in a large incident-response patch. How would you safely inspect and correct the index without losing working-tree changes?

### Layer 5 — Senior Trade-off / Edge Case

> Why is the index a powerful design choice, and what failure modes can occur when scripts manipulate it concurrently or incorrectly?

---

## Q4 — Branches and refs

### Layer 1 — Foundation

> What exactly is a Git branch?

### Layer 2 — Internals / Mechanism

> Explain how branch refs move during commits, merges, resets, and fast-forwards.

### Layer 3 — Production Scenario

> Two engineers disagree about whether a branch 'contains' commits. Explain the more precise model using reachability.

### Layer 4 — Troubleshooting / Failure

> A release branch was force-pushed and now points to the wrong commit. How would you determine the previous tip and restore it safely?

### Layer 5 — Senior Trade-off / Edge Case

> When are force-pushes acceptable, and what controls would you use in a production engineering workflow to reduce ref-loss risk?

---

## Q5 — HEAD and detached HEAD

### Layer 1 — Foundation

> What is `HEAD` in Git?

### Layer 2 — Internals / Mechanism

> Explain symbolic `HEAD` versus detached `HEAD` and what happens when you commit in each state.

### Layer 3 — Production Scenario

> A CI job checks out a commit SHA directly and creates a commit during the build. Where does that commit live?

### Layer 4 — Troubleshooting / Failure

> Someone created valuable work in detached HEAD and then switched branches. How do you recover it?

### Layer 5 — Senior Trade-off / Edge Case

> Why do CI/CD systems often use detached HEAD deliberately, and what workflow risks does that introduce for humans?

---

## Q6 — Merge vs rebase

### Layer 1 — Foundation

> What is the difference between merge and rebase?

### Layer 2 — Internals / Mechanism

> Explain the object-graph changes caused by merge versus rebase.

### Layer 3 — Production Scenario

> A long-running feature branch has diverged heavily from main. How would you choose between merge, rebase, or rebuilding the branch?

### Layer 4 — Troubleshooting / Failure

> A rebase was performed on a shared branch and collaborators now have duplicated-looking commits. How do you untangle the situation?

### Layer 5 — Senior Trade-off / Edge Case

> What are the maintainability, auditability, and incident-forensics trade-offs between linear history and preserved merge history?

---

## Q7 — Git repository corruption

### Layer 1 — Foundation

> What does it mean for a Git repository to be corrupted?

### Layer 2 — Internals / Mechanism

> Which internal structures can be damaged, and how would corruption of refs differ from corruption of objects?

### Layer 3 — Production Scenario

> A build agent reports intermittent Git object errors while other clones are healthy. How would you separate local disk issues from remote-repository issues?

### Layer 4 — Troubleshooting / Failure

> Walk through a safe corruption investigation using backups, remotes, `git fsck`, reflogs, and object inspection.

### Layer 5 — Senior Trade-off / Edge Case

> In a regulated production environment, what evidence-preservation and recovery practices would you establish before attempting repair?

---

## Q8 — Recovering lost commits

### Layer 1 — Foundation

> How can you recover commits after an accidental reset?

### Layer 2 — Internals / Mechanism

> Explain how reflogs, unreachable objects, and reachability interact during recovery.

### Layer 3 — Production Scenario

> A developer ran `reset --hard` and force-pushed. The remote branch no longer references three commits. What do you do?

### Layer 4 — Troubleshooting / Failure

> Assume the commits are not in any branch and the reflog is missing on the remote. How would you search for dangling commits locally or on other clones?

### Layer 5 — Senior Trade-off / Edge Case

> How does garbage collection change the recovery window, and what repository policies reduce the probability of permanent loss?

---

# 02 — Linux / Operating Systems

## Q9 — Process vs thread

### Layer 1 — Foundation

> Explain the difference between a process and a thread.

### Layer 2 — Internals / Mechanism

> Which resources are shared between threads, and which execution state is private?

### Layer 3 — Production Scenario

> A multithreaded service is consuming high CPU but only one core is saturated. What mechanisms could explain that?

### Layer 4 — Troubleshooting / Failure

> How would you determine whether contention, scheduling, or a single hot thread is the bottleneck?

### Layer 5 — Senior Trade-off / Edge Case

> When would you prefer multiple processes over multiple threads for reliability, isolation, and operational control?

---

## Q10 — Linux process memory layout

### Layer 1 — Foundation

> Describe the typical memory layout of a Linux process.

### Layer 2 — Internals / Mechanism

> Explain text, data, BSS, heap, stacks, shared libraries, and memory-mapped regions.

### Layer 3 — Production Scenario

> A process RSS is high but heap usage is modest. What could account for the difference?

### Layer 4 — Troubleshooting / Failure

> How would you investigate anonymous mappings, shared mappings, page cache effects, and native allocations?

### Layer 5 — Senior Trade-off / Edge Case

> Which memory metrics are most misleading in containers, and how would you reason about real memory pressure at host and cgroup levels?

---

## Q11 — Load average

### Layer 1 — Foundation

> What does Linux load average measure?

### Layer 2 — Internals / Mechanism

> Why can load average be high even when CPU utilization is low?

### Layer 3 — Production Scenario

> A host has load average 30 on 16 CPUs, but CPU usage is only 25%. What hypotheses do you form?

### Layer 4 — Troubleshooting / Failure

> How would you prove whether uninterruptible I/O, runnable-task bursts, or another factor is driving the load?

### Layer 5 — Senior Trade-off / Edge Case

> What operational thresholds would you use for alerting on load average, and why is a static threshold often weak?

---

## Q12 — CPU saturation

### Layer 1 — Foundation

> Production CPU suddenly reaches 100%. What is your first approach?

### Layer 2 — Internals / Mechanism

> Explain how user time, system time, iowait, steal, IRQ, and softirq change your diagnosis.

### Layer 3 — Production Scenario

> A Kubernetes node is CPU-saturated after a deployment. How do you separate application CPU, kernel overhead, and noisy-neighbour effects?

### Layer 4 — Troubleshooting / Failure

> Which commands and profiles would you use to identify hot processes, threads, syscalls, and code paths without making the incident worse?

### Layer 5 — Senior Trade-off / Edge Case

> When is throttling, scaling, rollback, or optimization the right mitigation, and how do you choose?

---

## Q13 — Memory leak / memory growth

### Layer 1 — Foundation

> How do you distinguish a memory leak from normal memory growth?

### Layer 2 — Internals / Mechanism

> Explain heap, native memory, page cache, mmap, allocator fragmentation, and cgroup accounting.

### Layer 3 — Production Scenario

> A Java container grows toward its memory limit while JVM heap remains at 60%. What are your main hypotheses?

### Layer 4 — Troubleshooting / Failure

> How would you use container metrics, JVM/native memory data, `/proc`, and system tooling to isolate the cause?

### Layer 5 — Senior Trade-off / Edge Case

> What remediation is safest during an incident, and what long-term engineering controls would you add to prevent recurrence?

---

## Q14 — Zombie processes

### Layer 1 — Foundation

> What is a zombie process?

### Layer 2 — Internals / Mechanism

> Why does a zombie exist and why can't you simply kill it?

### Layer 3 — Production Scenario

> A container accumulates thousands of zombies. What does that tell you about PID 1 and child reaping?

### Layer 4 — Troubleshooting / Failure

> How would you identify the parent process, confirm the leak mechanism, and mitigate safely?

### Layer 5 — Senior Trade-off / Edge Case

> What container-entrypoint or init-system design choices prevent zombie accumulation in production?

---

## Q15 — File descriptors

### Layer 1 — Foundation

> What is a file descriptor?

### Layer 2 — Internals / Mechanism

> Explain how files, sockets, pipes, and other kernel objects are represented through file descriptors.

### Layer 3 — Production Scenario

> A service starts returning `Too many open files`. What are the likely causes?

### Layer 4 — Troubleshooting / Failure

> How would you use `/proc`, `lsof`, `ss`, limits, and application metrics to determine whether this is a leak or legitimate growth?

### Layer 5 — Senior Trade-off / Edge Case

> When is increasing `ulimit` appropriate, and when does it only hide a deeper design problem?

---

## Q16 — SIGTERM vs SIGKILL

### Layer 1 — Foundation

> What is the difference between SIGTERM and SIGKILL?

### Layer 2 — Internals / Mechanism

> Explain what the kernel and application can do for each signal.

### Layer 3 — Production Scenario

> A Kubernetes Pod repeatedly needs `kill -9` to terminate. What might be wrong?

### Layer 4 — Troubleshooting / Failure

> How would you investigate stuck shutdown, blocked I/O, deadlocks, preStop hooks, and termination grace periods?

### Layer 5 — Senior Trade-off / Edge Case

> What shutdown contract should a production service implement to balance graceful completion against fast recovery?

---

# 03 — Networking

## Q17 — What happens when you open an HTTPS URL

### Layer 1 — Foundation

> What happens when you type `https://example.com` into a browser?

### Layer 2 — Internals / Mechanism

> Walk through DNS, route selection, neighbour resolution, TCP, TLS, HTTP, proxies/load balancers, and application handling.

### Layer 3 — Production Scenario

> The browser resolves DNS successfully but the page never loads. Which layers are still suspect?

### Layer 4 — Troubleshooting / Failure

> How would you narrow the fault domain using packet capture, socket state, TLS tools, and application telemetry?

### Layer 5 — Senior Trade-off / Edge Case

> Where would you place observability and timeouts across the path so failures are diagnosable rather than appearing as generic latency?

---

## Q18 — TCP three-way handshake

### Layer 1 — Foundation

> Explain the TCP three-way handshake.

### Layer 2 — Internals / Mechanism

> Why are sequence numbers exchanged and why isn't a two-message handshake sufficient?

### Layer 3 — Production Scenario

> Clients intermittently fail during connection establishment while established connections are fine. What does that suggest?

### Layer 4 — Troubleshooting / Failure

> How would you distinguish SYN drops, backlog exhaustion, firewall issues, and server overload?

### Layer 5 — Senior Trade-off / Edge Case

> What tuning or architectural changes are appropriate for legitimate connection bursts versus an attack or retry storm?

---

## Q19 — TIME_WAIT

### Layer 1 — Foundation

> What is `TIME_WAIT` and why does it exist?

### Layer 2 — Internals / Mechanism

> Explain why the active closer commonly enters `TIME_WAIT` and how it protects TCP correctness.

### Layer 3 — Production Scenario

> A service has tens of thousands of TIME_WAIT sockets and begins failing outbound connections. What could be happening?

### Layer 4 — Troubleshooting / Failure

> How would you investigate ephemeral-port exhaustion, connection reuse, NAT limits, and client behaviour?

### Layer 5 — Senior Trade-off / Edge Case

> Which mitigations are safe, and why can aggressive TIME_WAIT tuning create subtle correctness problems?

---

## Q20 — DNS works but TCP times out

### Layer 1 — Foundation

> A hostname resolves successfully but connections time out. What do you check next?

### Layer 2 — Internals / Mechanism

> Explain the layers between DNS success and successful application connectivity.

### Layer 3 — Production Scenario

> Only one subnet experiences the timeout while others work. How does that change your hypothesis set?

### Layer 4 — Troubleshooting / Failure

> Walk through route tables, SG/NACL/firewall policy, NAT, proxying, endpoint health, and packet evidence.

### Layer 5 — Senior Trade-off / Edge Case

> How do you design network diagnostics so teams can distinguish DNS, routing, transport, TLS, and application failures quickly?

---

## Q21 — Intermittent DNS failure

### Layer 1 — Foundation

> How would you investigate intermittent DNS timeouts?

### Layer 2 — Internals / Mechanism

> Explain caching, recursive resolution, resolver configuration, TTLs, search domains, and retry behaviour.

### Layer 3 — Production Scenario

> Only 2% of requests fail and failures cluster on a subset of nodes. What hypotheses become stronger?

### Layer 4 — Troubleshooting / Failure

> How would you test resolver health, CoreDNS/upstream behaviour, packet loss, conntrack pressure, and `ndots`-related amplification?

### Layer 5 — Senior Trade-off / Edge Case

> What architectural changes reduce DNS as a systemic dependency without creating stale-discovery risks?

---

## Q22 — HTTP 502 / 503 / 504

### Layer 1 — Foundation

> What is the operational difference between HTTP 502, 503, and 504?

### Layer 2 — Internals / Mechanism

> Explain which component commonly emits each status in reverse-proxy and load-balancer architectures.

### Layer 3 — Production Scenario

> Users see 504s while backend CPU is low. What classes of failure would you investigate?

### Layer 4 — Troubleshooting / Failure

> How would you correlate load-balancer logs, upstream timing, retries, queueing, and dependency latency to identify the source?

### Layer 5 — Senior Trade-off / Edge Case

> How should timeout budgets and error mapping be designed so the status code gives useful operational meaning?

---

## Q23 — Packet loss

### Layer 1 — Foundation

> What is packet loss and how does it affect TCP applications?

### Layer 2 — Internals / Mechanism

> Explain retransmissions, congestion control, latency inflation, and throughput collapse.

### Layer 3 — Production Scenario

> Application latency rises but CPU and memory look normal. What evidence would make packet loss a leading hypothesis?

### Layer 4 — Troubleshooting / Failure

> How would you use `ping`, `mtr`, `ss`, TCP retransmit metrics, packet capture, and interface counters responsibly?

### Layer 5 — Senior Trade-off / Edge Case

> How do you distinguish host, switch, overlay, WAN, and cloud-provider loss when you do not control the entire path?

---

## Q24 — TLS handshake

### Layer 1 — Foundation

> Explain a TLS handshake at a practical engineering level.

### Layer 2 — Internals / Mechanism

> Describe certificate validation, key agreement, session keys, SNI, ALPN, and resumption.

### Layer 3 — Production Scenario

> A client gets intermittent TLS failures only for one hostname behind a shared load balancer. What could cause that?

### Layer 4 — Troubleshooting / Failure

> How would you investigate certificate chains, SNI routing, clock skew, cipher/protocol mismatch, and termination points?

### Layer 5 — Senior Trade-off / Edge Case

> Where should TLS terminate in a multi-tier platform, and what are the security and operability trade-offs of re-encryption or mTLS?

---

# 04 — Kubernetes Fundamentals & Internals

## Q25 — Pod creation lifecycle

### Layer 1 — Foundation

> What happens after `kubectl apply` creates a Pod?

### Layer 2 — Internals / Mechanism

> Walk through API server persistence, admission, scheduling, kubelet reconciliation, CRI, image pull, CNI, and readiness.

### Layer 3 — Production Scenario

> A Pod object exists but no container starts. Which control-plane and node-side stages could be blocked?

### Layer 4 — Troubleshooting / Failure

> How would you use events, scheduler data, kubelet logs, runtime state, and CNI evidence to find the failed stage?

### Layer 5 — Senior Trade-off / Edge Case

> Which parts of this lifecycle would you make highly available or observable first in a production cluster, and why?

---

## Q26 — Deployment → ReplicaSet → Pod

### Layer 1 — Foundation

> Explain the relationship between a Deployment, ReplicaSet, and Pod.

### Layer 2 — Internals / Mechanism

> Why does a Deployment not directly manage Pods?

### Layer 3 — Production Scenario

> A rollout creates a new ReplicaSet but never scales it fully. What mechanisms control progress?

### Layer 4 — Troubleshooting / Failure

> How would you investigate maxSurge/maxUnavailable, readiness, PDBs, quota, scheduling, and rollout status?

### Layer 5 — Senior Trade-off / Edge Case

> What trade-offs would you choose for a critical API between rollout speed, capacity overhead, and availability?

---

## Q27 — Kubernetes Service traffic

### Layer 1 — Foundation

> What is a Kubernetes Service?

### Layer 2 — Internals / Mechanism

> Explain how Service VIPs, EndpointSlices, kube-proxy or eBPF datapaths, and Pod IPs fit together.

### Layer 3 — Production Scenario

> DNS resolves the Service but clients cannot connect. Which layers do you inspect?

### Layer 4 — Troubleshooting / Failure

> Same-node Service traffic works but cross-node traffic fails. How do you narrow the fault to CNI, routing, conntrack, policy, or node networking?

### Layer 5 — Senior Trade-off / Edge Case

> How would your diagnosis change in an eBPF-based cluster where kube-proxy is absent?

---

## Q28 — Ready Pods but 503s

### Layer 1 — Foundation

> All Pods are Ready but users receive 503s. Where do you start?

### Layer 2 — Internals / Mechanism

> Explain why readiness alone does not guarantee end-to-end availability.

### Layer 3 — Production Scenario

> Only one availability zone shows 503s. Which routing and dependency issues become likely?

### Layer 4 — Troubleshooting / Failure

> How would you correlate ingress/load-balancer targets, Service endpoints, app health, dependency health, and zonal networking?

### Layer 5 — Senior Trade-off / Edge Case

> What changes would you make so readiness reflects true serving capability without making probes overly expensive or fragile?

---

## Q29 — CrashLoopBackOff

### Layer 1 — Foundation

> What does `CrashLoopBackOff` mean?

### Layer 2 — Internals / Mechanism

> Explain restart policy, exponential backoff, container exit states, and how previous logs help.

### Layer 3 — Production Scenario

> A Pod starts successfully for 20 seconds and then crashes repeatedly. What categories of causes do you consider?

### Layer 4 — Troubleshooting / Failure

> How would you inspect events, exit codes, OOMKilled, probes, config, secrets, dependencies, and application startup/shutdown behaviour?

### Layer 5 — Senior Trade-off / Edge Case

> When is disabling a liveness probe or increasing delays an acceptable mitigation, and when would that conceal the real fault?

---

## Q30 — Pending Pod

### Layer 1 — Foundation

> What does it mean when a Pod remains Pending?

### Layer 2 — Internals / Mechanism

> Explain scheduling constraints, resource requests, affinity, taints/tolerations, PVC binding, quotas, and admission blockers.

### Layer 3 — Production Scenario

> Only new Pods are Pending while existing workloads run normally. What recent changes or capacity issues do you suspect?

### Layer 4 — Troubleshooting / Failure

> How would you use scheduler events, node allocatable data, quotas, storage state, and affinity rules to identify the blocker?

### Layer 5 — Senior Trade-off / Edge Case

> How do you design capacity headroom and scheduling policy so a single placement constraint cannot create a large outage?

---

## Q31 — Kubernetes DNS

### Layer 1 — Foundation

> How does DNS work inside a Kubernetes cluster?

### Layer 2 — Internals / Mechanism

> Explain CoreDNS, Service discovery records, search domains, `ndots`, caching, and upstream resolution.

### Layer 3 — Production Scenario

> Only Pods on certain nodes intermittently fail to resolve Services. What does that suggest?

### Layer 4 — Troubleshooting / Failure

> How would you test CoreDNS, node networking, conntrack, resolver config, packet loss, and query amplification?

### Layer 5 — Senior Trade-off / Edge Case

> What changes improve DNS resilience at scale without causing stale data or masking service-discovery failures?

---

## Q32 — etcd unavailable

### Layer 1 — Foundation

> What is etcd used for in Kubernetes?

### Layer 2 — Internals / Mechanism

> What happens to reads, writes, scheduling, controllers, and already-running workloads when etcd becomes unavailable?

### Layer 3 — Production Scenario

> Your applications continue serving but no new Pods can be created. How would you confirm etcd is the control-plane bottleneck?

### Layer 4 — Troubleshooting / Failure

> How would you investigate quorum, disk latency, network partitions, certs, resource pressure, and member health?

### Layer 5 — Senior Trade-off / Edge Case

> What backup, restore, quorum, and failure-domain design would you require for a production etcd cluster?

---

# 05 — Kubernetes Production Troubleshooting

## Q33 — Deployment regression

### Layer 1 — Foundation

> Error rate rises five minutes after a deployment. What do you do first?

### Layer 2 — Internals / Mechanism

> Explain how you correlate rollout timeline, version, configuration, traffic, and dependency changes.

### Layer 3 — Production Scenario

> Only the new ReplicaSet shows elevated errors while old Pods remain healthy. What is your immediate mitigation?

### Layer 4 — Troubleshooting / Failure

> If rollback does not restore health, how would you test whether schema changes, cache state, external dependencies, or irreversible side effects are involved?

### Layer 5 — Senior Trade-off / Edge Case

> How do you define rollback criteria and release guardrails so the decision is fast, safe, and not dependent on one person's intuition?

---

## Q34 — One slow Pod

### Layer 1 — Foundation

> One out of ten Pods has 3x higher latency. What could cause that?

### Layer 2 — Internals / Mechanism

> Explain node locality, CPU throttling, memory pressure, GC, network path, disk, connection pools, and cache-warmth effects.

### Layer 3 — Production Scenario

> The slow Pod becomes fast after rescheduling to another node. What does that tell you?

### Layer 4 — Troubleshooting / Failure

> How would you inspect node metrics, cgroup throttling, network counters, storage latency, and noisy-neighbour evidence?

### Layer 5 — Senior Trade-off / Edge Case

> What automation would you add so single-instance degradation is detected and isolated before it impacts users?

---

## Q35 — HPA not scaling

### Layer 1 — Foundation

> CPU is high but the HPA is not scaling. What do you check?

### Layer 2 — Internals / Mechanism

> Explain how HPA obtains metrics, computes desired replicas, applies stabilization, and interacts with requests/limits.

### Layer 3 — Production Scenario

> CPU is 90% in `top`, but HPA reports 45% utilization. Why might the numbers differ?

### Layer 4 — Troubleshooting / Failure

> How would you inspect metrics-server/custom metrics, resource requests, HPA events, maxReplicas, cooldown behaviour, and pending capacity?

### Layer 5 — Senior Trade-off / Edge Case

> When would CPU be the wrong scaling signal, and what workload metric would you use instead?

---

## Q36 — OOMKilled with normal JVM heap

### Layer 1 — Foundation

> A Java Pod is OOMKilled while JVM heap metrics look normal. Why?

### Layer 2 — Internals / Mechanism

> Explain container memory accounting beyond the Java heap: metaspace, direct buffers, thread stacks, native libraries, page cache, and mmap.

### Layer 3 — Production Scenario

> The kernel reports cgroup OOM but heap dump shows no leak. What do you investigate next?

### Layer 4 — Troubleshooting / Failure

> How would you correlate cgroup memory, Native Memory Tracking, process mappings, thread counts, direct buffers, and limits?

### Layer 5 — Senior Trade-off / Edge Case

> How would you size JVM/container memory and enforce guardrails so native growth cannot unexpectedly consume the cgroup budget?

---

## Q37 — Node NotReady

### Layer 1 — Foundation

> What does `NodeNotReady` mean?

### Layer 2 — Internals / Mechanism

> Explain heartbeats/leases, kubelet status, node conditions, and controller eviction behaviour.

### Layer 3 — Production Scenario

> A node becomes NotReady during peak traffic but remains reachable by SSH. What possibilities do you consider?

### Layer 4 — Troubleshooting / Failure

> How would you investigate kubelet, runtime, disk pressure, PID pressure, network, API-server reachability, and resource starvation before rebooting?

### Layer 5 — Senior Trade-off / Edge Case

> What node-remediation automation is safe, and what safeguards prevent an automated reboot loop from amplifying an outage?

---

## Q38 — Cross-node traffic failure

### Layer 1 — Foundation

> Same-node Pod traffic works but cross-node traffic intermittently fails. What does that suggest?

### Layer 2 — Internals / Mechanism

> Explain the packet path across nodes for your CNI and where encapsulation/routing/NAT/policy can fail.

### Layer 3 — Production Scenario

> Failures are concentrated on one worker pair. How does that narrow your scope?

### Layer 4 — Troubleshooting / Failure

> How would you use route tables, CNI state, MTU checks, conntrack, packet capture, interface drops, and network policy inspection?

### Layer 5 — Senior Trade-off / Edge Case

> What cluster-network architecture choices reduce these failure modes, and what observability would you require at the dataplane?

---

## Q39 — Rollout stuck at 8/10

### Layer 1 — Foundation

> A Deployment rollout is stuck at 8/10 replicas. What do you inspect?

### Layer 2 — Internals / Mechanism

> Explain rollout progress conditions and how readiness, scheduling, PDBs, maxSurge/maxUnavailable, and quotas affect it.

### Layer 3 — Production Scenario

> Two new Pods remain Pending while old Pods cannot be terminated. What interaction could cause this?

### Layer 4 — Troubleshooting / Failure

> How would you prove whether capacity, PDB, affinity, quota, image pull, or probe failure is the blocker?

### Layer 5 — Senior Trade-off / Edge Case

> How would you design rollout policy to avoid deadlock when the cluster has little spare capacity?

---

## Q40 — Control plane healthy, workloads unhealthy

### Layer 1 — Foundation

> Kubernetes control-plane metrics are healthy but application availability is dropping. How do you narrow the fault domain?

### Layer 2 — Internals / Mechanism

> Explain why API-server health does not imply node, network, storage, ingress, or application health.

### Layer 3 — Production Scenario

> Only one service is affected while other workloads on the same nodes are healthy. What does that imply?

### Layer 4 — Troubleshooting / Failure

> How would you move from external symptom to ingress, Service, Pod, node, dependency, and application evidence without random command execution?

### Layer 5 — Senior Trade-off / Edge Case

> What layered SLOs and synthetic checks would let you distinguish platform health from workload health automatically?

---

# 06 — AWS / Cloud

## Q41 — ALB to application timeout

### Layer 1 — Foundation

> Requests reach an ALB but never reach the application. What do you check?

### Layer 2 — Internals / Mechanism

> Explain target groups, health checks, listeners, security groups, routing, subnets, and backend connection flow.

### Layer 3 — Production Scenario

> Targets are healthy but requests still time out intermittently. What deeper issues do you consider?

### Layer 4 — Troubleshooting / Failure

> How would you correlate ALB access logs, target response times, SG/NACLs, subnet routing, application sockets, and dependency latency?

### Layer 5 — Senior Trade-off / Edge Case

> What timeout, health-check, and connection-management settings would you design to avoid ambiguous ALB failures?

---

## Q42 — Security Groups vs NACLs

### Layer 1 — Foundation

> Explain the difference between Security Groups and Network ACLs.

### Layer 2 — Internals / Mechanism

> Which are stateful, which are stateless, and how are rules evaluated?

### Layer 3 — Production Scenario

> An outbound connection succeeds from one subnet but fails from another with identical SGs. What could explain it?

### Layer 4 — Troubleshooting / Failure

> How would you prove whether NACLs, routes, SGs, ephemeral ports, or another layer is responsible?

### Layer 5 — Senior Trade-off / Edge Case

> What policy-management approach reduces accidental network outages while keeping least privilege?

---

## Q43 — Multi-AZ design

### Layer 1 — Foundation

> What does Multi-AZ protect you from?

### Layer 2 — Internals / Mechanism

> Explain which failures AZ separation handles and which shared dependencies remain.

### Layer 3 — Production Scenario

> Your application spans three AZs but loses availability when one AZ fails. What design mistakes could cause that?

### Layer 4 — Troubleshooting / Failure

> How would you investigate uneven capacity, zonal load-balancing, NAT, stateful dependencies, quorum, and cross-AZ traffic?

### Layer 5 — Senior Trade-off / Edge Case

> What capacity and dependency rules would you enforce so the system can actually survive an AZ loss rather than just claim Multi-AZ?

---

## Q44 — AWS API throttling

### Layer 1 — Foundation

> What is AWS API throttling?

### Layer 2 — Internals / Mechanism

> Explain rate limits, burst limits, retries, exponential backoff, jitter, and token-bucket-style behaviour.

### Layer 3 — Production Scenario

> An automation fleet suddenly sees throttling after a scale-out event. What do you do?

### Layer 4 — Troubleshooting / Failure

> How would you identify the offending API/client, distinguish per-account/per-region limits, and stop retry amplification?

### Layer 5 — Senior Trade-off / Edge Case

> When should you request quota increases versus redesign batching, caching, concurrency, and control-plane access?

---

## Q45 — S3 consistency

### Layer 1 — Foundation

> What consistency guarantees does Amazon S3 provide?

### Layer 2 — Internals / Mechanism

> Explain strong read-after-write/list consistency and why application-level behaviour can still appear inconsistent.

### Layer 3 — Production Scenario

> A pipeline writes an object, then another component claims it is missing. What else besides S3 consistency could be wrong?

### Layer 4 — Troubleshooting / Failure

> How would you investigate stale caches, eventual metadata outside S3, versioning, retries, IAM, replication, and application race conditions?

### Layer 5 — Senior Trade-off / Edge Case

> How would you design idempotent object workflows so transient retries and duplicate events do not create inconsistent business state?

---

## Q46 — IAM AccessDenied

### Layer 1 — Foundation

> An IAM policy appears to allow an action, but the request gets AccessDenied. What can override it?

### Layer 2 — Internals / Mechanism

> Explain identity policies, resource policies, SCPs, permission boundaries, session policies, explicit deny, and KMS policy interaction.

### Layer 3 — Production Scenario

> Only one assumed role fails while another role with similar permissions succeeds. What do you compare?

### Layer 4 — Troubleshooting / Failure

> How would you use policy simulation, CloudTrail, role session context, resource policies, and KMS grants to isolate the denial?

### Layer 5 — Senior Trade-off / Edge Case

> What IAM design practices make authorization failures diagnosable without creating overly broad roles?

---

## Q47 — Regional degradation / failover

### Layer 1 — Foundation

> AWS reports partial degradation in your primary region. When do you fail over?

### Layer 2 — Internals / Mechanism

> Explain the technical and business signals required before a regional failover.

### Layer 3 — Production Scenario

> Some dependencies are healthy and others degraded. How do you determine whether failover improves or worsens user impact?

### Layer 4 — Troubleshooting / Failure

> How would you validate secondary-region capacity, data currency, DNS/traffic controls, external dependencies, and failback risk?

### Layer 5 — Senior Trade-off / Edge Case

> What RTO/RPO, game-day, and decision-authority model would you establish before the incident so failover is not improvised?

---

## Q48 — Cloud cost anomaly

### Layer 1 — Foundation

> AWS cost increases 40% overnight without known traffic growth. Where do you start?

### Layer 2 — Internals / Mechanism

> Explain how you break cost down by service, account, region, tag, usage type, and time.

### Layer 3 — Production Scenario

> Compute cost rises but request volume is flat. What technical causes might explain the difference?

### Layer 4 — Troubleshooting / Failure

> How would you correlate autoscaling, runaway jobs, data transfer, NAT, log ingestion, storage growth, and pricing changes?

### Layer 5 — Senior Trade-off / Edge Case

> What FinOps guardrails and anomaly alerts would you implement without blocking legitimate scaling?

---

# 07 — Terraform / Infrastructure as Code

## Q49 — Terraform state

### Layer 1 — Foundation

> Why does Terraform need state?

### Layer 2 — Internals / Mechanism

> Explain resource addressing, dependency tracking, refresh, remote objects, and why config alone is insufficient.

### Layer 3 — Production Scenario

> Two teams accidentally use different state files for overlapping infrastructure. What can happen?

### Layer 4 — Troubleshooting / Failure

> How would you detect ownership conflict, prevent destructive plans, and safely consolidate or import resources?

### Layer 5 — Senior Trade-off / Edge Case

> What state-boundary strategy would you use for a large organization to balance blast radius, dependencies, and team autonomy?

---

## Q50 — Lost Terraform state

### Layer 1 — Foundation

> What happens if Terraform state is lost?

### Layer 2 — Internals / Mechanism

> Explain why recreating the same configuration does not necessarily recover ownership safely.

### Layer 3 — Production Scenario

> State is deleted but infrastructure still exists. What are your immediate safety steps?

### Layer 4 — Troubleshooting / Failure

> How would you restore from remote-state versioning/backups or rebuild with imports while minimizing destructive actions?

### Layer 5 — Senior Trade-off / Edge Case

> What controls should make permanent state loss extremely unlikely, and how would you test the recovery procedure?

---

## Q51 — Infrastructure drift

### Layer 1 — Foundation

> What is Terraform drift?

### Layer 2 — Internals / Mechanism

> How does refresh/plan reveal drift and what kinds of drift may be intentional?

### Layer 3 — Production Scenario

> An engineer makes an emergency console change during an outage. What should happen after stabilization?

### Layer 4 — Troubleshooting / Failure

> How would you determine whether to revert the manual change, codify it, import it, or redesign the resource?

### Layer 5 — Senior Trade-off / Edge Case

> What governance model allows emergency changes without normalizing unmanaged infrastructure?

---

## Q52 — `terraform plan` internals

### Layer 1 — Foundation

> What does `terraform plan` do?

### Layer 2 — Internals / Mechanism

> Explain config evaluation, provider reads, state refresh, dependency graph construction, diffing, and unknown values.

### Layer 3 — Production Scenario

> A plan shows an unexpected replacement for a critical resource. What do you do before apply?

### Layer 4 — Troubleshooting / Failure

> How would you inspect provider schema, lifecycle rules, changed attributes, state, and upstream dependencies to understand the replacement?

### Layer 5 — Senior Trade-off / Edge Case

> What CI checks should gate a plan containing destroys/replacements in production?

---

## Q53 — State locking

### Layer 1 — Foundation

> Why does Terraform state need locking?

### Layer 2 — Internals / Mechanism

> Explain the race conditions that can occur if two applies mutate the same state concurrently.

### Layer 3 — Production Scenario

> Two pipelines are waiting on a lock and one lock appears stale. What is your response?

### Layer 4 — Troubleshooting / Failure

> How would you confirm whether an apply is still active before force-unlocking, and what evidence would you preserve?

### Layer 5 — Senior Trade-off / Edge Case

> How would you design pipeline serialization and workspace/state ownership to make force-unlock almost unnecessary?

---

## Q54 — Secrets in Terraform

### Layer 1 — Foundation

> Does `sensitive = true` make a Terraform secret secure?

### Layer 2 — Internals / Mechanism

> Explain where sensitive values can still appear: state, provider APIs, logs, plans, and downstream systems.

### Layer 3 — Production Scenario

> A secret was committed to state and later rotated. What exposure remains?

### Layer 4 — Troubleshooting / Failure

> How would you rotate credentials, secure remote state, limit access, scrub logs, and assess whether historical state versions contain the value?

### Layer 5 — Senior Trade-off / Edge Case

> When should Terraform reference a secret manager rather than manage secret values directly?

---

## Q55 — Partial Terraform apply failure

### Layer 1 — Foundation

> Terraform creates 15 resources and fails on resource 16. What state are you left in?

### Layer 2 — Internals / Mechanism

> Explain how successful operations are recorded and how a subsequent plan reconciles partial progress.

### Layer 3 — Production Scenario

> The failure occurs after an external side effect but before the provider records state correctly. What complications arise?

### Layer 4 — Troubleshooting / Failure

> How would you inspect real infrastructure versus state and recover without blindly re-running the apply?

### Layer 5 — Senior Trade-off / Edge Case

> What provider and module design choices improve idempotency and recovery from partial failures?

---

## Q56 — Terraform at organizational scale

### Layer 1 — Foundation

> How would you manage Terraform for hundreds of production resources across many teams?

### Layer 2 — Internals / Mechanism

> Explain module boundaries, remote state, CI/CD, policy-as-code, provider/version pinning, and ownership.

### Layer 3 — Production Scenario

> One shared module change can alter dozens of stacks. How do you reduce blast radius?

### Layer 4 — Troubleshooting / Failure

> How would you stage validation, canary applies, policy checks, drift detection, and rollback/recovery for infrastructure changes?

### Layer 5 — Senior Trade-off / Edge Case

> What should be centralized versus delegated to product teams in a mature platform organization?

---

# 08 — Observability

## Q57 — Metrics vs logs vs traces

### Layer 1 — Foundation

> When would you use metrics, logs, and traces?

### Layer 2 — Internals / Mechanism

> Explain the strengths, costs, and information model of each telemetry type.

### Layer 3 — Production Scenario

> A service has high latency but no obvious errors. Which signal do you start with and why?

### Layer 4 — Troubleshooting / Failure

> How would you combine RED metrics, traces, structured logs, and infrastructure metrics to move from symptom to cause?

### Layer 5 — Senior Trade-off / Edge Case

> What telemetry would you deliberately not collect because of cost, privacy, or cardinality risk?

---

## Q58 — RED and USE

### Layer 1 — Foundation

> Explain the RED and USE methods.

### Layer 2 — Internals / Mechanism

> Which systems are better suited to each method and why?

### Layer 3 — Production Scenario

> An API is slow but CPU is low. How would RED and USE guide different parts of your investigation?

### Layer 4 — Troubleshooting / Failure

> How would you map rate/errors/duration and utilization/saturation/errors across app, node, network, and storage layers?

### Layer 5 — Senior Trade-off / Edge Case

> How do you avoid turning RED/USE into dashboard checklists that still fail to explain user impact?

---

## Q59 — P99 up, P50 stable

### Layer 1 — Foundation

> P99 latency doubles while P50 stays unchanged. What does that tell you?

### Layer 2 — Internals / Mechanism

> Explain percentiles and why tail latency can change without moving the median.

### Layer 3 — Production Scenario

> Only a small subset of requests is slow after a deployment. What dimensions would you segment by?

### Layer 4 — Troubleshooting / Failure

> How would you use traces, endpoint/version/zone/node dimensions, queueing metrics, and dependency timing to isolate the tail?

### Layer 5 — Senior Trade-off / Edge Case

> What SLO and alerting approach would detect harmful tail latency without overreacting to tiny sample noise?

---

## Q60 — Average latency looks healthy

### Layer 1 — Foundation

> Why can average latency look healthy while users report slowness?

### Layer 2 — Internals / Mechanism

> Explain skew, outliers, percentiles, aggregation windows, and request weighting.

### Layer 3 — Production Scenario

> One customer cohort sees 3-second latency while global average is 150 ms. How do you expose that?

### Layer 4 — Troubleshooting / Failure

> How would you slice telemetry by tenant/region/endpoint/version while managing cardinality?

### Layer 5 — Senior Trade-off / Edge Case

> What aggregation strategy gives leadership simple KPIs without hiding serious localized failures?

---

## Q61 — High-cardinality metrics

### Layer 1 — Foundation

> What is metric cardinality?

### Layer 2 — Internals / Mechanism

> Why do dimensions such as user ID or request ID create operational and cost problems?

### Layer 3 — Production Scenario

> A team adds `customer_id` to every Prometheus metric and the monitoring system degrades. What happened?

### Layer 4 — Troubleshooting / Failure

> How would you identify the cardinality explosion, mitigate it quickly, and preserve diagnostic value through logs/traces instead?

### Layer 5 — Senior Trade-off / Edge Case

> What rules would you establish for labels, exemplars, aggregation, and retention?

---

## Q62 — No useful logs during failure

### Layer 1 — Foundation

> Production is failing but application logs show nothing unusual. What do you do?

### Layer 2 — Internals / Mechanism

> Explain why absence of logs does not mean absence of failure.

### Layer 3 — Production Scenario

> Metrics show 5xx responses generated by a proxy before requests reach the app. How does that change your investigation?

### Layer 4 — Troubleshooting / Failure

> How would you use traces, load-balancer/proxy logs, kernel/network telemetry, dependency metrics, and synthetic tests?

### Layer 5 — Senior Trade-off / Edge Case

> What logging contract would you establish so critical state transitions and failures are observable without excessive noise?

---

## Q63 — Distributed tracing

### Layer 1 — Foundation

> How does distributed tracing help diagnose microservices?

### Layer 2 — Internals / Mechanism

> Explain trace IDs, spans, parent/child relationships, context propagation, sampling, and baggage.

### Layer 3 — Production Scenario

> A request crosses eight services and takes four seconds. How do you identify the dominant contributor?

### Layer 4 — Troubleshooting / Failure

> How would you distinguish service time, queue time, retries, network delay, and missing spans?

### Layer 5 — Senior Trade-off / Edge Case

> What sampling strategy preserves incident value while controlling cost and avoiding biased traces?

---

## Q64 — Alert design

### Layer 1 — Foundation

> CPU is 95% for ten minutes. Should that page an SRE?

### Layer 2 — Internals / Mechanism

> Explain the difference between symptom alerts and cause/resource alerts.

### Layer 3 — Production Scenario

> CPU is 95% but latency and error rate are normal. What action, if any, is appropriate?

### Layer 4 — Troubleshooting / Failure

> How would you use SLO burn rate, saturation trends, queue depth, and user impact to decide paging versus ticketing?

### Layer 5 — Senior Trade-off / Edge Case

> What characteristics make an alert actionable, low-noise, and safe for an on-call rotation?

---

# 09 — SLI / SLO / Reliability

## Q65 — SLI

### Layer 1 — Foundation

> What is an SLI?

### Layer 2 — Internals / Mechanism

> Explain how an SLI is derived from user-visible behaviour rather than internal component health.

### Layer 3 — Production Scenario

> For a payment API, which candidate SLIs would you consider and which would you reject?

### Layer 4 — Troubleshooting / Failure

> How would you validate that the SLI query correctly handles retries, partial failures, client errors, and missing telemetry?

### Layer 5 — Senior Trade-off / Edge Case

> What makes an SLI stable enough for long-term governance while still representing changing user journeys?

---

## Q66 — SLO vs SLA

### Layer 1 — Foundation

> What is the difference between an SLO and an SLA?

### Layer 2 — Internals / Mechanism

> Explain internal reliability targets, contractual commitments, and error budgets.

### Layer 3 — Production Scenario

> A service has a 99.9% SLO but a 99.5% SLA. Why might that be intentional?

### Layer 4 — Troubleshooting / Failure

> How would you handle a situation where internal telemetry says the SLO is met but customers claim SLA impact?

### Layer 5 — Senior Trade-off / Edge Case

> What organizational behaviour should SLOs drive beyond simply reporting a percentage?

---

## Q67 — Choosing 99.9% vs 99.99%

### Layer 1 — Foundation

> Why might a team choose 99.9% instead of 99.99%?

### Layer 2 — Internals / Mechanism

> Translate both targets into engineering cost, allowable failure, and dependency requirements.

### Layer 3 — Production Scenario

> A low-revenue internal service requests four nines because 'reliability is important'. How do you challenge that?

### Layer 4 — Troubleshooting / Failure

> How would you estimate whether architecture, staffing, dependency SLOs, and operational maturity can support the target?

### Layer 5 — Senior Trade-off / Edge Case

> What business evidence should justify increasing an SLO, and when should you deliberately keep it lower?

---

## Q68 — Error budgets

### Layer 1 — Foundation

> What is an error budget?

### Layer 2 — Internals / Mechanism

> Explain how it connects SLO targets to allowed unreliability and delivery velocity.

### Layer 3 — Production Scenario

> A team burns 80% of its monthly budget in two days. What should change?

### Layer 4 — Troubleshooting / Failure

> How would you distinguish a one-off incident from a structural reliability problem and decide release policy?

### Layer 5 — Senior Trade-off / Edge Case

> What error-budget policy balances reliability and product delivery without becoming a rigid freeze mechanism?

---

## Q69 — Availability for a payment API

### Layer 1 — Foundation

> How would you define availability for a payment API?

### Layer 2 — Internals / Mechanism

> Explain numerator/denominator choices and which requests should count.

### Layer 3 — Production Scenario

> A request times out client-side but the server later completes the payment. Is that available?

### Layer 4 — Troubleshooting / Failure

> How would you handle idempotency, async processing, retries, partial success, and duplicate submissions in the SLI?

### Layer 5 — Senior Trade-off / Edge Case

> What user outcome should ultimately define availability for a transactional system?

---

## Q70 — Dependency SLO mismatch

### Layer 1 — Foundation

> Your service has a 99.95% SLO but depends on a service with a 99.9% SLO. What is the issue?

### Layer 2 — Internals / Mechanism

> Explain how dependency reliability composes and why your SLO may be mathematically or operationally impossible.

### Layer 3 — Production Scenario

> The dependency is not replaceable. What architectural options do you have?

### Layer 4 — Troubleshooting / Failure

> How would you test whether caching, graceful degradation, retries, hedging, or asynchronous decoupling can protect your SLO?

### Layer 5 — Senior Trade-off / Edge Case

> When should you renegotiate your own SLO instead of adding complexity to mask a weaker dependency?

---

## Q71 — SLO violation alerting

### Layer 1 — Foundation

> Why is paging on every SLO violation a bad idea?

### Layer 2 — Internals / Mechanism

> Explain short-window noise, long-window significance, and burn-rate concepts.

### Layer 3 — Production Scenario

> A service briefly exceeds its error target for five minutes but has abundant monthly budget. Should anyone be paged?

### Layer 4 — Troubleshooting / Failure

> How would you design multi-window burn-rate alerts to catch fast and slow burns?

### Layer 5 — Senior Trade-off / Edge Case

> What secondary signals would you include to prevent both alert fatigue and silent budget exhaustion?

---

## Q72 — Burn-rate alerting

### Layer 1 — Foundation

> What is SLO burn rate?

### Layer 2 — Internals / Mechanism

> Explain what 1x, 10x, or 100x burn means relative to the budget.

### Layer 3 — Production Scenario

> How would you interpret a fast 50x burn versus a persistent 2x burn?

### Layer 4 — Troubleshooting / Failure

> Design a multi-window alert strategy that detects both catastrophic and slow reliability loss.

### Layer 5 — Senior Trade-off / Edge Case

> What are the trade-offs between mathematical precision, operational simplicity, and explainability to on-call engineers?

---

# 10 — Programming / Concurrency

## Q73 — Deadlock

### Layer 1 — Foundation

> What is a deadlock? Draw a simple example.

### Layer 2 — Internals / Mechanism

> Explain the resource dependency cycle and how threads become permanently blocked.

### Layer 3 — Production Scenario

> A Java service stops making progress while CPU remains low. What evidence would make deadlock likely?

### Layer 4 — Troubleshooting / Failure

> How would you use thread dumps, lock ownership, JVM tools, and application telemetry to confirm the deadlock?

### Layer 5 — Senior Trade-off / Edge Case

> What design patterns prevent deadlocks, and what trade-offs come with lock ordering, timeouts, or lock-free structures?

---

## Q74 — Deadlock conditions

### Layer 1 — Foundation

> What four conditions are required for deadlock?

### Layer 2 — Internals / Mechanism

> Explain mutual exclusion, hold-and-wait, no preemption, and circular wait.

### Layer 3 — Production Scenario

> Which condition would you most realistically break in typical application code?

### Layer 4 — Troubleshooting / Failure

> Given a production locking design, how would you identify whether a cycle can form before it happens?

### Layer 5 — Senior Trade-off / Edge Case

> How would you document and enforce concurrency invariants across a large codebase with many contributors?

---

## Q75 — Race condition vs deadlock

### Layer 1 — Foundation

> What is the difference between a race condition and a deadlock?

### Layer 2 — Internals / Mechanism

> Explain how timing affects correctness in a race while deadlock affects progress.

### Layer 3 — Production Scenario

> A counter occasionally loses updates but the service never hangs. What class of bug is likely?

### Layer 4 — Troubleshooting / Failure

> How would you reproduce, instrument, and prove a race that occurs once in a million requests?

### Layer 5 — Senior Trade-off / Edge Case

> When do atomics, locks, immutability, actor models, or database constraints provide the cleanest fix?

---

## Q76 — Thread safety

### Layer 1 — Foundation

> What makes code thread-safe?

### Layer 2 — Internals / Mechanism

> Explain synchronization, atomicity, visibility, immutability, and shared mutable state.

### Layer 3 — Production Scenario

> A singleton cache works in tests but corrupts data under production load. What do you inspect?

### Layer 4 — Troubleshooting / Failure

> How would you use stress tests, thread analyzers, synchronization review, and memory-model reasoning to find the bug?

### Layer 5 — Senior Trade-off / Edge Case

> What design choices reduce the need for explicit locking altogether?

---

## Q77 — Lost update / database concurrency

### Layer 1 — Foundation

> How can two concurrent writers cause a lost update?

### Layer 2 — Internals / Mechanism

> Explain optimistic locking, pessimistic locking, MVCC, compare-and-set, and version columns.

### Layer 3 — Production Scenario

> Two service instances update the same order nearly simultaneously. How do you preserve correctness?

### Layer 4 — Troubleshooting / Failure

> How would you reproduce the race, choose an isolation/control mechanism, and prove the fix under concurrency?

### Layer 5 — Senior Trade-off / Edge Case

> When is application-level locking inferior to letting the database enforce the invariant?

---

## Q78 — Distributed locks

### Layer 1 — Foundation

> When would you use a distributed lock?

### Layer 2 — Internals / Mechanism

> Explain ownership, lease expiry, fencing tokens, clock/partition concerns, and failure modes.

### Layer 3 — Production Scenario

> A lock holder pauses for longer than its lease, resumes, and writes stale data. What went wrong?

### Layer 4 — Troubleshooting / Failure

> How would you design the protected resource so an expired lock holder cannot corrupt state?

### Layer 5 — Senior Trade-off / Edge Case

> When should you redesign the workflow to avoid distributed locks entirely?

---

## Q79 — Idempotency

### Layer 1 — Foundation

> What is idempotency and why does it matter in distributed systems?

### Layer 2 — Internals / Mechanism

> Explain request keys, deduplication state, replay semantics, and response persistence.

### Layer 3 — Production Scenario

> Design an idempotent payment endpoint that may receive retries after timeouts.

### Layer 4 — Troubleshooting / Failure

> How would you handle duplicate requests that arrive concurrently, partial downstream success, and key expiry?

### Layer 5 — Senior Trade-off / Edge Case

> What guarantees can you realistically provide across multiple systems when true atomicity is unavailable?

---

## Q80 — Retry storm

### Layer 1 — Foundation

> What happens when every client retries a slow dependency three times?

### Layer 2 — Internals / Mechanism

> Explain retry amplification, queue growth, resource saturation, timeout coupling, and cascading failure.

### Layer 3 — Production Scenario

> A downstream service slows from 50 ms to 2 s and upstream QPS triples due to retries. What do you do immediately?

### Layer 4 — Troubleshooting / Failure

> How would you tune timeouts, exponential backoff, jitter, retry budgets, circuit breakers, and load shedding?

### Layer 5 — Senior Trade-off / Edge Case

> Where should retries live in a multi-layer architecture so independent layers do not multiply one another?

---

# 11 — Software Engineering Fundamentals

## Q81 — SOLID

### Layer 1 — Foundation

> Which SOLID principle is most useful to you, and why?

### Layer 2 — Internals / Mechanism

> Explain that principle beyond the textbook definition and how it affects dependency structure.

### Layer 3 — Production Scenario

> Give a real production example where violating it made change or testing difficult.

### Layer 4 — Troubleshooting / Failure

> How would you refactor the design safely while preserving behaviour and deployment confidence?

### Layer 5 — Senior Trade-off / Edge Case

> When can strict SOLID application make a system worse through over-abstraction or unnecessary indirection?

---

## Q82 — Maintainable code

### Layer 1 — Foundation

> What makes code maintainable?

### Layer 2 — Internals / Mechanism

> Discuss cohesion, coupling, naming, tests, boundaries, observability, dependency direction, and simplicity.

### Layer 3 — Production Scenario

> You inherit a reliable but difficult-to-change service. What evidence tells you where maintainability is actually hurting the business?

### Layer 4 — Troubleshooting / Failure

> How would you refactor incrementally without turning a cleanup effort into a risky rewrite?

### Layer 5 — Senior Trade-off / Edge Case

> How do you balance maintainability, performance, delivery speed, and local team skill level?

---

## Q83 — Test-first vs test-second

### Layer 1 — Foundation

> What are the pros and cons of test-first versus test-second development?

### Layer 2 — Internals / Mechanism

> Explain how each approach affects design feedback, coverage, coupling, and developer flow.

### Layer 3 — Production Scenario

> For a legacy production incident fix, which approach would you choose and why?

### Layer 4 — Troubleshooting / Failure

> How would you add a regression test when the code is difficult to isolate and the failure spans multiple components?

### Layer 5 — Senior Trade-off / Edge Case

> When does insisting on TDD become counterproductive, and what engineering outcome matters more than process purity?

---

## Q84 — Unit vs integration tests

### Layer 1 — Foundation

> What should be covered by unit tests versus integration tests?

### Layer 2 — Internals / Mechanism

> Explain confidence, execution speed, dependency realism, and failure localization.

### Layer 3 — Production Scenario

> A service passes thousands of unit tests but repeatedly fails in production due to configuration and dependency issues. What is missing?

### Layer 4 — Troubleshooting / Failure

> How would you redesign the test pyramid or test portfolio to catch the real failures?

### Layer 5 — Senior Trade-off / Edge Case

> What should run on every commit, pre-merge, pre-deploy, and post-deploy in a mature delivery system?

---

## Q85 — Mocking

### Layer 1 — Foundation

> When is mocking useful?

### Layer 2 — Internals / Mechanism

> Explain the difference between mocking behaviour, faking dependencies, stubbing responses, and using real integrations.

### Layer 3 — Production Scenario

> A test suite has hundreds of brittle mocks and passes while production contracts drift. What went wrong?

### Layer 4 — Troubleshooting / Failure

> How would you replace high-risk mocks with contract tests, fakes, or integration environments without making CI unusably slow?

### Layer 5 — Senior Trade-off / Edge Case

> What boundaries are appropriate to mock, and which should be tested against real implementations?

---

## Q86 — API versioning

### Layer 1 — Foundation

> How would you evolve an API without breaking existing consumers?

### Layer 2 — Internals / Mechanism

> Explain additive changes, deprecation, versioning, compatibility, schema evolution, and feature negotiation.

### Layer 3 — Production Scenario

> A field semantics change is required but thousands of clients cannot upgrade quickly. What strategy do you use?

### Layer 4 — Troubleshooting / Failure

> How would you measure client usage, roll out compatibility logic, detect breakage, and retire the old contract?

### Layer 5 — Senior Trade-off / Edge Case

> When is a new API version justified versus maintaining backward-compatible evolution?

---

## Q87 — REST to GraphQL migration

### Layer 1 — Foundation

> How would you migrate a REST API to GraphQL?

### Layer 2 — Internals / Mechanism

> Explain schema design, resolver boundaries, data loading, authorization, caching, and N+1 risks.

### Layer 3 — Production Scenario

> Clients already depend on REST and cannot migrate simultaneously. How do you run both safely?

### Layer 4 — Troubleshooting / Failure

> How would you observe performance regressions, resolver failures, query complexity, and data-source load during migration?

### Layer 5 — Senior Trade-off / Edge Case

> When is GraphQL the wrong choice despite client flexibility benefits?

---

## Q88 — Technical debt

### Layer 1 — Foundation

> How do you decide whether technical debt is worth fixing?

### Layer 2 — Internals / Mechanism

> Explain debt principal, interest, risk, opportunity cost, and evidence of recurring friction.

### Layer 3 — Production Scenario

> A team wants a three-month rewrite because the current service is 'messy'. How do you evaluate the proposal?

### Layer 4 — Troubleshooting / Failure

> How would you identify the highest-leverage debt items using incident, change-failure, delivery, and maintenance data?

### Layer 5 — Senior Trade-off / Edge Case

> When is consciously carrying debt the correct business decision?

---

# 12 — Databases / Distributed Systems

## Q89 — Database suddenly slow

### Layer 1 — Foundation

> Database-backed requests suddenly become slow. What do you check?

### Layer 2 — Internals / Mechanism

> Explain query plans, locks, I/O, CPU, cache, connection pools, statistics, and workload changes.

### Layer 3 — Production Scenario

> DB CPU is low but latency is high. What hypotheses become more likely?

### Layer 4 — Troubleshooting / Failure

> How would you inspect waits, locks, disk latency, network, connection queues, slow queries, and recent schema/data changes?

### Layer 5 — Senior Trade-off / Edge Case

> What mitigations are safest during an incident, and which optimizations require careful post-incident testing?

---

## Q90 — Database index

### Layer 1 — Foundation

> What does a database index do?

### Layer 2 — Internals / Mechanism

> Explain B-tree-style lookup, selectivity, ordering, write amplification, storage, and optimizer choices.

### Layer 3 — Production Scenario

> Why can adding an index make some workloads worse?

### Layer 4 — Troubleshooting / Failure

> How would you determine whether a slow query needs a new index, a different query, updated statistics, or a schema change?

### Layer 5 — Senior Trade-off / Edge Case

> What indexing strategy balances read performance against write cost and operational complexity?

---

## Q91 — Connection pool exhaustion

### Layer 1 — Foundation

> How can an application time out waiting for DB connections while database CPU remains low?

### Layer 2 — Internals / Mechanism

> Explain pool sizing, connection leaks, long transactions, queueing, and server limits.

### Layer 3 — Production Scenario

> All DB connections are in use but query latency is normal. What does that suggest?

### Layer 4 — Troubleshooting / Failure

> How would you inspect pool wait time, transaction duration, leaked connections, thread dumps, and per-query/session state?

### Layer 5 — Senior Trade-off / Edge Case

> How do you size pools across many replicas so aggregate connections do not overwhelm the database?

---

## Q92 — Transaction isolation

### Layer 1 — Foundation

> What are transaction isolation levels?

### Layer 2 — Internals / Mechanism

> Explain dirty reads, non-repeatable reads, phantoms, snapshot isolation, and serialization anomalies.

### Layer 3 — Production Scenario

> A financial workflow occasionally double-processes an item under concurrency. How could isolation be involved?

### Layer 4 — Troubleshooting / Failure

> How would you reproduce the anomaly and choose between stronger isolation, explicit locking, constraints, or application idempotency?

### Layer 5 — Senior Trade-off / Edge Case

> When is serializable isolation worth the throughput and contention cost?

---

## Q93 — Redis/cache failure

### Layer 1 — Foundation

> If Redis becomes unavailable, should the whole application fail?

### Layer 2 — Internals / Mechanism

> Explain cache-aside, write-through, TTLs, cache misses, fallback, and stampede risk.

### Layer 3 — Production Scenario

> A cache outage sends all traffic to the database and the DB begins failing. What happened?

### Layer 4 — Troubleshooting / Failure

> How would you use rate limits, stale reads, request coalescing, circuit breakers, and staged cache recovery to protect the DB?

### Layer 5 — Senior Trade-off / Edge Case

> When is a cache actually a critical dependency despite being described as 'optional'?

---

## Q94 — Duplicate messages

### Layer 1 — Foundation

> A consumer receives the same message twice. What should it do?

### Layer 2 — Internals / Mechanism

> Explain at-least-once delivery, acknowledgements, deduplication, idempotent consumers, and transactional outbox patterns.

### Layer 3 — Production Scenario

> Two duplicate messages are processed concurrently by different replicas. What protection is required?

### Layer 4 — Troubleshooting / Failure

> How would you persist deduplication state, handle crashes between side effects and acknowledgements, and test replay safety?

### Layer 5 — Senior Trade-off / Edge Case

> What retention window and key design would you choose for deduplication at scale?

---

## Q95 — Exactly-once processing

### Layer 1 — Foundation

> Can distributed messaging guarantee exactly-once processing?

### Layer 2 — Internals / Mechanism

> Explain the difference between exactly-once delivery, processing semantics, transactional boundaries, and idempotency.

### Layer 3 — Production Scenario

> A broker claims exactly-once semantics but your consumer writes to an external database. Where can duplicates still appear?

### Layer 4 — Troubleshooting / Failure

> How would you design the workflow so replays are safe across broker and database failure boundaries?

### Layer 5 — Senior Trade-off / Edge Case

> When is at-least-once plus idempotency simpler and more reliable than chasing exactly-once?

---

## Q96 — Cascading failure

### Layer 1 — Foundation

> How can a slow Service D eventually bring down upstream Service A?

### Layer 2 — Internals / Mechanism

> Explain timeout stacking, thread/connection-pool exhaustion, retry amplification, queue growth, and backpressure.

### Layer 3 — Production Scenario

> D latency rises from 100 ms to 3 s, but D never fully fails. Why can this be more dangerous than a hard failure?

### Layer 4 — Troubleshooting / Failure

> How would you use timeouts, bulkheads, circuit breakers, load shedding, queue limits, and dependency SLOs to contain the blast radius?

### Layer 5 — Senior Trade-off / Edge Case

> How should timeout budgets be allocated across a call chain to avoid contradictory retry and latency policies?

---

# 13 — Incident Management

## Q97 — First actions in a production outage

### Layer 1 — Foundation

> Production is down. What do you do first?

### Layer 2 — Internals / Mechanism

> Explain impact assessment, severity, ownership, stabilization, communication, and evidence preservation.

### Layer 3 — Production Scenario

> Multiple dashboards are red but customer impact is unclear. What do you prioritize?

### Layer 4 — Troubleshooting / Failure

> How would you establish scope, define an incident commander, create a timeline, and stop uncoordinated changes?

### Layer 5 — Senior Trade-off / Edge Case

> What incident process gives enough structure without slowing expert responders during a fast-moving outage?

---

## Q98 — Rollback vs investigate

### Layer 1 — Foundation

> Error rate jumps immediately after a deployment. Do you rollback or investigate first?

### Layer 2 — Internals / Mechanism

> Explain the decision factors: customer impact, rollback safety, reversibility, data/schema changes, and confidence in correlation.

### Layer 3 — Production Scenario

> The release includes a backward-incompatible DB migration. How does that change your decision?

### Layer 4 — Troubleshooting / Failure

> How would you assess rollback feasibility, mitigate traffic, compare versions, and preserve evidence in parallel?

### Layer 5 — Senior Trade-off / Edge Case

> What pre-deployment design makes rollback a reliable option rather than an assumption?

---

## Q99 — Unknown root cause

### Layer 1 — Foundation

> You do not know what is causing an outage. Walk through your troubleshooting method.

### Layer 2 — Internals / Mechanism

> Explain symptom, scope, timeline, recent changes, fault-domain narrowing, hypotheses, evidence, and mitigation.

### Layer 3 — Production Scenario

> The first three hypotheses are disproven. How do you prevent random-walk debugging?

### Layer 4 — Troubleshooting / Failure

> How would you use binary fault-domain reduction, comparative analysis, controlled experiments, and known-good baselines?

### Layer 5 — Senior Trade-off / Edge Case

> What habits distinguish strong incident reasoning from simply knowing many diagnostic commands?

---

## Q100 — Multiple correlated symptoms

### Layer 1 — Foundation

> CPU is high, DB latency is high, 5xx is rising, and queue depth is growing. Which is the root cause?

### Layer 2 — Internals / Mechanism

> Explain why correlation alone is insufficient to establish causality.

### Layer 3 — Production Scenario

> The timeline shows queue growth began first, then DB latency, then CPU. What hypotheses does that support?

### Layer 4 — Troubleshooting / Failure

> How would you construct and test a causal chain using timestamps, per-component telemetry, and controlled mitigation?

### Layer 5 — Senior Trade-off / Edge Case

> How do you communicate uncertainty to stakeholders without sounding indecisive?

---

## Q101 — Mitigation before permanent fix

### Layer 1 — Foundation

> You know the likely root cause but the permanent fix will take two hours. What do you do?

### Layer 2 — Internals / Mechanism

> Explain why incident mitigation and root-cause correction are separate objectives.

### Layer 3 — Production Scenario

> You can reduce traffic, disable a feature, or increase capacity. How do you choose?

### Layer 4 — Troubleshooting / Failure

> How would you estimate risk, reversibility, customer impact, and secondary effects before applying the mitigation?

### Layer 5 — Senior Trade-off / Edge Case

> What criteria tell you the system is stable enough to move from incident response to recovery and follow-up?

---

## Q102 — Rollback did not fix it

### Layer 1 — Foundation

> A deployment caused an outage. You rolled back, but the problem remains. What now?

### Layer 2 — Internals / Mechanism

> Explain irreversible side effects, schema/data changes, cache/state changes, external dependencies, and coincident failures.

### Layer 3 — Production Scenario

> The old version now fails identically. How does that update your confidence in the deployment hypothesis?

### Layer 4 — Troubleshooting / Failure

> How would you compare state before/after, inspect migrations, caches, queues, config, and dependency health?

### Layer 5 — Senior Trade-off / Edge Case

> What release controls reduce the number of changes that cannot be safely reversed?

---

## Q103 — Partial outage

### Layer 1 — Foundation

> Only 5% of users are affected. How do you investigate?

### Layer 2 — Internals / Mechanism

> Explain why segmentation by tenant, AZ, region, node, version, endpoint, ISP, or data partition matters.

### Layer 3 — Production Scenario

> Failures cluster on one customer shard but infrastructure metrics are globally healthy. What do you inspect?

### Layer 4 — Troubleshooting / Failure

> How would you find the smallest common dimension using logs, traces, routing, shard placement, and comparative queries?

### Layer 5 — Senior Trade-off / Edge Case

> What telemetry architecture is required to debug partial failures without exploding cardinality?

---

## Q104 — Incident Commander

### Layer 1 — Foundation

> What should an Incident Commander do?

### Layer 2 — Internals / Mechanism

> Explain coordination, decision ownership, communication, role separation, and keeping responders focused.

### Layer 3 — Production Scenario

> The IC is the strongest technical expert in the room. Should they also do the deepest debugging?

### Layer 4 — Troubleshooting / Failure

> How would you structure roles for operations, investigation, communications, scribe, and subject-matter experts?

### Layer 5 — Senior Trade-off / Edge Case

> What makes an IC effective under uncertainty, and how do you avoid command-and-control behaviour that suppresses useful expertise?

---

# 14 — Hands-on / Day in the Office

## Q105 — Broken Kubernetes service — 12% 504

### Layer 1 — Foundation

> Users receive 12% HTTP 504s through ALB → Ingress → Service → Pods → PostgreSQL. Where do you start?

### Layer 2 — Internals / Mechanism

> Map the timeout budget and observable boundaries across every hop.

### Layer 3 — Production Scenario

> Failures occur only on two Pods. What comparisons do you make against healthy Pods?

### Layer 4 — Troubleshooting / Failure

> Use metrics, logs, traces, endpoint state, node/network evidence, DB sessions, and targeted tests to isolate the bottleneck.

### Layer 5 — Senior Trade-off / Edge Case

> Once mitigated, what permanent design, alerting, and test changes would prevent the same partial timeout from escaping again?

---

## Q106 — Release regression timeline

### Layer 1 — Foundation

> A release deploys at 13:04; errors rise at 13:08; CPU rises at 13:10; queue depth rises at 13:12. What do you infer?

### Layer 2 — Internals / Mechanism

> Construct possible causal chains rather than treating all metrics as independent.

### Layer 3 — Production Scenario

> Only the new version shows elevated request duration before CPU rises. What is your leading hypothesis?

### Layer 4 — Troubleshooting / Failure

> How would you validate whether slower code caused queueing and CPU amplification versus an external dependency slowdown?

### Layer 5 — Senior Trade-off / Edge Case

> What release guardrails would have detected or automatically stopped this before full rollout?

---

## Q107 — Intermittent DNS — 2% failures

### Layer 1 — Foundation

> 98% of requests succeed; 2% fail with `Temporary failure in name resolution`. How do you start?

### Layer 2 — Internals / Mechanism

> Identify which DNS layers and retry/caching behaviours can create intermittent failures.

### Layer 3 — Production Scenario

> Failures are concentrated on a subset of Kubernetes nodes. What becomes likely?

### Layer 4 — Troubleshooting / Failure

> How would you inspect CoreDNS, node resolver path, conntrack, packet loss, `ndots`, search domains, and upstream DNS?

### Layer 5 — Senior Trade-off / Edge Case

> What resilience changes would you make while avoiding excessive DNS caching or stale discovery?

---

## Q108 — One bad Kubernetes node

### Layer 1 — Foundation

> Pods scheduled on one worker node are consistently slow. What do you do?

### Layer 2 — Internals / Mechanism

> List node-local resources and datapaths that can create workload-specific latency.

### Layer 3 — Production Scenario

> CPU and memory look normal, but all Pods on the node have network latency. What next?

### Layer 4 — Troubleshooting / Failure

> How would you inspect NIC errors, CNI state, routes, MTU, conntrack, kernel logs, interrupts, and packet loss?

### Layer 5 — Senior Trade-off / Edge Case

> When should you cordon/drain immediately versus continue investigation on the live node?

---

## Q109 — JVM 60% heap, container 98% memory

### Layer 1 — Foundation

> JVM heap is 60% but container memory is 98%. Explain possible causes.

### Layer 2 — Internals / Mechanism

> Break down native memory, metaspace, direct buffers, thread stacks, code cache, mmap, and page cache.

### Layer 3 — Production Scenario

> The Pod is close to OOMKill but GC metrics are normal. What evidence do you gather?

### Layer 4 — Troubleshooting / Failure

> How would you correlate NMT, `/proc`, cgroup counters, thread count, direct-buffer usage, and file mappings?

### Layer 5 — Senior Trade-off / Edge Case

> What memory-budgeting policy would you implement for Java on Kubernetes to avoid this class of failure?

---

## Q110 — All services healthy, user journey fails

### Layer 1 — Foundation

> Services A, B, and C all report healthy, but the end-to-end user journey fails. How is that possible?

### Layer 2 — Internals / Mechanism

> Explain component health versus interaction health, contract mismatch, routing, auth, state, and dependency sequencing.

### Layer 3 — Production Scenario

> Each service passes its own health check but the composed transaction returns an error. What evidence do you need?

### Layer 4 — Troubleshooting / Failure

> How would you trace the journey, validate contracts, auth context, state transitions, timing, and cross-service assumptions?

### Layer 5 — Senior Trade-off / Edge Case

> What synthetic or business-transaction checks should exist so 'green components' cannot hide a broken product flow?

---

## Q111 — Dangerous Terraform apply

### Layer 1 — Foundation

> You take over a terminal where `terraform apply` is about to recreate a critical production resource. What do you do first?

### Layer 2 — Internals / Mechanism

> Explain state locking, plan interpretation, lifecycle semantics, provider behaviour, and replacement triggers.

### Layer 3 — Production Scenario

> The replacement is due to one changed attribute that may be safe to modify manually. Do you proceed?

### Layer 4 — Troubleshooting / Failure

> How would you stop safely, preserve state/plan, compare real infrastructure, determine whether the replacement is necessary, and create a recovery path?

### Layer 5 — Senior Trade-off / Edge Case

> What organizational controls should make accidental destructive production applies exceptionally hard?

---

## Q112 — Database connection exhaustion

### Layer 1 — Foundation

> DB CPU is 30%, DB connections are 100%, and app latency is 15 seconds. What is your first hypothesis?

### Layer 2 — Internals / Mechanism

> Explain how pool exhaustion and queueing can occur without high DB CPU.

### Layer 3 — Production Scenario

> Queries are fast once a connection is acquired. What application behaviours become likely?

### Layer 4 — Troubleshooting / Failure

> How would you inspect pool wait time, leaked/long-held connections, transactions, thread dumps, replica counts, and server limits?

### Layer 5 — Senior Trade-off / Edge Case

> What pool-sizing, timeout, leak-detection, and backpressure policy prevents connection exhaustion from cascading across the system?

---

# Training Standard

A topic is **not complete** because you can answer Layer 1.

Use this standard:

- **Bronze** — Layers 1–2 are clear and accurate.
- **Silver** — Layers 1–3 can be answered with a real production example.
- **Gold** — Layers 1–4 can be answered using a structured troubleshooting method.
- **Pushpay-ready** — All five layers can be answered, including trade-offs, failure modes, and alternative designs.

## Self-rating warning

If an interviewer asks you to rate a technology from 1–5, treat **5/5** as:

> “You may ask me implementation-level internals, failure modes, production troubleshooting, and design trade-offs.”

A safer interpretation:

```text
1/5 — Awareness only
2/5 — Basic exposure; needs help for non-trivial work
3/5 — Independent day-to-day production work
4/5 — Deep production use; can troubleshoot and guide others
5/5 — Subject-matter expert; comfortable with internals and edge cases
```

## Final goal

Any major technology on your CV should survive at least this sequence:

```text
What is it?
↓
How does it work?
↓
How does it behave in production?
↓
How does it fail?
↓
How would you diagnose it?
↓
How would you mitigate it?
↓
What trade-offs would you make?
```

That is the level this bank is designed to train.
