# WEEK 1 — KUBERNETES, JAVA AND POSTGRESQL: CAUSAL ISOLATION

ULTRA Revision 1. Author-facing build prompt; do not distribute this prompt or its private build transcript to the responder.

Build a Kubernetes-hosted Java 21+ transactional API backed by PostgreSQL. The system should look healthy through ordinary pod/readiness checks while sustained customer operations experience partial failure. Choose and keep private a credible primary mechanism; do not preselect Kubernetes, the JVM or PostgreSQL as the answer merely because of the title.

## Weekly progression and scope

- Prerequisites: inspect Kubernetes services/endpoints and deployment history, read JVM/thread/pool observations, query PostgreSQL activity, and understand logical requests versus retries.
- Healthy prelab, outside the six-hour clock: map one synthetic operation from client receipt to pod, runtime and durable row. Demonstrate a load measurement and reconcile a repeated idempotency key without an incident. Record tool outputs, not a vocabulary quiz.
- New capability: separate fault localization from causal proof, and preserve customer correctness while testing a hypothesis. This is already an advanced entry exercise; prerequisites are not taught during the incident.
- Later transfer: Week 4 must use a different primary mechanism and require quantitative capacity reasoning, rather than repeating this week's isolation exercise.

## Scenario and depth requirements

| Requirement | Minimum |
|---|---|
| Primary mechanism | One coherent incident |
| Distinct contributors | 3 |
| Real, disprovable distractions | 3 |
| Substantive evidence boundaries | 4: Kubernetes traffic/readiness, application admission/request handling, JVM execution/resources, PostgreSQL activity/durability |
| Causal proof | All five shared proof roles, including two competing explanations and an isolated intervention |

Under nominal traffic, expose 15–30% failures/timeouts in at least one critical operation/cohort over the declared five-minute fault window; low traffic and many readiness checks remain healthy. Other operations must continue to succeed. At least one cohort difference must let the responder compare equivalent successful and failing operations without giving away the mechanism.

Include a time/load threshold and a persistent state effect whose reset/replay is measurable. The causal chain must connect request distribution or admission, actual waiting/execution behavior and database consequences; not every boundary must contain a defect. Include two viable mitigation choices with different effects on accepted demand, downstream pressure or recurrence, bounded by the public resource budget. At least one temporarily helps without satisfying full recovery.

Generate three plausible background signals from real behavior: for example a harmless pod restart, a noncausal metric increase and a recent unrelated change. Each needs a timestamped disqualifier. Never manufacture a kube event saying that a component is broken.

## Required evidence and acceptance additions

Expose logical-operation IDs across access logs and database receipts; traffic by operation/cohort and pod; readiness changes; request admission/in-flight counts; JVM/thread observations; pool waits; and PostgreSQL activity/transaction observations. Normal documentation must explain what readiness promises and how to access all these data, without labelling a culprit.

In addition to the shared full acceptance, repeat the critical write sequence with duplicate client deliveries and a bounded cancellation/timeout case. Reconcile acknowledged operations and ambiguous outcomes after settling. Require zero duplicate durable effects and zero lost acknowledged work, with no growing in-flight or database wait population after bursts. The candidate must explain why a green pod status alone did not establish customer recovery.

Qualify `replay-state` against the same pod distribution, initial business data and timing profile without replacing a candidate repair. In the private proof matrix, test whether changing the visually suspicious but unrelated Kubernetes signal changes customer impact; document why that explanation is rejected.

## Assessed deliverables and follow-up

Submit an operation-to-durability causal graph, two ruled-out hypotheses with provenance, a measured mitigation decision, repair and rollback, full acceptance output and a reconciliation summary. All shared communication and response checkpoints apply.

If localization is weak, repeat the healthy prelab on a different operation and build a matched cohort comparison. If causality is weak, predict a single-variable intervention before running it in a replay copy. The transfer exercise changes traffic mix within the frozen supported envelope while keeping the failure mechanism fixed; a guessed configuration fix must survive this check.

The complete shared delivery contract below is mandatory.

---

# Shared delivery contract — ULTRA Revision 1

This contract is embedded in every weekly prompt so that the prompt works independently. The weekly scenario specifies its domains, learning delta, exact acceptance additions and minimum design requirements. Those additions strengthen this contract; they do not replace its safety, fairness, recovery or scoring gates. Validate the merged requirements, especially Week 8, rather than checking a weaker generic minimum.

## Role, scope and separation

You are the incident-lab designer. Build and qualify the environment; do not solve the exercise for the responder. The deliverable is a locally reproducible, intentionally faulty system with realistic customer operations, sufficient evidence, neutral documentation and executable acceptance checks. A target score is not evidence of quality or measured difficulty.

Use one coherent primary failure mechanism, with causally distinct contributing factors. Permit several defensible descriptions of the causal graph and multiple valid repairs. A learner need not guess the author's exact wording or chosen patch. Maintain a private explanation of what is primary, what amplifies it, and what is unrelated.

Use two artifacts inside the task's authorized workspace:

- `candidate/`: application and infrastructure source, neutral history, architecture, incident ticket, operations commands, workload contract, telemetry access, public business acceptance checks, blank response templates and scoring rubric. No answer key, fixed branch, solution patch, fault-labelled file or coaching hint.
- `facilitator/`: causal model, fault/control configuration, seed/state recipes, expected discriminating observations, acceptable repair families, qualification evidence and blind-pilot records. Test healthy controls and reference repairs in isolated disposable copies here; hand over the candidate environment in its original faulty condition.

Never put facilitator files, their contents or revealing paths in candidate Git history, archives, container images/layers, volumes, tool output, CI logs, caches or mounted parent folders. Run the responder in a separate session that has not seen construction or qualification. Filesystem separation on one administrator account is only a self-study convention, not a security boundary; a formal blind assessment needs separate accounts/environments and facilitator-controlled access. Do not claim blindness if the solver saw the build transcript.

Do not execute outside local containers/VMs and the authorized task directory. No real cloud resources, production systems, credentials, real customer data, permanent host network/firewall changes or global Git configuration changes. Use synthetic transaction identifiers. Do not fabricate command output or measured results. Repair accidental bootstrap defects without removing the intended incident from the handover artifact.

## Meaningful difficulty and a fairness gate

Retain green superficial health, partial customer failure, a relevant/irrelevant change timeline, load or time dependence, persistent state, imperfect telemetry, and an action that improves symptoms before recurrence. The weekly minima constrain breadth; they are not a points-per-component recipe.

Every scored boundary must add a different constraint or explain propagation. Do not split one function into extra services merely to meet a layer count. A contributing factor must measurably change severity, onset or recurrence under a controlled comparison. A false lead must be a real observable event or behavior with available evidence that can rule it out. Do not create unrelated outages or forged warning lines. Prefer three bounded distractions; Week 8 requires four.

The facilitator must supply a causal proof matrix with these distinct roles:

1. Customer impact: logical-operation outcomes, affected cohorts and a time window.
2. Localization: evidence separating the failing path from an equivalent healthy control/cohort.
3. Mechanism: runtime, state, dependency or release evidence explaining how failures arise.
4. Discrimination: a test whose predicted result separates the leading explanation from at least two plausible alternative hypotheses.
5. Intervention: change one relevant variable, reproduce under matched traffic/state, and show the predicted effect or lack of effect; explain confounders and rollback.

At least three evidence modalities must contribute. Repeated dashboard views of the same underlying series count once. The mechanism must predict a result before the test, and survive a counterfactual comparison. Source/config inspection is legitimate evidence. Do not censor a naturally informative error message or forbid an efficient command: a clue may be obvious while causal validation and safe recovery remain difficult. Never stretch the exercise by hiding required documentation, deleting unique evidence, randomizing the answer or making commands artificially slow.

Expose raw data behind aggregations, workload/cohort identifiers, UTC timestamps and event-relative monotonic timings. Document scrape intervals, sampling and lag; critical evidence lag must be at most 30 seconds. Missing traces must have a documented alternative through correlated structured logs and metrics. All false leads require a discoverable disqualifying observation. Verify these paths from the candidate's permissions.

## Local platform, versions and resource contract

Implement only the technologies needed by the weekly scenario. Pin runtime/tool versions, OCI image digests, application dependency locks and Terraform provider locks where applicable; record them in `environment.lock.json`. Avoid mutable `latest` tags and undocumented paid features. Document bootstrap network downloads; the prepared exercise must run without external production dependencies.

Support Windows PowerShell with Docker Desktop/WSL2, or Linux with Docker. Provide `scripts/labctl.py` as the portable command interface; Bash wrappers may be added but cannot be the only documented interface. Check Docker context and namespaced resource ownership before operations. Host networking capability gaps are a preflight failure, not a candidate incident.

Target a declared lab allocation of 8 vCPU, 16 GiB RAM and 60 GiB free storage. Publish measured per-service budgets and total footprint; these numbers are a design budget, not a compatibility claim until tested. An optional 4 vCPU/8 GiB profile may reduce traffic and heap sizes only after proving the same causal mechanism and acceptance separation. Never silently remove services, increase timeouts or change the fault to fit hardware. If the available machine cannot sustain the contract, report `PLATFORM_BLOCKED` with measurements.

Preflight records available CPU/RAM/disk, container limits, versions and clock alignment. Healthy controls must sustain all required loads inside the fixed resource ceiling with no host OOM, generator drops or host-wide pressure causing failures. Intended resource saturation inside the faulty application is allowed and must be distinguishable from a failing lab host.

## Frozen workload and observable outcomes

Before publishing the exercise, qualify and freeze `acceptance.json`, `workload.json`, neutral initial data, service resource ceilings, relevant operational timing ranges and named hardware profile. These are business and platform contracts, not a disclosure of the fault. The candidate receives the frozen contracts and their hashes. Tests and service objectives cannot be loosened to pass a repair.

Use a paced, open-loop arrival schedule with reproducible business-operation sequences. Default nominal load `B` is 20 logical operations/second; a supported hardware profile may choose another published value at or above 10 only before handover and after control qualification. The generator must record scheduled/actually sent operations, dropped iterations, client deadline failures and all attempts. Insufficient generator capacity makes a run `INVALID`; it cannot count as service recovery. Retries must not reduce the scheduled external arrival rate.

Freeze business-operation mixes and cohorts. Use distinct public sequence seeds `20260905`, `20260906`, `20260907` for training and acceptance; fault identity does not change with seed. Ensure every critical operation/cohort has at least 500 observations in the steady acceptance window, and the window has at least 6,000 logical operations in total. A critical cohort must be at least 10% of the traffic or the window must be lengthened. Do not average away a failing operation or tenant.

The normal exercise fault must cause the weekly symptom envelope in a defined five-minute affected window, typically 15–35% failed/timed-out operations or p99 above five seconds. A weekly explicit event window, such as Week 5's 60–180 second release window, replaces that generic five-minute window. Preserve some successful customer operations. Generate failures through the real defective mechanism, never random status-code injection or load-script assertions pretending to be a server fault. The healthy control must meet the objectives at the same load, limits and initial state.

Customer acceptance defaults, fixed before handover:

- At steady `B` and burst `1.5B`: at least 99.5% logical-operation success, p95 at most 500 ms, p99 at most 1,500 ms; client deadline 12 seconds. A documented workload-specific substitute must be numerically fixed and control-qualified before handover, never after seeing a candidate repair.
- Evaluate each critical operation/cohort as well as the aggregate. Expected synthetic negative requests have their own contract and cannot inflate success. Rejected/deferred critical work remains visible in the offered-demand denominator.
- Measure end-to-end logical latency including all retries. Deadline failures count as failures and censored latency at least equal to the deadline; never drop them from percentile reporting. Report successful latency separately from all-outcome latency. Record sample counts and confidence intervals for rates; no claim of production SLO certainty from a short lab window.
- For writes, one durable business effect per idempotency key. Transport/message duplicates may occur, but duplicate business effects, lost acknowledged operations and inconsistent ledger/order state must equal zero. Reconcile client receipts, durable records and asynchronous effects after settling; do not treat a 2xx or queue acknowledgement as proof of correctness.
- Track retry attempts per logical operation, useful throughput, resource saturation and dependency load. A fix cannot pass by dropping critical work, disabling required features, bypassing correctness or exceeding frozen resource ceilings.

For an asynchronous API, the synchronous latency objective measures the admission receipt; separately measure business completion from initial submission, and require both SLIs. A receipt cannot count as completed business work. For every applicable async path, define an accepted-operation completion objective: at least 99.5% complete within 30 seconds at steady load, oldest-message age at most 30 seconds in steady windows, burst peak age at most 120 seconds, and queue depth/age back within baseline envelope within 300 seconds after a burst. Publish operation-specific exceptions before handover with control evidence. Account explicitly for redelivery, in-flight work, retries and dead-lettered messages; silently discarding or dead-lettering business work is not recovery.

## Recurrence, mitigation and sustained recovery

Publish normal timing ranges for all relevant caches, pools, leases, retry budgets, workers and releases in neutral operational documentation. Define a common observation horizon `T` that covers these ranges without naming which one is faulty; all scenario cycles must fit within 300 seconds. Time-compressed local behavior is allowed only if documented and checked to preserve event ordering and the mechanism.

Provide two materially different, reversible response options with business tradeoffs. At least one must reduce measured customer impact promptly while leaving a documented risk of recurrence. The candidate is not told which option has that property. Credit an informed temporary mitigation; distinguish `MITIGATED` from `RECOVERED`. Do not punish a successful early mitigation because it is not the final fix, and do not require the learner to restore customer harm just to collect proof. Capture evidence first where feasible and use an isolated replay for counterfactual work.

Full recovery uses the unchanged public evaluator and requires:

1. Steady `B` for `max(15 minutes, 3*T)`, meeting sample minima and all business objectives.
2. Three burst cycles, each two minutes at `1.5B` followed by three minutes at `B`; inspect each burst and recovery window, not only their combined average. Async scenarios must regain their baseline queue envelope before the next burst. If a control-qualified drain needs longer, freeze interburst gaps up to five minutes before handover and include the extra time in the full-suite budget.
3. Five minutes idle, then ten minutes at `B`, using a second sequence seed, to expose state-dependent recurrence.
4. Successful reconciliation of acknowledged operations and async effects, and resource/retry/backlog convergence with no sustained growth. Queue tests additionally obey their drain horizon.
5. Weekly additions such as repeat deployment or DNS/session cycling, using the same frozen workload and candidate repair. Report any overlap with the common windows explicitly; do not skip cycles or sample gates to finish faster.

Order the phases and overlap compatible weekly checks so the default common run takes 45 minutes and the full published suite fits within 60 minutes. Qualify this before handover. If it cannot fit while preserving coverage, revise the scenario before publishing; do not silently shorten validation during the exercise.

A symptom-only smoke test is a fast triage aid; it is not final recovery acceptance. Report `BROKEN`, `MITIGATED`, `RECOVERED`, `INVALID` and `NOT_VERIFIED` separately. Lower traffic, unlimited replicas or a quiet post-rollout period cannot establish full recovery.

## Reproducible lifecycle and candidate interface

Implement the following interface in `scripts/labctl.py` with `--help`, documented working directory and namespaced local resources:

| Command | Required behavior |
|---|---|
| `preflight` | Check tools, hardware, ports, locks, permissions, generator capacity and clock consistency. |
| `bootstrap` | Start the candidate system with original faulty code/config and neutral initial data; do not claim the incident is active until a trigger has run. |
| `trigger --seed 20260905` | Orchestrate the weekly workload, state preparation and event/release replay; record seed, run ID and monotonic event markers without diagnostic hints. |
| `traffic --profile nominal --seed 20260905` | Run the public workload independently; expose attempts, logical outcomes and generator validity. |
| `smoke` | Report customer-level symptoms and exit nonzero on failure, without naming the cause. |
| `snapshot` | Capture neutral status, recent logs, raw metrics, traces, in-flight/backlog state and change history. |
| `accept --suite full` | Run the frozen recovery suite against current candidate code/config; never reset or replace the candidate repair. |
| `replay-state --seed 20260906` | Restore only declared business/state fixtures for another run while preserving candidate code/config changes. |
| `reset --confirm-discard-lab-changes` | Snapshot/export learner work, then restore the immutable original faulty code/config AND state, queues, clocks/relative schedules and deployment starting versions. Scope to explicitly named lab resources. |
| `pause` / `resume` | For the scheduled local-lab break, preserve evidence and suspend the declared event/traffic clock consistently; resume must not count paused time as an acceptance window. |
| `stop` | Stop only owned resources. Preserve response notes and evidence. |

`reset` is intentionally destructive to lab experiments; show resolved targets and preserve exported patches/notes in a non-reset evidence directory. Never run broad workspace clean/delete or reset another repository. Final qualification must prove both that `reset` restores the faulty scenario and that `accept`/`replay-state` preserve a trial repair.

Candidate documentation includes prerequisites, setup/stop/reset/replay, neutral architecture and normal invariants, all URLs/ports, telemetry discovery, normal timing ranges, resource ceilings, business acceptance and scoring. An incident ticket includes severity, business impact, customer reports, timestamped changes and observations, never diagnosis. Supply realistic operational context without a troubleshooting sequence or suspicious labels.

## Six-hour response exercise and course progression

Prerequisite checks and lab provisioning occur before the six-hour clock. Each week defines a healthy-system prelab, what it adds beyond earlier weeks, transfer evidence and a targeted remediation exercise. Prior-week source code is not required to bootstrap a later week. The facilitator privately checks that overlapping weeks do not recycle the same primary mechanism, using a course scenario registry outside the candidate artifact. When a week is built in isolation without that registry, mark the non-repetition check `NOT VERIFIED`; do not invent knowledge of an earlier root cause.

All response actions, including safe rollback, traffic control and mitigation, are allowed from minute zero. Use six active hours with these flexible checkpoints; reward outcomes, not waiting for a scheduled phase:

| Active elapsed time | Expected artifact/action |
|---|---|
| 0–15 min | Scope customer impact, set severity, declare incident ownership, snapshot evidence and choose immediate protection. |
| 15–60 min | Execute or explicitly justify deferring a bounded mitigation; record measured benefit, risk, rollback and next update. |
| 60–150 min | Test competing hypotheses, update a causal graph and run isolated discriminating experiments. |
| 150–180 min | Handover with known/unknown state, mitigation expiry/risks and next actions; preserve or pause the local exercise for lunch. |
| 180–255 min | Implement a bounded durable change, explain alternatives and add regression protection. Earlier repair is welcome. |
| 255–315 min | Complete up to 60 minutes of frozen full acceptance and reconciliation; report residual uncertainty. |
| 315–360 min | Deliver RCA, stakeholder update, prioritized prevention and a technical defense. |

For the 09:00–12:00 / 14:00–17:00 schedule, lunch is a controlled simulation pause or explicit facilitator handover, not an unattended production outage. In solo mode the learner writes IC, operations and communications artifacts themselves. Do not require additional people or agents to run the lab. Facilitator role-play uses a fixed script and cannot introduce a second technical fault or change acceptance criteria mid-run.

Provide stakeholder requests at +20 minutes (impact/next update), +60 minutes (service restoration versus correctness/cost), +150 minutes (handover) and during final defense (why this change, what evidence would falsify it). Release all requested factual answers through a neutral lookup sheet so solo learners are not blocked. Brief status updates every 30 active minutes must distinguish facts, hypotheses, actions and uncertainty; drafting them does not authorize sending real messages.

## Public responder rubric — 100 points

This scores the responder, not the prompt author's design. Use timestamped artifacts and actual outputs. Each item receives full points when demonstrated, half for sound but incomplete evidence and zero when unsupported. Do not award points for command count, hours spent or matching the author's wording.

| Area | Points and observable subcriteria |
|---|---|
| Impact and containment | 20: operation/cohort scope 5; severity and business consequences 5; safe timely protection or evidence-backed deferral 5; snapshot and rollback plan 5. |
| Causal reasoning | 25: falsifiable mechanism 5; provenance/time alignment 5; two alternatives with discriminators 5; matched intervention/control 5; primary/contributor/symptom separation 5. |
| Recovery and correctness | 25: critical operation SLIs 5; sustained/burst/idle-resume gates 5; durable business reconciliation 5; repeated trigger/second seed 5; fixed load/resource budget and valid generator 5. |
| Operational judgment | 15: compare two viable mitigations 5; measure benefit/recurrence/residual risk 5; bounded durable repair with safe rollback 5. |
| Coordination and communication | 10: clear ownership/escalation decision 3; factual timed updates 3; usable handover and stakeholder tradeoff explanation 4. |
| Prevention and learning | 5: mechanism-specific regression protection 2; prioritized owner/verification-bound follow-up 2; one transferable lesson and remaining uncertainty 1. |

Numeric bands: 90–100 advanced mastery; 80–89 strong performance; 65–79 targeted practice needed; below 65 repeat after prelab remediation. These are exercise outcomes, not employment-level certifications.

Hard gates apply regardless of total: no validated sustained recovery means `INCOMPLETE`; lost acknowledged work, duplicate business effects, altered evaluator/contract, fabricated evidence or uncontained actions mean `NOT_PASSED`. Honest uncertainty is preferable to an unsupported success claim. A safe mitigation without a durable repair earns its demonstrated category points but does not pass the recovery gate. Facilitator setup failures invalidate the affected assessment and do not penalize the learner.

## Build qualification, private control and calibration

Before declaring the lab technically qualified, the facilitator must execute and preserve run IDs, commands, exit codes, versions, profile/state hashes, windows, sample counts and reconciliation output for all of these:

1. Schema/preflight checks and clean bootstrap on the declared platform.
2. Healthy control in an isolated copy passes the full frozen suite under the same resource ceilings. Required dependency service/version capability probes must pass before fault injection.
3. Original faulty state reproduces the weekly symptom envelope on three cold resets spanning at least two fixed sequence seeds; every run has sufficient candidate-accessible evidence and valid generator output.
4. Each contributor has measurable causal effect. Each distraction is real and has an accessible disqualifier; check the weekly exact minima. Validate the five-role causal proof matrix and two competing explanations.
5. A reversible mitigation improves measured customer impact, followed by recurrence or a demonstrated remaining failure mode during sustained load/state replay; preserve the distinction between symptom relief and full recovery.
6. At least one durable reference repair passes full acceptance, all weekly additions and an independent seed in a disposable facilitator copy. Reject a known superficial-only change and an insufficient-duration evaluation. Record any second acceptable repair family and its tradeoffs; never reject a candidate merely for choosing a different valid family.
7. A deliberate business-integrity violation is caught by reconciliation; an invalid generator, insufficient sample count and altered contract are detected as invalid rather than pass. These are evaluator qualification checks, not additional faults left in the candidate scenario.
8. `reset` returns the original faulty code/config/state/trigger; `replay-state` and `accept` preserve a reference repair. Week 5 must replay a release; Week 8 must validate its four distractions, three contributors, four boundaries and async invariants, not weaker common minima.
9. The full public acceptance finishes within its published 60-minute bound and stays inside host budgets. Verify pause/resume semantics, cleanup scope and learner artifact preservation.
10. Candidate artifact leak review covers files, history, images, mount paths and outputs. Export a neutral qualification summary while keeping diagnostic proof private. Finish by restoring and triggering the original incident for handover, or explicitly report `ARMED` for a transient event awaiting candidate replay.

Use these release states honestly: `DESIGN_REVIEWED` (text checked), `BUILT_NOT_QUALIFIED` (runs but evidence incomplete), `TECHNICALLY_QUALIFIED` (all technical gates actually passed), `BLIND_CALIBRATED` (technical gates plus pilots). Required but unexecuted checks are `NOT VERIFIED`, never implied passes. A blocker report may explain an environment limitation to the owner without revealing a solution to the responder.

Difficulty calibration requires two independent engineers familiar with the stack but unfamiliar with the scenario. Record time to first useful mitigation, defensible diagnosis, verified recovery, unsupported detours, hint use and perceived fairness. Aim for substantial cross-layer reasoning and safe recovery within six active hours; do not punish a fast expert. If both finish trivially, fail for the same inaccessible clue or need more than six hours because of setup/runtime delays, adjust the design and rerun calibration before claiming measured difficulty. No pilots means difficulty remains a design estimate.

## Final handover

Tell the candidate only the start/trigger/replay/reset/smoke/accept commands, ports, artifacts to submit, frozen business objectives, public rubric and actual current state (`ACTIVE`, `ARMED` or blocked). For a transient incident, state that replay is required and provide timestamped historical customer symptoms; do not assert continuing errors after the window has ended. Do not reveal the mechanism, likely cause, suspicious file, special mitigation or investigation order.

Report owner-facing qualification status separately. Preserve original broken handover behavior without pretending that healthy-control or reference-repair checks were unnecessary or already executed.
