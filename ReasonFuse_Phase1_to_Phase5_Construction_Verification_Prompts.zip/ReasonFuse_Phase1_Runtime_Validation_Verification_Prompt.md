# ReasonFuse Phase 1 — Runtime Validation Verification Prompt

> **Purpose:** Independently validate the Phase 1 runtime construction against the frozen ReasonFuse v4.1.3 architecture.  
> **Audience:** GPT-6 Astra / independent validation agent  
> **Phase:** 1 — Runtime Validation  
> **Role:** Validator, not implementer  
> **Rule:** Do not award PASS based on code inspection alone.

---

# 1. Mission

Your job is to verify whether the four architecture-critical runtime assumptions work in real execution.

You are NOT here to improve the architecture.

You are NOT here to expand the system.

You are NOT here to reward partial implementation.

You must execute the real integration paths, capture evidence, and return:

```text
Spike 1 — PASS / FAIL
Spike 2 — PASS / FAIL
Spike 3 — PASS / FAIL
Spike 4 — PASS / FAIL

Architecture Unfreeze Required? YES / NO

PHASE 1 RESULT:
PASS / BLOCKED
```

Phase 1 passes only if:

```text
4 / 4 spikes PASS
```

---

# 2. Validation Principles

## Principle 1 — Trust Execution, Not Claims

Do not accept:

```text
"the code looks correct"
"the SDK should support this"
"the docs say this is valid"
"unit tests pass"
"Terraform plan succeeds"
```

as proof of a spike.

Require real execution evidence.

---

## Principle 2 — Do Not Fix Failures Silently

If a spike fails:

```text
preserve evidence
identify the failing assumption
mark FAIL
```

You may make small diagnostic changes, but do not redesign the system and then pretend the original architecture passed.

---

## Principle 3 — Distinguish Implementation Bug from Architecture Failure

Classify every failure as one of:

```text
IMPLEMENTATION_BUG
CONFIGURATION_ERROR
ENVIRONMENT_ERROR
SDK_VERSION_INCOMPATIBILITY
ARCHITECTURE_ASSUMPTION_FAILURE
```

Only the last category automatically triggers:

```text
Architecture Unfreeze Required = YES
```

---

# 3. Pre-Validation Environment Audit

Before validating spikes, record:

```text
date/time
Azure subscription / Foundry project
region
Hosted Agent versions
Toolbox version
model deployment
APIM endpoint

Python version
agent-framework version
agent-framework-foundry version
agent-framework-foundry-hosting version
azure-ai-projects version
azure-identity version

azd version
terraform version
azurerm provider version
azapi provider version if present
```

Confirm dependency files use exact pins.

Run:

```text
scripts/preflight.sh
```

Record:

```text
exit code
output
failures if any
```

If preflight fails because the environment is not deployable, Phase 1 cannot PASS.

---

# 4. Spike 1 Validation — Responses History + AgentSession

## Frozen Assumption

```text
Foundry Agent Server
=
canonical conversation-history owner

AgentSession
=
runtime/provider/ReasonFuse state owner
```

Required host configuration:

```text
ResponsesHostServer(
    history_source="agent_server"
)
```

Required downstream behavior:

```text
store = false
```

---

## Test A — Multi-Turn History

Start a new conversation.

Turn 1:

```text
My service is unhealthy.
Remember incident ID INC-001.
```

Record:

```text
conversation_id
agent_session_id
response
```

Turn 2, same conversation:

```text
What incident ID are we investigating?
```

Expected:

```text
INC-001
```

---

## Test B — AgentSession State

Before or during Turn 1, ensure:

```text
reasonfuse_test_state = "RF-STATE-001"
```

is stored in AgentSession state.

After Turn 2, verify:

```text
reasonfuse_test_state == "RF-STATE-001"
```

using runtime/session evidence, not an LLM-generated statement.

---

## Test C — Duplicate History Detection

Inspect available logs/traces/message counts.

Look for:

```text
duplicate user message
duplicate assistant message
duplicate tool call
replayed transcript
duplicate continuation
```

There must be no evidence that a second HistoryProvider reloads the same canonical conversation.

---

## Spike 1 PASS Criteria

All must be true:

```text
[ ] Turn 2 remembers INC-001
[ ] Foundry conversation is the canonical transcript
[ ] AgentSession preserves RF-STATE-001
[ ] store=False is active
[ ] no duplicate history is observed
[ ] no custom canonical history store is required
```

If any frozen ownership assumption fails in real execution:

```text
Spike 1 = FAIL
Architecture Unfreeze Required = YES
```

---

# 5. Spike 2 Validation — Local Toolbox Interception

## Frozen Assumption

Every ReasonFuse-critical tool can execute through:

```text
Agent Framework
 ↓
Function Calling Middleware
 ↓
Local Tool / MCP Invocation
 ↓
Foundry Toolbox
```

and can be intercepted before execution.

This is the most important Phase 1 spike.

---

## Test A — Allow Path

Call:

```text
dns_resolution("api.reasonfuse.local")
```

Capture logs.

Required observable order:

```text
BEFORE dns_resolution
TOOL EXECUTED
AFTER dns_resolution
```

Confirm BEFORE sees:

```text
tool name
arguments
```

Confirm AFTER sees:

```text
tool result
```

---

## Test B — Block Path

Call:

```text
dns_resolution("blocked.reasonfuse.local")
```

Required:

```text
BEFORE
BLOCK
```

Forbidden:

```text
TOOL EXECUTED
AFTER with a real external result
```

Use an external/tool execution counter or equivalent evidence.

Required:

```text
execution_count delta = 0
```

Do not accept middleware logs alone if the tool could still have executed.

---

## Test C — Repeatability

Run Allow and Block tests more than once.

Confirm behavior is deterministic.

---

## Spike 2 PASS Criteria

```text
[ ] BEFORE observes tool name
[ ] BEFORE observes args
[ ] allowed call executes
[ ] AFTER observes result
[ ] blocked call never executes externally
[ ] block decision is made before execution
[ ] path uses local Agent Framework invocation
[ ] Foundry Toolbox remains the managed tool surface
```

If Foundry Toolbox critical calls cannot be intercepted before execution using the selected supported local integration:

```text
Spike 2 = FAIL
Architecture Unfreeze Required = YES
```

---

# 6. Spike 3 Validation — R2 Human Approval Round-trip

## Frozen Assumption

A high-impact tool can:

```text
pause before execution
→ request approval
→ preserve AgentSession state
→ resume exact action
→ execute once
```

---

## Test A — Approval Pause

Set:

```text
reasonfuse_test_counter = 7
```

Request:

```text
restart_service("orders")
```

Before approval:

```text
tool execution count must remain 0
```

---

## Test B — Approve Exact Action

Approve:

```text
restart_service("orders")
```

Required:

```text
tool executes exactly once
```

After execution confirm:

```text
reasonfuse_test_counter == 7
```

---

## Test C — Denial

Request:

```text
restart_service("payments")
```

Deny.

Required:

```text
tool execution count delta = 0
```

---

## Test D — Approval Binding

Approve only:

```text
restart_service("orders")
```

Then attempt:

```text
restart_service("payments")
```

without a new approval.

Required:

```text
payments action does not execute
```

---

## Test E — One-Time Consumption

Try to replay the same approval if the framework exposes a replay path.

Required:

```text
no duplicate side effect
```

---

## Spike 3 PASS Criteria

```text
[ ] R2 pauses before execution
[ ] approve resumes exact action
[ ] approved action executes once
[ ] deny prevents execution
[ ] AgentSession state survives round-trip
[ ] approval is bound to exact args
[ ] approval cannot silently authorize another action
```

If runtime approval cannot safely preserve/restore the required state:

```text
Spike 3 = FAIL
Architecture Unfreeze Required = YES
```

---

# 7. Spike 4 Validation — APIM Sticky Canary + SSE

## Frozen Assumption

APIM can provide:

```text
weighted Stable/Candidate routing
+
sticky release affinity
+
unbuffered Responses streaming
```

---

# 7A. Sticky Canary Validation

Confirm backend configuration:

```text
Stable weight    = 95
Candidate weight = 5
session affinity = ON
```

Use one persistent HTTP client/session.

Perform:

```text
Turn 1
Turn 2
Turn 3
Turn 4
Turn 5
```

Record:

```text
release_role
affinity cookie/header state
request ID
```

Expected:

```text
all five turns use the same release backend
```

Example valid:

```text
Candidate
Candidate
Candidate
Candidate
Candidate
```

Example invalid:

```text
Candidate
Stable
Candidate
Stable
```

---

## Negative Control

Create a brand-new HTTP client/session.

Do not reuse the previous affinity state.

Confirm it can independently receive a release assignment.

This proves the observed stickiness comes from affinity, not hard-coded routing.

---

# 7B. SSE Streaming Validation

Call an endpoint that emits:

```text
chunk-1
chunk-2
chunk-3
chunk-4
```

Capture client receive timestamps.

Required:

```text
chunk-1 arrives before final completion
chunk-2 arrives before final completion
chunk-3 arrives before final completion
```

Verify APIM configuration:

```text
buffer-response = false
response caching = OFF
streaming body diagnostics = OFF
```

Do not accept one complete payload split locally after receipt.

---

## Spike 4 PASS Criteria

```text
[ ] weighted pool is active
[ ] affinity state is issued/preserved
[ ] same client stays on one backend
[ ] new client can be assigned independently
[ ] SSE chunks arrive incrementally
[ ] APIM does not buffer complete response
```

If APIM cannot preserve the required release affinity for the chosen client flow:

```text
Spike 4 = FAIL
Architecture Unfreeze Required = YES
```

---

# 8. Clean-Start Validation

After individual spikes pass:

```text
destroy/reset temporary state as appropriate
restart from a clean local environment
deploy using documented scripts
run preflight
rerun all four spikes
```

The result must be reproducible.

One lucky run is not enough.

---

# 9. Evidence Requirements

For every PASS claim, capture:

```text
command
timestamp
exit code
relevant logs
trace/request IDs where available
conversation/session IDs
execution counters
HTTP affinity evidence
stream timestamps
package versions
```

Do not expose:

```text
tokens
passwords
secrets
connection strings
```

Redact sensitive values.

---

# 10. Validation Report

Update:

```text
PHASE1_REPORT.md
```

Use this structure.

```text
# Phase 1 Runtime Validation Report

## Environment
...

## Spike 1 — Responses History + AgentSession
Status: PASS / FAIL
Evidence:
...
Failure Classification:
...

## Spike 2 — Local Toolbox Interception
Status: PASS / FAIL
Evidence:
...
Failure Classification:
...

## Spike 3 — R2 Human Approval
Status: PASS / FAIL
Evidence:
...
Failure Classification:
...

## Spike 4 — APIM Sticky Canary + SSE
Status: PASS / FAIL
Evidence:
...
Failure Classification:
...

## Clean-Start Revalidation
Status: PASS / FAIL

## Architecture Unfreeze Required?
YES / NO

Reason:
...

## Phase 1 Result
PASS / BLOCKED
```

---

# 11. Final Decision Rules

## PASS

Only return:

```text
PHASE 1 RESULT: PASS
```

when:

```text
Spike 1 PASS
AND
Spike 2 PASS
AND
Spike 3 PASS
AND
Spike 4 PASS
AND
clean-start revalidation PASS
```

---

## BLOCKED

Return:

```text
PHASE 1 RESULT: BLOCKED
```

if any critical spike fails after reasonable diagnostic work.

Do not weaken the acceptance criteria to obtain a PASS.

---

# 12. Final Validator Instruction

Your job is to falsify the architecture assumptions if they are wrong.

Do not optimize for making the project look successful.

Optimize for certainty.

The most valuable Phase 1 result is either:

```text
4 / 4 PASS
→ architecture is validated
→ proceed to Phase 2
```

or:

```text
a precise FAIL
→ architecture assumption identified early
→ evidence preserved
→ Phase 2 avoided until corrected
```

Never return PASS because the implementation appears plausible.
