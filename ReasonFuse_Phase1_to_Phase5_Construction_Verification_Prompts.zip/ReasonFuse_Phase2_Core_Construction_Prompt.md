# ReasonFuse Phase 2 — Core Construction Prompt

> **Purpose:** Implement the first real working ReasonFuse P0 core on top of the validated Phase 1 runtime.  
> **Audience:** GPT-6 Astra / coding agent  
> **Phase:** 2 — ReasonFuse Core  
> **Expected effort:** 10–14 hours  
> **Prerequisite:** Phase 1 Runtime Validation = **4/4 PASS**  
> **Architecture status:** FROZEN — ReasonFuse v4.1.3 / v4.1.2 freeze lineage  
> **Primary Exit Gate:** `ReasonFuse OFF/ON + Outcome Verification PASS`

---

# 1. Mission

Phase 2 is the first phase in which you implement the actual ReasonFuse product logic.

You are no longer validating whether the Microsoft runtime can support the architecture. Phase 1 already proved that.

Your job is to build the smallest production-shaped ReasonFuse core that can demonstrate:

```text
1. Runtime objective-progress tracking
2. Exact-loop detection
3. Oscillation detection
4. Retrieval-churn detection
5. Useful-recheck preservation
6. Run Contract enforcement
7. Outcome Verification
8. Deterministic containment
9. ReasonFuse OFF / ON behavioral contrast
```

The Phase 2 result must be a working P0 core, not a prototype that only passes mocked unit tests.

---

# 2. Hard Prerequisite

Before changing code, inspect the Phase 1 report.

Required:

```text
Spike 1 — PASS
Spike 2 — PASS
Spike 3 — PASS
Spike 4 — PASS

Architecture Unfreeze Required?
NO
```

If Phase 1 is not fully PASS:

```text
STOP
```

Do not continue Phase 2 against an unvalidated runtime.

---

# 3. Frozen Runtime Boundary

Do not redesign this:

```text
Foundry Hosted Agent
 ↓
Responses 2.0.0
 ↓
ResponsesHostServer(
    history_source="agent_server"
)
 ↓
Agent Framework Agent
 ├─ TodoProvider
 ├─ AgentModeProvider
 ├─ AgentSession
 ├─ Tool Approval
 └─ ReasonFuse Middleware
      ├─ Agent Run Middleware
      └─ Function Calling Middleware
            ↓
      Local Tool / MCP Invocation
            ↓
      Foundry Toolbox
      ├─ Foundry IQ / retrieval path
      └─ Operations OpenAPI
            ↓
      Outcome Verifier
```

Phase 2 must extend this exact runtime.

---

# 4. Non-Negotiable Rules

## Rule 1 — No Architecture Expansion

Do not add:

```text
Redis
Cosmos DB
Postgres
AKS
Kubernetes
Service Bus
Event Hub
Durable Functions
custom conversation store
custom approval database
custom RAG platform
custom MCP transport
multi-agent orchestration
custom evaluation platform
```

Phase 2 is a core-behavior phase.

---

## Rule 2 — Deterministic Runtime Decisions

Runtime containment must not depend on:

```text
LLM judge
free-form model confidence
arbitrary model self-assessment
natural-language "progress score"
```

ReasonFuse runtime decisions must be based on structured state and deterministic rules.

---

## Rule 3 — Todo Is Planning, Not Objective Progress

`Todo Delta` may be captured, but:

```text
Todo Delta alone
MUST NOT
reset the no-progress timer
```

Objective progress is:

```text
Evidence Delta
World-State Delta
Retrieval Delta
Postcondition Delta
```

---

## Rule 4 — Preserve Useful Rechecks

Repeated calls are not automatically bad.

ReasonFuse must allow legitimate verification after meaningful state change.

This is a required correctness property, not an optional enhancement.

---

# 5. Phase 2 Deliverables

Implement the following P0 modules:

```text
ReasonFuse State
Trajectory Model
Progress Engine

Evidence Delta
World-State Delta
Retrieval Delta
Todo Delta as planning signal
Postcondition Delta

Exact Loop Detector
Oscillation Detector
Retrieval Churn Detector
Useful Recheck Classifier

Run Contract
Behavioral Fuse
Containment Result

Postcondition Registry
Outcome Verifier

ReasonFuse OFF mode
ReasonFuse ON mode

Core integration tests
Core live scenarios
Phase 2 evidence
PHASE2_REPORT.md
```

---

# 6. Recommended Repository Structure

Use or adapt the existing repository.

Recommended:

```text
src/reasonfuse_agent/
├── agent.py
├── state/
│   └── reasonfuse_state.py
│
├── middleware/
│   ├── run_middleware.py
│   └── function_middleware.py
│
├── behavioral/
│   ├── trajectory.py
│   ├── progress_engine.py
│   ├── evidence_delta.py
│   ├── world_state_delta.py
│   ├── retrieval_delta.py
│   ├── todo_delta.py
│   ├── useful_recheck.py
│   ├── exact_loop.py
│   ├── oscillation.py
│   ├── retrieval_churn.py
│   ├── run_contract.py
│   └── behavioral_fuse.py
│
├── verification/
│   ├── registry.py
│   └── outcome_verifier.py
│
└── telemetry/
    └── tracing.py
```

Tests:

```text
tests/
├── unit/
│   ├── test_exact_loop.py
│   ├── test_oscillation.py
│   ├── test_retrieval_churn.py
│   ├── test_useful_recheck.py
│   ├── test_run_contract.py
│   └── test_outcome_verifier.py
│
└── integration/
    ├── test_off_on_no_progress.py
    ├── test_useful_recheck_live.py
    ├── test_outcome_failure_live.py
    └── test_budget_exhaustion_live.py
```

---

# 7. ReasonFuse State Model

Implement a typed structured state.

At minimum:

```text
run_id
conversation_id
agent_session_id

trajectory_state
progress_state

step_index
tool_call_count
side_effect_count

recent_actions[]
recent_action_fingerprints[]

evidence_keys[]
retrieval_evidence_keys[]
world_state_snapshot
todo_snapshot

stall_counter
oscillation_counter
retrieval_churn_counter

last_objective_progress_step

pending_postcondition
last_postcondition_result

run_contract_version
reasonfuse_enabled
```

State must live in `AgentSession`.

Do not rebuild it from prompt history.

---

# 8. Canonical Tool Call Fingerprint

Implement canonical argument normalization.

Fingerprint:

```text
SHA256(
    tool_name
    +
    canonical_json(args)
)
```

Canonicalization should ensure equivalent dictionaries serialize identically.

Examples:

```json
{"a":1,"b":2}
```

and

```json
{"b":2,"a":1}
```

must produce the same fingerprint.

Preserve explicit differences that actually change tool semantics.

---

# 9. Evidence Delta

Implement a structured evidence model.

Evidence Delta should represent new diagnostic information.

Examples of positive evidence:

```text
status changed from UNKNOWN → UNHEALTHY
dependency changed from UNKNOWN → DEGRADED
new distinct failure class observed
new source/citation materially changes the evidence set
```

Examples of zero evidence:

```text
same tool
same args
same result class
same external state
same retrieved sources
```

Do not use model prose length as evidence.

---

# 10. World-State Delta

Implement comparison of relevant external state.

Examples:

```text
service health
deployment version
database state
replica count
config version
restart generation
```

A real external state change is objective progress.

World-state representation may be normalized into a small deterministic dictionary.

---

# 11. Retrieval Delta

Use normalized retrieval evidence from the existing Foundry IQ / retrieval integration.

Prefer:

```text
source_keys[]
citation_ids[]
chunk_ids[] optional
scores[] optional
derived normalized content hashes optional
knowledge_base_version
```

Retrieval Delta is positive only when effective evidence changes materially.

Different query wording with equivalent evidence:

```text
Retrieval Delta = 0
```

---

# 12. Todo Delta

Capture:

```text
OPEN
IN_PROGRESS
COMPLETED
```

changes from TodoProvider.

Todo Delta is useful telemetry and planning context.

But:

```text
Todo Delta != Objective Progress
```

A Todo transition may be recorded while ReasonFuse remains STALLED.

---

# 13. Postcondition Delta

Implement postcondition observations for side effects.

At minimum Phase 2 must support:

```text
restart_service
→ required postcondition:
service_health == HEALTHY
```

Track:

```text
before state
accepted action
verification observation
final postcondition result
```

---

# 14. Progress Engine

Implement a deterministic progress decision.

Recommended conceptual output:

```text
objective_progress = true / false

signals:
  evidence_delta
  world_state_delta
  retrieval_delta
  postcondition_delta

planning_signal:
  todo_delta
```

Do not create a vague floating-point AI score.

A simple deterministic rule is acceptable:

```text
objective_progress = any(
    evidence_delta,
    world_state_delta,
    retrieval_delta,
    postcondition_delta
)
```

provided each delta is itself carefully defined.

---

# 15. Exact Loop Detector

Detect repeated identical tool-call fingerprints.

Example:

```text
dns_resolution("api")
dns_resolution("api")
dns_resolution("api")
```

with no objective progress.

Do not trip on the first legitimate retry.

Use Run Contract thresholds.

Expected result:

```text
EXACT_LOOP
```

---

# 16. Oscillation Detector

Detect alternating cycles such as:

```text
A → B → A → B
```

when no objective progress occurs.

At minimum detect period-2 oscillation.

Keep the implementation deterministic and bounded.

Expected result:

```text
OSCILLATING
```

Do not overengineer general sequence mining in Phase 2.

---

# 17. Retrieval Churn Detector

Detect repeated retrieval attempts that change query wording but not effective evidence.

Example:

```text
search("database failure")
→ sources {A,B}

search("db connectivity")
→ sources {A,B}

search("database issue")
→ sources {A,B}
```

with no new objective evidence.

Expected result:

```text
RETRIEVAL_CHURN
```

---

# 18. Useful Recheck Classifier

Required positive scenario:

```text
database_health()
 ↓
restart_service()
 ↓
database_health()
```

The second health check must be classified as useful because a side effect changed the world and verification is now required.

Required negative scenario:

```text
database_health()
 ↓
database_health()
 ↓
database_health()
```

with no state change.

This must be classified as wasteful repetition.

Recommended output:

```text
useful_recheck = true / false
reason = ...
```

Keep the reason deterministic.

---

# 19. Run Contract

Implement the frozen P0 contract:

```yaml
run_contract:
  max_steps: 12
  max_tool_calls: 10
  max_stalled_steps: 2
  max_oscillation_cycles: 2
  max_retrieval_churn: 3
  max_side_effects: 1
  required_objective_progress_interval: 2
  require_postcondition_for_side_effects: true
```

The exact defaults may be configuration, but tests must pin them.

Run Contract must support:

```text
BUDGET_EXHAUSTED
```

when limits are exceeded.

---

# 20. Behavioral Fuse

Implement deterministic containment.

Possible reasons:

```text
NO_PROGRESS
EXACT_LOOP
OSCILLATING
RETRIEVAL_CHURN
BUDGET_EXHAUSTED
POSTCONDITION_FAILED
```

When tripped, return a structured result.

Example:

```json
{
  "decision": "BLOCK",
  "trajectory_state": "STALLED",
  "fuse_reason": "NO_PROGRESS",
  "objective_progress": false,
  "step": 6
}
```

Do not merely stop with an exception.

---

# 21. ReasonFuse OFF Mode

Implement a runtime configuration:

```text
REASONFUSE_ENABLED=false
```

OFF mode must:

```text
observe telemetry if convenient
but NOT block the agent
```

This is required for the OFF/ON comparison.

Do not maintain two separate codebases.

Use the same agent and tools.

---

# 22. ReasonFuse ON Mode

Implement:

```text
REASONFUSE_ENABLED=true
```

ON mode must enforce the Run Contract and Behavioral Fuse.

Same prompt.
Same model.
Same tools.
Same world.
Only ReasonFuse enforcement differs.

---

# 23. Operations API Phase 2 Behavior

Make the Operations API deterministic enough to reproduce core cases.

At minimum support:

```text
service_status
database_health
dns_resolution
restart_service
```

Add deterministic scenario/fault state.

Example:

```text
scenario = no_progress_dns

dns_resolution()
→ always INCONCLUSIVE
```

Outcome-failure scenario:

```text
restart_service()
→ HTTP 202 / accepted
→ service remains UNHEALTHY
```

Useful-recheck scenario:

```text
restart_service()
→ accepted
→ service becomes HEALTHY
→ next health check verifies success
```

Keep scenario state resettable.

---

# 24. Postcondition Registry

Implement a small registry.

At minimum:

```text
restart_service:
  verify with service_status
  expected:
    service_health == HEALTHY
```

Registry design should support later extension but remain simple.

---

# 25. Outcome Verifier

Required outcomes:

```text
OUTCOME_VERIFIED
POSTCONDITION_FAILED
OUTCOME_UNKNOWN
```

Phase 2 must prove:

```text
HTTP 202 accepted
≠
successful outcome
```

Outcome verification must perform a real postcondition check against the deterministic Operations API.

---

# 26. Core Live Scenarios

Implement at least these scenarios.

## Scenario A — OFF No-Progress

```text
ReasonFuse OFF
dns/search investigation repeats
agent is allowed to continue
```

Capture redundant behavior.

---

## Scenario B — ON No-Progress

Same world, same prompt, same tool behavior.

Expected:

```text
objective_progress = false
→ STALLED
→ FUSE_TRIPPED
```

---

## Scenario C — Exact Loop

Expected:

```text
EXACT_LOOP
→ BLOCK
```

---

## Scenario D — Oscillation

Expected:

```text
OSCILLATING
→ BLOCK
```

---

## Scenario E — Retrieval Churn

Expected:

```text
RETRIEVAL_CHURN
→ BLOCK
```

If Foundry IQ is not yet fully integrated, use the validated retrieval abstraction with a deterministic local/fallback retrieval result, but do not change the architecture.

---

## Scenario F — Useful Recheck

Expected:

```text
restart
→ health recheck
→ ALLOW
```

No false positive.

---

## Scenario G — Outcome Failure

Expected:

```text
restart_service
→ accepted
→ postcondition fails
→ POSTCONDITION_FAILED
```

---

## Scenario H — Budget Exhaustion

Expected:

```text
Run Contract exceeded
→ BUDGET_EXHAUSTED
```

---

# 27. Telemetry

Emit structured OTel attributes/events where practical.

At minimum:

```text
reasonfuse.trajectory_state
reasonfuse.progress_state
reasonfuse.evidence_delta
reasonfuse.world_state_delta
reasonfuse.retrieval_delta
reasonfuse.todo_delta
reasonfuse.postcondition_delta
reasonfuse.useful_recheck
reasonfuse.failure_type
reasonfuse.fuse_reason
reasonfuse.contract_version
```

Do not build dashboards in Phase 2.

---

# 28. Test Strategy

Implement:

```text
unit tests
+
integration tests
+
live Hosted Agent scenarios
```

Unit tests must cover detector edge cases.

Integration tests must prove the middleware/state flow.

Live scenarios must prove the P0 behavior in the validated Microsoft runtime.

---

# 29. Phase 2 Required Acceptance Tests

Required:

```text
[ ] OFF mode does not block

[ ] ON mode blocks no-progress behavior

[ ] Exact Loop detector trips

[ ] Oscillation detector trips

[ ] Retrieval Churn detector trips

[ ] Useful Recheck scenario is preserved

[ ] Todo-only change does not count as objective progress

[ ] Run Contract budget exhaustion trips

[ ] restart_service accepted + unhealthy
    → POSTCONDITION_FAILED

[ ] restart_service accepted + healthy
    → OUTCOME_VERIFIED

[ ] ReasonFuse state persists through the run

[ ] local Function Middleware remains in the enforcement path
```

---

# 30. Evidence Capture

For every core scenario capture:

```text
scenario name
ReasonFuse OFF/ON
run_id
conversation_id
agent_session_id
tool sequence
objective progress signals
detector state
fuse decision
postcondition result
trace/request ID if available
exit result
```

Save under:

```text
evidence/phase2/
```

Do not store secrets.

---

# 31. PHASE2_REPORT.md

Create:

```text
# Phase 2 ReasonFuse Core Report

## Environment
...

## Core Modules Implemented
...

## Scenario A — OFF No-Progress
PASS / FAIL
Evidence: ...

## Scenario B — ON No-Progress
PASS / FAIL
Evidence: ...

## Scenario C — Exact Loop
PASS / FAIL

## Scenario D — Oscillation
PASS / FAIL

## Scenario E — Retrieval Churn
PASS / FAIL

## Scenario F — Useful Recheck
PASS / FAIL

## Scenario G — Outcome Failure
PASS / FAIL

## Scenario H — Budget Exhaustion
PASS / FAIL

## Outcome Verification
OUTCOME_VERIFIED case: PASS / FAIL
POSTCONDITION_FAILED case: PASS / FAIL

## Architecture Change Required?
YES / NO

## Phase 2 Result
PASS / BLOCKED
```

---

# 32. What Phase 2 Must NOT Do

Do not spend Phase 2 on:

```text
100-scenario benchmark
300-run benchmark
confusion matrix
APIM canary polish
Judge Mode final UI
user testing
video production
AI Red Teaming
advanced Foundry Evaluation
release automation
multi-region
production dashboards
```

Those belong to later phases.

---

# 33. Construction Completion Gate

Construction is complete when:

```text
[ ] all core modules exist
[ ] unit tests exist
[ ] integration tests exist
[ ] live scenario scripts exist
[ ] OFF/ON configuration exists
[ ] deterministic Operations API scenario state exists
[ ] Outcome Verifier is wired
[ ] telemetry exists
[ ] reset script works
[ ] PHASE2_REPORT.md template exists
```

At construction completion, state:

```text
PHASE 2 CONSTRUCTION COMPLETE
READY FOR INDEPENDENT VALIDATION
```

Do not self-award Phase 2 PASS unless the separate verification procedure is executed.
