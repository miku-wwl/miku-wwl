# Pushpay Senior SRE — 140 个核心主题 × 5 层问题库（中文版）

> **共 700 个面试问题，仅问题，无答案。**

每个 Topic 固定五层：

1. **`.1` — 基础定义**
2. **`.2` — 内部机制**
3. **`.3` — 生产场景**
4. **`.4` — 故障排查**
5. **`.5` — Senior Trade-off / Edge Case**

用于 Mock Interview 时，建议按顺序连续追问，而不是把 560 题当成互不相关的散题。

```text
Definition → Internals → Production → Failure Diagnosis → Senior Trade-off
```

---

# 01 — Git 内部原理

## Q1 — .git 目录

### Q1.1 — 基础定义

> 描述 `.git` 目录中包含什么，以及主要文件和子目录分别有什么作用。

### Q1.2 — 内部机制

> 解释 `HEAD`、`refs`、`index`、`objects`、`logs` 和 `packed-refs` 之间的关系。

### Q1.3 — 生产场景

> 开发者说工作区内容正确，但 Git 显示了意外的 staged changes。你会检查 `.git` 中哪些结构，为什么？

### Q1.4 — 故障排查

> 一次错误操作后，分支指针异常，而且几个 commit 看起来丢失了。请基于 Git internals 说明恢复思路。

### Q1.5 — Senior Trade-off / Edge Case

> 如果 reflog 不完整，而且可能已经执行过 garbage collection，还有哪些恢复手段？首先要保护什么证据？恢复能力的极限在哪里？

---

## Q2 — Git commit / tree / blob 对象

### Q2.1 — 基础定义

> Git commit object 到底是什么？

### Q2.2 — 内部机制

> 解释 commit、tree、blob 和 annotated tag 对象如何连接，以及 Git 如何进行 content addressing。

### Q2.3 — 生产场景

> 两个仓库包含相同文件内容，但提交历史不同。哪些对象可能相同，哪些通常会不同？

### Q2.4 — 故障排查

> 一个仓库看起来损坏了。你如何利用 object structure 和 `git fsck` 输出定位损坏范围？

### Q2.5 — Senior Trade-off / Edge Case

> Git 的 immutable content-addressed storage 带来了哪些优势？hash collision、packfile 和 GC 又会带来什么复杂度？

---

## Q3 — `git add` 与 index

### Q3.1 — 基础定义

> 执行 `git add` 时内部发生了什么？

### Q3.2 — 内部机制

> Git index 到底是什么？它与 working tree 和 `HEAD` 有什么区别？

### Q3.3 — 生产场景

> 一个文件只 stage 了部分修改。Git 如何表示这种状态？

### Q3.4 — 故障排查

> 事故修复中，开发者错误 stage 了不该提交的改动。如何在不丢失工作区内容的情况下安全修正？

### Q3.5 — Senior Trade-off / Edge Case

> 为什么 index 是 Git 很强的设计？脚本并发或错误操作 index 会有什么风险？

---

## Q4 — Branch 与 refs

### Q4.1 — 基础定义

> Git branch 本质上是什么？

### Q4.2 — 内部机制

> commit、merge、reset 和 fast-forward 时 branch ref 如何移动？

### Q4.3 — 生产场景

> 有人说“branch 里面包含一组 commits”。如何用 reachability 更精确地解释？

### Q4.4 — 故障排查

> release branch 被 force-push 到错误 commit。如何找到旧 tip 并安全恢复？

### Q4.5 — Senior Trade-off / Edge Case

> 什么时候 force-push 可以接受？生产工程流程中如何降低 ref 丢失风险？

---

## Q5 — HEAD 与 detached HEAD

### Q5.1 — 基础定义

> `HEAD` 在 Git 中是什么？

### Q5.2 — 内部机制

> 解释 symbolic `HEAD` 与 detached `HEAD` 的区别，以及两种状态下 commit 会发生什么。

### Q5.3 — 生产场景

> CI 直接 checkout 某个 commit SHA，然后在构建中创建了新 commit。这个 commit 会在哪里？

### Q5.4 — 故障排查

> 有人在 detached HEAD 中做了重要修改并 commit，随后切换了 branch。如何恢复？

### Q5.5 — Senior Trade-off / Edge Case

> 为什么 CI/CD 经常故意使用 detached HEAD？这对人工操作有什么风险？

---

## Q6 — Merge 与 Rebase

### Q6.1 — 基础定义

> merge 和 rebase 的区别是什么？

### Q6.2 — 内部机制

> 从 Git object graph 的角度解释 merge 与 rebase 分别改变了什么。

### Q6.3 — 生产场景

> 一个长期 feature branch 与 main 严重分叉。如何选择 merge、rebase 或重新整理分支？

### Q6.4 — 故障排查

> 共享 branch 被 rebase 后，协作者看到重复样的 commits。如何处理？

### Q6.5 — Senior Trade-off / Edge Case

> linear history 与保留 merge history 在可维护性、审计和事故取证上分别有什么 trade-off？

---

## Q7 — Git 仓库损坏

### Q7.1 — 基础定义

> Git repository corruption 是什么意思？

### Q7.2 — 内部机制

> refs 损坏与 objects 损坏有什么区别？

### Q7.3 — 生产场景

> 只有一个 build agent 报 Git object error，而其他 clone 都正常。如何区分本地磁盘问题与 remote repository 问题？

### Q7.4 — 故障排查

> 请给出一个安全的 corruption investigation 流程。

### Q7.5 — Senior Trade-off / Edge Case

> 在受监管生产环境中，修复前应如何做 evidence preservation 和 recovery？

---

## Q8 — 丢失 commit 的恢复

### Q8.1 — 基础定义

> 误执行 reset 后如何恢复 commits？

### Q8.2 — 内部机制

> 解释 reflog、unreachable objects 和 reachability 在恢复中的关系。

### Q8.3 — 生产场景

> 开发者 `reset --hard` 后又 force-push，remote 已不再引用三个 commits。怎么办？

### Q8.4 — 故障排查

> remote 没 reflog，而且 branch/ref 都找不到这些 commits，如何继续搜索？

### Q8.5 — Senior Trade-off / Edge Case

> GC 如何影响恢复窗口？哪些 repository policy 可以降低永久丢失概率？

---

# 02 — Linux / 操作系统

## Q9 — Process 与 Thread

### Q9.1 — 基础定义

> 解释 process 和 thread 的区别。

### Q9.2 — 内部机制

> threads 之间共享哪些资源，哪些状态是每个 thread 私有的？

### Q9.3 — 生产场景

> 一个多线程服务 CPU 很高，但只有一个 core 被打满。可能是什么原因？

### Q9.4 — 故障排查

> 如何判断瓶颈来自 lock contention、scheduler 还是某个 hot thread？

### Q9.5 — Senior Trade-off / Edge Case

> 从可靠性、隔离和运维角度，什么时候更适合多进程而不是多线程？

---

## Q10 — Linux 进程内存布局

### Q10.1 — 基础定义

> 描述典型 Linux process 的内存布局。

### Q10.2 — 内部机制

> 解释 text、data、BSS、heap、stack、shared libraries 和 mmap regions。

### Q10.3 — 生产场景

> process RSS 很高，但 heap 使用不高。可能是什么原因？

### Q10.4 — 故障排查

> 如何调查 anonymous mappings、shared mappings、page cache effects 和 native allocations？

### Q10.5 — Senior Trade-off / Edge Case

> 容器中哪些 memory metrics 最容易误导？如何同时看 host 和 cgroup 的真实 memory pressure？

---

## Q11 — Linux Load Average

### Q11.1 — 基础定义

> Linux load average 到底测量什么？

### Q11.2 — 内部机制

> 为什么 CPU utilization 很低时 load average 仍然可能很高？

### Q11.3 — 生产场景

> 16 核主机 load=30，但 CPU 只有 25%。你的主要 hypotheses 是什么？

### Q11.4 — 故障排查

> 如何证明 blocked I/O 是否导致高 load？

### Q11.5 — Senior Trade-off / Edge Case

> 如何设计 load average 告警，避免大量噪声？

---

## Q12 — CPU Saturation

### Q12.1 — 基础定义

> 生产环境 CPU 突然达到 100%，第一步怎么做？

### Q12.2 — 内部机制

> 解释 user、system、iowait、steal、IRQ、softirq 分别如何影响判断。

### Q12.3 — 生产场景

> Kubernetes node 在 deployment 后 CPU 饱和。如何区分应用 CPU、kernel overhead 和 noisy neighbour？

### Q12.4 — 故障排查

> 哪些工具可以定位 hot process、thread、syscall 和 code path，同时尽量不放大事故？

### Q12.5 — Senior Trade-off / Edge Case

> 什么时候应该 throttling、scaling、rollback 或 optimization？如何选择？

---

## Q13 — Memory Leak / Memory Growth

### Q13.1 — 基础定义

> 如何区分真正的 memory leak 与正常 memory growth？

### Q13.2 — 内部机制

> 解释 heap、native memory、page cache、mmap、allocator fragmentation 和 cgroup accounting。

### Q13.3 — 生产场景

> Java container 内存不断接近 limit，但 JVM heap 只有 60%。主要 hypotheses 是什么？

### Q13.4 — 故障排查

> 如何结合 container metrics、JVM/native data、`/proc` 和系统工具定位？

### Q13.5 — Senior Trade-off / Edge Case

> 事故中最安全的 remediation 是什么？长期如何防止复发？

---

## Q14 — Zombie Process

### Q14.1 — 基础定义

> 什么是 zombie process？

### Q14.2 — 内部机制

> 为什么 zombie 不能直接被 kill？

### Q14.3 — 生产场景

> 一个容器积累了几千个 zombies，这通常说明 PID 1 或 child reaping 有什么问题？

### Q14.4 — 故障排查

> 如何找到 parent process、确认机制并安全缓解？

### Q14.5 — Senior Trade-off / Edge Case

> 容器 entrypoint/init 设计如何避免 zombie accumulation？

---

## Q15 — File Descriptors

### Q15.1 — 基础定义

> 什么是 file descriptor？

### Q15.2 — 内部机制

> 文件、socket、pipe 等如何通过 file descriptor 表示？

### Q15.3 — 生产场景

> 应用开始报 `Too many open files`，最可能发生了什么？

### Q15.4 — 故障排查

> 如何利用 `/proc`、`lsof`、`ss`、limits 和应用 metrics 判断是 leak 还是合法增长？

### Q15.5 — Senior Trade-off / Edge Case

> 什么时候提高 `ulimit` 是正确的？什么时候只是在掩盖设计问题？

---

## Q16 — SIGTERM 与 SIGKILL

### Q16.1 — 基础定义

> SIGTERM 与 SIGKILL 有什么区别？

### Q16.2 — 内部机制

> kernel 与 application 对这两个 signal 分别能做什么？

### Q16.3 — 生产场景

> 一个 Kubernetes Pod 总要靠 `kill -9` 才能结束，可能有什么问题？

### Q16.4 — 故障排查

> 如何调查 stuck shutdown、blocked I/O、deadlock、preStop hook 和 termination grace period？

### Q16.5 — Senior Trade-off / Edge Case

> 一个生产服务应该实现怎样的 graceful shutdown contract？

---

# 03 — 网络

## Q17 — 打开 HTTPS URL 时发生什么

### Q17.1 — 基础定义

> 在浏览器输入 `https://example.com` 后发生什么？

### Q17.2 — 内部机制

> 按顺序说明 DNS、route selection、neighbour resolution、TCP、TLS、HTTP、proxy/load balancer 和 application handling。

### Q17.3 — 生产场景

> DNS 已解析成功，但页面一直打不开。还有哪些层可能有问题？

### Q17.4 — 故障排查

> 如何利用 packet capture、socket state、TLS 工具和 telemetry 缩小故障范围？

### Q17.5 — Senior Trade-off / Edge Case

> 为了让 timeout 容易诊断，你会在整条链路上如何布置 observability 和 timeout？

---

## Q18 — TCP 三次握手

### Q18.1 — 基础定义

> 解释 TCP three-way handshake。

### Q18.2 — 内部机制

> 为什么需要交换 sequence numbers？为什么不是 two-way handshake？

### Q18.3 — 生产场景

> 只有 connection establishment 间歇失败，但已建立连接都正常，这暗示什么？

### Q18.4 — 故障排查

> 如何区分 SYN drop、listen backlog exhaustion、firewall 问题和 server overload？

### Q18.5 — Senior Trade-off / Edge Case

> 面对真实连接突发与攻击/retry storm，分别应该如何调整？

---

## Q19 — TIME_WAIT

### Q19.1 — 基础定义

> `TIME_WAIT` 是什么，为什么存在？

### Q19.2 — 内部机制

> 为什么 active closer 常进入 `TIME_WAIT`？

### Q19.3 — 生产场景

> 大量 TIME_WAIT 导致 outbound connections 失败，可能发生了什么？

### Q19.4 — 故障排查

> 如何调查 ephemeral-port exhaustion、connection reuse、NAT limits 和 client behaviour？

### Q19.5 — Senior Trade-off / Edge Case

> 哪些 mitigation 是安全的？为什么激进 TIME_WAIT tuning 可能有风险？

---

## Q20 — DNS 成功但 TCP Timeout

### Q20.1 — 基础定义

> hostname 能解析，但连接 timeout。下一步检查什么？

### Q20.2 — 内部机制

> 解释 DNS 成功到应用连接成功之间还经过哪些层。

### Q20.3 — 生产场景

> 只有一个 subnet 出现 timeout，而其他 subnet 正常。这如何改变 hypotheses？

### Q20.4 — 故障排查

> 如何检查 route table、SG/NACL、NAT、proxy、target health 和 packet evidence？

### Q20.5 — Senior Trade-off / Edge Case

> 如何设计诊断数据，让团队快速区分 DNS、routing、transport、TLS 和 application failure？

---

## Q21 — 间歇性 DNS 故障

### Q21.1 — 基础定义

> 如何调查 intermittent DNS timeout？

### Q21.2 — 内部机制

> 解释 caching、recursive resolution、TTL、search domain、`ndots` 和 retry behaviour。

### Q21.3 — 生产场景

> 只有 2% 失败，而且集中在部分 nodes。哪些 hypotheses 更强？

### Q21.4 — 故障排查

> 如何测试 resolver health、CoreDNS/upstream、packet loss、conntrack pressure 和 `ndots` amplification？

### Q21.5 — Senior Trade-off / Edge Case

> 如何降低 DNS 成为系统性依赖，同时避免 stale discovery？

---

## Q22 — HTTP 502 / 503 / 504

### Q22.1 — 基础定义

> 从运维角度解释 HTTP 502、503、504 的区别。

### Q22.2 — 内部机制

> 在 reverse proxy / load balancer 架构中，通常是谁生成这些状态码？

### Q22.3 — 生产场景

> 用户大量看到 504，但 backend CPU 很低。你会调查什么？

### Q22.4 — 故障排查

> 如何结合 LB logs、upstream timing、retry、queue 和 dependency latency 找到来源？

### Q22.5 — Senior Trade-off / Edge Case

> timeout budget 和 error mapping 应如何设计，才能让状态码具有诊断价值？

---

## Q23 — Packet Loss

### Q23.1 — 基础定义

> 什么是 packet loss？它如何影响 TCP 应用？

### Q23.2 — 内部机制

> 解释 retransmission、congestion control、latency inflation 和 throughput collapse。

### Q23.3 — 生产场景

> 应用 latency 上升但 CPU/memory 正常，什么证据会让 packet loss 成为主要 hypothesis？

### Q23.4 — 故障排查

> 如何合理使用 `ping`、`mtr`、`ss`、TCP retransmit metrics、packet capture 和 interface counters？

### Q23.5 — Senior Trade-off / Edge Case

> 如果你不控制整条网络路径，如何区分 host、switch、overlay、WAN 和 cloud-provider loss？

---

## Q24 — TLS Handshake

### Q24.1 — 基础定义

> 从工程实践角度解释 TLS handshake。

### Q24.2 — 内部机制

> 说明 certificate validation、key agreement、session keys、SNI、ALPN 和 resumption。

### Q24.3 — 生产场景

> 共享 LB 后只有一个 hostname 间歇 TLS failure，可能是什么原因？

### Q24.4 — 故障排查

> 如何调查 certificate chain、SNI routing、clock skew、cipher/protocol mismatch 和 termination point？

### Q24.5 — Senior Trade-off / Edge Case

> 多层平台中 TLS 应在哪里 terminate？re-encryption / mTLS 有什么 trade-off？

---

# 04 — Kubernetes 基础与内部原理

## Q25 — Pod 创建生命周期

### Q25.1 — 基础定义

> 执行 `kubectl apply` 创建 Pod 后发生什么？

### Q25.2 — 内部机制

> 依次解释 API server、admission、etcd、scheduler、kubelet、CRI、container runtime、CNI 的作用。

### Q25.3 — 生产场景

> Pod object 已存在，但 container 完全没启动。可能卡在哪些阶段？

### Q25.4 — 故障排查

> 如何用 events、scheduler data、kubelet logs、runtime state 和 CNI evidence 找到失败阶段？

### Q25.5 — Senior Trade-off / Edge Case

> 生产集群中，你会优先让 lifecycle 的哪些阶段具备 HA 和 observability？为什么？

---

## Q26 — Deployment → ReplicaSet → Pod

### Q26.1 — 基础定义

> 解释 Deployment、ReplicaSet 与 Pod 的关系。

### Q26.2 — 内部机制

> 为什么 Deployment 不直接管理 Pod？

### Q26.3 — 生产场景

> rollout 创建了新 ReplicaSet，但一直无法完全 scale。哪些机制控制 progress？

### Q26.4 — 故障排查

> 如何调查 maxSurge/maxUnavailable、readiness、PDB、quota、scheduling 和 rollout status？

### Q26.5 — Senior Trade-off / Edge Case

> 关键 API 在 rollout speed、capacity overhead、availability 之间如何取舍？

---

## Q27 — Kubernetes Service 流量路径

### Q27.1 — 基础定义

> 什么是 Kubernetes Service？

### Q27.2 — 内部机制

> 解释 Service VIP、EndpointSlice、kube-proxy 或 eBPF datapath 与 Pod IP 的关系。

### Q27.3 — 生产场景

> Service DNS 正常解析，但 client 连不上。检查哪些层？

### Q27.4 — 故障排查

> same-node Service traffic 正常，cross-node 失败。如何缩小到 CNI、routing、conntrack、policy 或 node networking？

### Q27.5 — Senior Trade-off / Edge Case

> 如果集群完全使用 eBPF 且没有传统 kube-proxy，诊断思路如何变化？

---

## Q28 — Pods Ready 但用户收到 503

### Q28.1 — 基础定义

> 所有 Pods 都是 Ready，但用户收到 503。你从哪里开始？

### Q28.2 — 内部机制

> 为什么 readiness 不能保证 end-to-end availability？

### Q28.3 — 生产场景

> 只有一个 AZ 出现 503。哪些问题更可疑？

### Q28.4 — 故障排查

> 如何关联 ingress/LB targets、Service endpoints、app health、dependency health 和 zonal networking？

### Q28.5 — Senior Trade-off / Edge Case

> readiness 应如何设计，既反映 serving capability，又不过度依赖下游？

---

## Q29 — CrashLoopBackOff

### Q29.1 — 基础定义

> `CrashLoopBackOff` 是什么意思？

### Q29.2 — 内部机制

> 解释 restart policy、exponential backoff、container exit state，以及为什么 `--previous` logs 很重要。

### Q29.3 — 生产场景

> Pod 能正常启动约 20 秒后持续 crash。你会考虑哪些原因？

### Q29.4 — 故障排查

> 如何检查 events、exit code、OOMKilled、probes、config、secrets、dependencies 和应用 startup/shutdown？

### Q29.5 — Senior Trade-off / Edge Case

> 什么时候暂时放宽 liveness probe 是合理 mitigation？什么时候会掩盖真正故障？

---

## Q30 — Pending Pod

### Q30.1 — 基础定义

> Pod 长时间处于 Pending 说明什么？

### Q30.2 — 内部机制

> 解释 resource requests、affinity、taints/tolerations、PVC binding、quota、admission 等如何导致 Pending。

### Q30.3 — 生产场景

> 只有新 Pod Pending，而已有 workload 正常运行。优先怀疑什么？

### Q30.4 — 故障排查

> 如何使用 scheduler events、node allocatable、quota、storage state 和 affinity rules 找到 blocker？

### Q30.5 — Senior Trade-off / Edge Case

> 如何设计 capacity headroom 和 scheduling policy，避免单个 placement constraint 造成大面积 outage？

---

## Q31 — Kubernetes DNS

### Q31.1 — 基础定义

> Kubernetes 集群内 DNS 如何工作？

### Q31.2 — 内部机制

> 解释 CoreDNS、Service discovery、search domains、`ndots`、caching 和 upstream resolution。

### Q31.3 — 生产场景

> 只有部分 nodes 上的 Pods 间歇无法解析 Service。你会怎么判断？

### Q31.4 — 故障排查

> 如何测试 CoreDNS、node networking、conntrack、resolver config、packet loss 和 query amplification？

### Q31.5 — Senior Trade-off / Edge Case

> 如何提高大规模集群 DNS resilience，同时避免 stale data？

---

## Q32 — etcd 不可用

### Q32.1 — 基础定义

> etcd 在 Kubernetes 中负责什么？

### Q32.2 — 内部机制

> etcd unavailable 时，reads、writes、scheduling、controllers 和已有 workloads 分别会怎样？

### Q32.3 — 生产场景

> 应用仍在 serving，但无法创建新 Pods。如何确认 etcd 是 control-plane bottleneck？

### Q32.4 — 故障排查

> 如何调查 quorum、disk latency、network partition、certificate、resource pressure 和 member health？

### Q32.5 — Senior Trade-off / Edge Case

> 生产 etcd 应如何设计 backup、restore、quorum 和 failure domain？

---

# 05 — Kubernetes 生产故障排查

## Q33 — Deployment 后错误率上涨

### Q33.1 — 基础定义

> 部署 5 分钟后 error rate 从 0.1% 升到 8%。第一步做什么？

### Q33.2 — 内部机制

> 如何关联 rollout timeline、version、configuration、traffic 和 dependency changes？

### Q33.3 — 生产场景

> 只有新 ReplicaSet 错误率高，而旧 Pods 健康。立即 mitigation 是什么？

### Q33.4 — 故障排查

> 如果 rollback 后问题仍存在，如何判断 schema/cache/external dependency/irreversible side effects？

### Q33.5 — Senior Trade-off / Edge Case

> 如何制定 rollback criteria 和 release guardrails，让决策快速且不依赖个人直觉？

---

## Q34 — 单个 Pod 明显变慢

### Q34.1 — 基础定义

> 10 个 Pods 中只有一个 latency 是其他 Pod 的 3 倍。可能是什么原因？

### Q34.2 — 内部机制

> 解释 node locality、CPU throttling、GC、network path、disk、connection pool 和 cache warmth 对单实例的影响。

### Q34.3 — 生产场景

> 把这个 Pod reschedule 到另一 node 后恢复正常。这说明什么？

### Q34.4 — 故障排查

> 如何检查 node metrics、cgroup throttling、network counters、storage latency 和 noisy-neighbour evidence？

### Q34.5 — Senior Trade-off / Edge Case

> 如何自动检测并隔离 single-instance degradation？

---

## Q35 — HPA 不扩容

### Q35.1 — 基础定义

> CPU 很高但 HPA 没有 scale。先检查什么？

### Q35.2 — 内部机制

> 解释 HPA 如何获取 metrics、计算 desired replicas、使用 stabilization，并与 requests/limits 交互。

### Q35.3 — 生产场景

> `top` 显示 90% CPU，但 HPA 只看到 45% utilization。为什么？

### Q35.4 — 故障排查

> 如何检查 metrics-server/custom metrics、resource requests、HPA events、maxReplicas、cooldown 和 pending capacity？

### Q35.5 — Senior Trade-off / Edge Case

> 什么时候 CPU 是错误的 scaling signal？应该换成什么？

---

## Q36 — JVM Heap 正常但 Pod OOMKilled

### Q36.1 — 基础定义

> Java service 被 OOMKilled，但 JVM heap 看起来正常。为什么？

### Q36.2 — 内部机制

> 解释 container memory 中 heap 以外的 metaspace、direct buffer、thread stack、native library、mmap 和 page cache。

### Q36.3 — 生产场景

> kernel 报 cgroup OOM，但 heap dump 没 leak。下一步查什么？

### Q36.4 — 故障排查

> 如何关联 cgroup memory、Native Memory Tracking、`/proc`、thread count、direct buffer 和 limits？

### Q36.5 — Senior Trade-off / Edge Case

> 如何为 JVM/container 做 memory sizing 与 guardrails？

---

## Q37 — Node NotReady

### Q37.1 — 基础定义

> 什么是 `NodeNotReady`？

### Q37.2 — 内部机制

> 解释 kubelet heartbeat/lease、node conditions 与 controller eviction behaviour。

### Q37.3 — 生产场景

> peak traffic 时 node NotReady，但 SSH 仍能连。你会考虑什么？

### Q37.4 — 故障排查

> 如何在不立刻 reboot 的情况下调查 kubelet、runtime、disk/PID pressure、network 和 API reachability？

### Q37.5 — Senior Trade-off / Edge Case

> 怎样的 automated node remediation 才安全？

---

## Q38 — Cross-node Pod Traffic 故障

### Q38.1 — 基础定义

> same-node Pod traffic 正常，但 cross-node 间歇失败。这说明什么？

### Q38.2 — 内部机制

> 解释 CNI 下跨 node packet path 中 routing、encapsulation、NAT/policy 可能出错的位置。

### Q38.3 — 生产场景

> 故障集中在某两个 worker 之间。如何进一步缩小范围？

### Q38.4 — 故障排查

> 如何使用 route、CNI state、MTU、conntrack、packet capture、interface drops 和 NetworkPolicy 诊断？

### Q38.5 — Senior Trade-off / Edge Case

> 哪些 cluster-network architecture 与 observability 设计可以减少这类故障？

---

## Q39 — Rollout 卡在 8/10

### Q39.1 — 基础定义

> Deployment rollout 卡在 8/10 replicas。检查什么？

### Q39.2 — 内部机制

> 解释 readiness、scheduling、PDB、maxSurge/maxUnavailable、quota 如何影响 progress。

### Q39.3 — 生产场景

> 两个新 Pods Pending，而旧 Pods 因 PDB 不能终止，可能发生了什么？

### Q39.4 — 故障排查

> 如何证明 blocker 是 capacity、PDB、affinity、quota、image pull 还是 probe？

### Q39.5 — Senior Trade-off / Edge Case

> 如何设计 rollout policy，避免 cluster spare capacity 很少时 deadlock？

---

## Q40 — Control Plane 健康但 Workload 不健康

### Q40.1 — 基础定义

> Kubernetes control-plane metrics 正常，但 application availability 在下降。如何缩小 fault domain？

### Q40.2 — 内部机制

> 为什么 API server healthy 不代表 node、network、storage、ingress 或 application healthy？

### Q40.3 — 生产场景

> 只有一个 service 受影响，同 node 上其他 workload 健康。这说明什么？

### Q40.4 — 故障排查

> 如何从 external symptom 逐层走到 ingress、Service、Pod、node、dependency 和 application evidence？

### Q40.5 — Senior Trade-off / Edge Case

> 如何设计 layered SLO 与 synthetic checks，自动区分 platform health 和 workload health？

---

# 06 — AWS / 云

## Q41 — ALB 到应用 Timeout

### Q41.1 — 基础定义

> 请求到达 ALB，但似乎没有到 application。你检查什么？

### Q41.2 — 内部机制

> 解释 target group、health check、listener、security group、routing、subnet 和 backend connection flow。

### Q41.3 — 生产场景

> targets healthy，但请求仍间歇 timeout。还可能是什么？

### Q41.4 — 故障排查

> 如何关联 ALB access logs、target response time、SG/NACL、socket 和 dependency latency？

### Q41.5 — Senior Trade-off / Edge Case

> 如何设置 timeout、health check 和 connection management，减少模糊 ALB failure？

---

## Q42 — Security Group 与 NACL

### Q42.1 — 基础定义

> Security Group 和 NACL 的区别是什么？

### Q42.2 — 内部机制

> 哪个是 stateful？哪个是 stateless？规则如何评估？

### Q42.3 — 生产场景

> 相同 SG 下，一个 subnet 正常，一个 subnet 失败。可能为什么？

### Q42.4 — 故障排查

> 如何证明问题来自 NACL、route、SG、ephemeral port 还是其他层？

### Q42.5 — Senior Trade-off / Edge Case

> 怎样管理网络 policy 才能兼顾 least privilege 与降低 outage 风险？

---

## Q43 — Multi-AZ 设计

### Q43.1 — 基础定义

> Multi-AZ 到底保护你免受什么故障？

### Q43.2 — 内部机制

> 它不能保护哪些 failure classes？

### Q43.3 — 生产场景

> 应用部署在三个 AZ，但一个 AZ down 后仍 outage。可能是什么设计错误？

### Q43.4 — 故障排查

> 如何调查 remaining capacity、zonal load balancing、NAT、stateful dependency、quorum 和 cross-AZ traffic？

### Q43.5 — Senior Trade-off / Edge Case

> 哪些 capacity/dependency rules 能确保系统真正 survive AZ loss？

---

## Q44 — AWS API Throttling

### Q44.1 — 基础定义

> 什么是 AWS API throttling？

### Q44.2 — 内部机制

> 解释 rate/burst limit、exponential backoff、jitter 和 token-bucket 风格行为。

### Q44.3 — 生产场景

> autoscaling 后 automation fleet 突然大量 throttling。怎么办？

### Q44.4 — 故障排查

> 如何找出 offending API/client，并区分 account/region/service quota？

### Q44.5 — Senior Trade-off / Edge Case

> 什么时候应该申请 quota increase，什么时候应该 redesign？

---

## Q45 — S3 Consistency

### Q45.1 — 基础定义

> S3 提供什么 consistency guarantee？

### Q45.2 — 内部机制

> 为什么应用仍可能观察到“看似不一致”？

### Q45.3 — 生产场景

> producer 写完对象后 consumer 说对象不存在，除了 S3 consistency 还可能是什么？

### Q45.4 — 故障排查

> 如何检查 cache、versioning、IAM、replication、event timing 和 application race？

### Q45.5 — Senior Trade-off / Edge Case

> 如何设计 idempotent object workflow，避免 retry/duplicate event 造成 business inconsistency？

---

## Q46 — IAM AccessDenied

### Q46.1 — 基础定义

> IAM policy 看起来 allow，但请求仍 AccessDenied。哪些东西能覆盖 allow？

### Q46.2 — 内部机制

> 解释 identity policy、resource policy、SCP、permission boundary、session policy、explicit deny 和 KMS policy。

### Q46.3 — 生产场景

> 只有一个 assumed role 失败，而相似 role 正常。应该比较什么？

### Q46.4 — 故障排查

> 如何使用 CloudTrail、policy simulation、role session context 和 resource/KMS policy 定位？

### Q46.5 — Senior Trade-off / Edge Case

> 怎样设计 IAM 才既 least privilege 又容易诊断？

---

## Q47 — AWS Region Degradation 与 Failover

### Q47.1 — 基础定义

> AWS primary region 部分 degraded。什么时候应该 fail over？

### Q47.2 — 内部机制

> regional failover 前需要哪些 technical/business signals？

### Q47.3 — 生产场景

> 部分 dependency 正常、部分 degraded。如何判断 failover 会改善还是恶化？

### Q47.4 — 故障排查

> 如何验证 secondary region capacity、data currency、DNS/traffic controls 和 external dependencies？

### Q47.5 — Senior Trade-off / Edge Case

> 应该预先建立怎样的 RTO/RPO、game day 和 decision authority？

---

## Q48 — AWS Cost Anomaly

### Q48.1 — 基础定义

> AWS cost 一夜上涨 40%，但已知 traffic 没增长。先从哪查？

### Q48.2 — 内部机制

> 如何按 service、account、region、tag、usage type 和 time 拆成本？

### Q48.3 — 生产场景

> compute cost 增加但 request volume 平。技术上可能是什么？

### Q48.4 — 故障排查

> 如何关联 autoscaling、runaway jobs、data transfer、NAT、logs 和 storage growth？

### Q48.5 — Senior Trade-off / Edge Case

> 如何设计 FinOps guardrails，同时不阻塞合法 scaling？

---

# 07 — Terraform / Infrastructure as Code

## Q49 — Terraform State

### Q49.1 — 基础定义

> Terraform 为什么需要 state？

### Q49.2 — 内部机制

> 解释 resource address、remote object、dependency 和 state mapping。

### Q49.3 — 生产场景

> 两个 teams 用不同 state 管理同一套 infrastructure，会发生什么？

### Q49.4 — 故障排查

> 如何安全检测 ownership conflict 并 consolidate/import？

### Q49.5 — Senior Trade-off / Edge Case

> 大型组织如何划分 state boundary，平衡 blast radius、dependency 和 team autonomy？

---

## Q50 — Terraform State 丢失

### Q50.1 — 基础定义

> Terraform state 丢失会怎样？

### Q50.2 — 内部机制

> 为什么只重新运行相同 configuration 并不能安全恢复？

### Q50.3 — 生产场景

> state 被删但 infrastructure 还在。第一步做什么？

### Q50.4 — 故障排查

> 如何从 remote-state version/backup 恢复，或通过 import 重建？

### Q50.5 — Senior Trade-off / Edge Case

> 哪些 controls 能让永久 state loss 极难发生？

---

## Q51 — Infrastructure Drift

### Q51.1 — 基础定义

> 什么是 Terraform drift？

### Q51.2 — 内部机制

> plan/refresh 如何发现 drift？哪些 drift 可能是 intentional？

### Q51.3 — 生产场景

> 工程师在 outage 中通过 Console 紧急修改资源，事后应怎么办？

### Q51.4 — 故障排查

> 如何决定 revert、codify、import 还是 redesign？

### Q51.5 — Senior Trade-off / Edge Case

> 怎样允许 break-glass changes，同时不让 unmanaged infra 常态化？

---

## Q52 — `terraform plan` 内部过程

### Q52.1 — 基础定义

> `terraform plan` 到底做什么？

### Q52.2 — 内部机制

> 解释 config evaluation、provider reads、state refresh、dependency graph、diff 和 unknown values。

### Q52.3 — 生产场景

> plan 显示 critical resource 将被 replace。怎么办？

### Q52.4 — 故障排查

> 如何检查 provider schema、lifecycle、changed attributes、state 和 dependencies？

### Q52.5 — Senior Trade-off / Edge Case

> production CI 应如何 gate destroy/replace plan？

---

## Q53 — Terraform State Locking

### Q53.1 — 基础定义

> 为什么 Terraform state 需要 locking？

### Q53.2 — 内部机制

> 如果两个 applies 同时修改同一个 state，会发生什么？

### Q53.3 — 生产场景

> 两个 pipelines 卡在 lock 上，其中一个 lock 看起来 stale。怎么办？

### Q53.4 — 故障排查

> force-unlock 前如何确认 apply 已不在运行？

### Q53.5 — Senior Trade-off / Edge Case

> 怎样设计 CI/state ownership，让 force-unlock 几乎不需要？

---

## Q54 — Terraform 中的 Secrets

### Q54.1 — 基础定义

> `sensitive = true` 能让 Terraform secret 安全吗？

### Q54.2 — 内部机制

> secret 还可能出现在哪里？

### Q54.3 — 生产场景

> secret 曾经写进 state 后已经 rotation，仍有哪些 exposure？

### Q54.4 — 故障排查

> 如何保护 remote state、CI logs、plans 和历史版本？

### Q54.5 — Senior Trade-off / Edge Case

> 什么时候 Terraform 应只引用 secret manager，而不是直接管理 secret value？

---

## Q55 — Terraform Apply 中途失败

### Q55.1 — 基础定义

> Terraform 创建 15 个资源后在第 16 个失败，state 会怎样？

### Q55.2 — 内部机制

> 后续 plan 如何处理 partial progress？

### Q55.3 — 生产场景

> 外部 API side effect 已发生，但 provider 尚未成功写 state，为什么麻烦？

### Q55.4 — 故障排查

> 如何检查 real infra 与 state 并安全恢复？

### Q55.5 — Senior Trade-off / Edge Case

> module/provider 如何设计得更适合 partial failure recovery？

---

## Q56 — 大规模 Terraform 管理

### Q56.1 — 基础定义

> 几百个 production resources、多个 teams 时如何管理 Terraform？

### Q56.2 — 内部机制

> 解释 module boundaries、remote state、CI/CD、policy-as-code、provider pinning 和 ownership。

### Q56.3 — 生产场景

> 一个 shared module change 可能影响几十个 stacks。如何降低 blast radius？

### Q56.4 — 故障排查

> 如何设计 validation、canary apply、policy check、drift detection 和 recovery？

### Q56.5 — Senior Trade-off / Edge Case

> 成熟 platform organization 中哪些应该 centralized，哪些 delegated？

---

# 08 — 可观测性

## Q57 — Metrics、Logs 与 Traces

### Q57.1 — 基础定义

> 什么时候分别使用 metrics、logs 和 traces？

### Q57.2 — 内部机制

> 解释三种 telemetry 在信息模型、成本和用途上的差异。

### Q57.3 — 生产场景

> 服务 latency 很高但没有明显 errors。你先看哪个 signal，为什么？

### Q57.4 — 故障排查

> 如何把 RED metrics、traces、structured logs 和 infra metrics 串起来定位？

### Q57.5 — Senior Trade-off / Edge Case

> 哪些 telemetry 你会故意不采集，为什么？

---

## Q58 — RED 与 USE

### Q58.1 — 基础定义

> 解释 RED 和 USE 方法。

### Q58.2 — 内部机制

> 哪些系统更适合 RED，哪些更适合 USE？

### Q58.3 — 生产场景

> API 很慢但 CPU 很低。RED 与 USE 会如何指导你？

### Q58.4 — 故障排查

> 如何把 RED/USE 映射到 app、node、network、storage 和 pools？

### Q58.5 — Senior Trade-off / Edge Case

> 如何避免 RED/USE 变成机械 dashboard checklist？

---

## Q59 — P99 上升但 P50 稳定

### Q59.1 — 基础定义

> P99 latency 翻倍但 P50 不变，说明什么？

### Q59.2 — 内部机制

> 为什么 tail latency 可以显著变化而 median 不变？

### Q59.3 — 生产场景

> 只有少量 requests 变慢，应该按哪些 dimensions 分组？

### Q59.4 — 故障排查

> 如何用 traces、endpoint/version/AZ/node、queue 和 dependency timing 找到 tail source？

### Q59.5 — Senior Trade-off / Edge Case

> 怎样做 tail latency alert，既能捕获问题又不被低样本噪声干扰？

---

## Q60 — Average Latency 正常但用户很慢

### Q60.1 — 基础定义

> 为什么 average latency 正常，但用户仍可能觉得系统很慢？

### Q60.2 — 内部机制

> 解释 skew、outlier、percentile、aggregation window 和 request weighting。

### Q60.3 — 生产场景

> 一个 customer cohort latency 3 秒，而 global average 150ms。怎么暴露这个问题？

### Q60.4 — 故障排查

> 如何既按 tenant/region/endpoint/version 切片，又控制 cardinality？

### Q60.5 — Senior Trade-off / Edge Case

> 如何同时给 leadership 简单 KPI 和 operations 足够细节？

---

## Q61 — High-cardinality Metrics

### Q61.1 — 基础定义

> 什么是 metric cardinality？

### Q61.2 — 内部机制

> 为什么 user ID、request ID 等 labels 很危险？

### Q61.3 — 生产场景

> 团队给所有 Prometheus metrics 加了 `customer_id` 后 monitoring 崩了。发生了什么？

### Q61.4 — 故障排查

> 如何快速识别和缓解 cardinality explosion，同时保留诊断价值？

### Q61.5 — Senior Trade-off / Edge Case

> 你会制定哪些 label、exemplar、aggregation 和 retention 规则？

---

## Q62 — 故障时没有有用 Logs

### Q62.1 — 基础定义

> production 正在失败，但 application logs 看不出异常。下一步怎么办？

### Q62.2 — 内部机制

> 为什么“没有 logs”不等于“没有 failure”？

### Q62.3 — 生产场景

> proxy 在请求到达 app 前就生成 5xx，这会如何改变诊断？

### Q62.4 — 故障排查

> 如何利用 traces、LB/proxy logs、kernel/network telemetry、dependency metrics 和 synthetic tests？

### Q62.5 — Senior Trade-off / Edge Case

> 应该建立怎样的 logging contract？

---

## Q63 — Distributed Tracing

### Q63.1 — 基础定义

> distributed tracing 如何帮助诊断 microservices？

### Q63.2 — 内部机制

> 解释 trace ID、span、parent/child、context propagation、sampling 和 baggage。

### Q63.3 — 生产场景

> 一个 request 经过 8 个 services，共耗时 4 秒。如何找主要 contributor？

### Q63.4 — 故障排查

> 如何区分 service time、queue time、retry、network delay 和 missing spans？

### Q63.5 — Senior Trade-off / Edge Case

> 怎样的 sampling strategy 能控制成本又保留 incident value？

---

## Q64 — Alert 设计

### Q64.1 — 基础定义

> CPU 95% 持续 10 分钟，应该 page SRE 吗？

### Q64.2 — 内部机制

> symptom alert 与 cause/resource alert 有什么区别？

### Q64.3 — 生产场景

> CPU 95%，但 latency/error 正常。应该做什么？

### Q64.4 — 故障排查

> 如何结合 SLO burn、saturation、queue depth 和 user impact 决定 paging 或 ticket？

### Q64.5 — Senior Trade-off / Edge Case

> 一个高质量 on-call alert 应具备什么特征？

---

# 09 — SLI / SLO / Reliability

## Q65 — SLI

### Q65.1 — 基础定义

> 什么是 SLI？

### Q65.2 — 内部机制

> 为什么 SLI 应接近 user-visible behaviour，而不是内部 component health？

### Q65.3 — 生产场景

> payment API 可以选择哪些 SLI？哪些不合适？

### Q65.4 — 故障排查

> 如何验证 SLI query 正确处理 retries、partial failures、client errors 和 missing telemetry？

### Q65.5 — Senior Trade-off / Edge Case

> 什么样的 SLI 才适合长期治理？

---

## Q66 — SLO 与 SLA

### Q66.1 — 基础定义

> SLO 和 SLA 的区别是什么？

### Q66.2 — 内部机制

> 解释 internal reliability target、contractual commitment 和 error budget。

### Q66.3 — 生产场景

> service SLO 99.9%，SLA 99.5%，为什么合理？

### Q66.4 — 故障排查

> 内部 telemetry 显示 SLO 达标，但 customers 声称 SLA impact。怎么办？

### Q66.5 — Senior Trade-off / Edge Case

> SLO 除了报一个百分比，还应该推动哪些组织行为？

---

## Q67 — 为什么选择 99.9% 而非 99.99%

### Q67.1 — 基础定义

> 为什么团队可能选择 99.9% 而不是 99.99%？

### Q67.2 — 内部机制

> 把这两个 target 转换成 engineering cost 和 allowable failure。

### Q67.3 — 生产场景

> 一个低价值 internal service 要求 four nines，因为“可靠性很重要”。你如何挑战？

### Q67.4 — 故障排查

> 如何判断 architecture、staffing、dependencies 和 operational maturity 能否支撑目标？

### Q67.5 — Senior Trade-off / Edge Case

> 什么 business evidence 才值得提高 SLO？什么时候应刻意保持较低目标？

---

## Q68 — Error Budget

### Q68.1 — 基础定义

> 什么是 error budget？

### Q68.2 — 内部机制

> 它如何连接 SLO、unreliability 和 delivery velocity？

### Q68.3 — 生产场景

> 一个月预算前两天就烧掉 80%，怎么办？

### Q68.4 — 故障排查

> 如何区分 one-off incident 与结构性 reliability problem，并决定 release policy？

### Q68.5 — Senior Trade-off / Edge Case

> 怎样的 error-budget policy 不会变成僵硬的 release freeze？

---

## Q69 — Payment API Availability SLI

### Q69.1 — 基础定义

> 如何为 payment API 定义 availability？

### Q69.2 — 内部机制

> numerator/denominator 应如何选择？

### Q69.3 — 生产场景

> client timeout，但 server 后来成功完成 payment，这算 available 吗？

### Q69.4 — 故障排查

> 如何处理 idempotency、async processing、retry、partial success 和 duplicate submission？

### Q69.5 — Senior Trade-off / Edge Case

> transactional system 最终应该用什么 user outcome 定义 availability？

---

## Q70 — Dependency SLO 不匹配

### Q70.1 — 基础定义

> 你的服务 SLO 99.95%，但必须依赖一个 99.9% 服务。有什么问题？

### Q70.2 — 内部机制

> dependency reliability 如何组合？

### Q70.3 — 生产场景

> dependency 无法替换，有哪些 architectural options？

### Q70.4 — 故障排查

> 如何测试 cache、graceful degradation、retry、hedging、async decoupling 是否真的保护 SLO？

### Q70.5 — Senior Trade-off / Edge Case

> 什么时候应下调自己的 SLO，而不是用复杂度掩盖弱 dependency？

---

## Q71 — SLO Violation Alerting

### Q71.1 — 基础定义

> 为什么不能每次 SLO violation 都 page？

### Q71.2 — 内部机制

> 解释 short-window noise、long-window significance 和 burn rate。

### Q71.3 — 生产场景

> 服务 5 分钟短暂超过 error target，但月度 budget 很充足。需要 page 吗？

### Q71.4 — 故障排查

> 如何设计 multi-window burn-rate alerts？

### Q71.5 — Senior Trade-off / Edge Case

> 还应该补充哪些 secondary signals？

---

## Q72 — Burn-rate Alerting

### Q72.1 — 基础定义

> 什么是 SLO burn rate？

### Q72.2 — 内部机制

> `1x`、`10x`、`100x` 分别意味着什么？

### Q72.3 — 生产场景

> 如何理解快速 50x burn 与持续 2x burn？

### Q72.4 — 故障排查

> 设计一种能同时发现 catastrophic 和 slow burn 的 multi-window 策略。

### Q72.5 — Senior Trade-off / Edge Case

> 在数学精度、运维简洁和 on-call 可解释性之间如何取舍？

---

# 10 — 编程 / 并发

## Q73 — Deadlock

### Q73.1 — 基础定义

> 什么是 deadlock？画一个简单例子。

### Q73.2 — 内部机制

> 解释 resource dependency cycle 为什么让 threads 永久 blocked。

### Q73.3 — 生产场景

> Java service CPU 很低但完全没 progress。什么 evidence 会让 deadlock 成为主要 hypothesis？

### Q73.4 — 故障排查

> 如何用 thread dumps、lock ownership、JVM tools 和 telemetry 确认？

### Q73.5 — Senior Trade-off / Edge Case

> 哪些设计 pattern 可以防止 deadlock？有什么 trade-off？

---

## Q74 — Deadlock 四个条件

### Q74.1 — 基础定义

> deadlock 需要哪四个条件？

### Q74.2 — 内部机制

> 解释 mutual exclusion、hold-and-wait、no preemption、circular wait。

### Q74.3 — 生产场景

> 应用代码中最现实地打破哪个条件？

### Q74.4 — 故障排查

> 如何在事故前发现 locking design 可能形成 cycle？

### Q74.5 — Senior Trade-off / Edge Case

> 大型 codebase 中如何记录和 enforce concurrency invariants？

---

## Q75 — Race Condition 与 Deadlock

### Q75.1 — 基础定义

> race condition 和 deadlock 有什么区别？

### Q75.2 — 内部机制

> timing 在 race 中如何影响 correctness，而 deadlock 如何影响 progress？

### Q75.3 — 生产场景

> counter 偶尔丢 update，但服务从不卡死。更像什么问题？

### Q75.4 — 故障排查

> 如何复现和证明每百万请求才出现一次的 race？

### Q75.5 — Senior Trade-off / Edge Case

> 什么时候选择 atomics、locks、immutability、actor model 或 database constraints？

---

## Q76 — Thread Safety

### Q76.1 — 基础定义

> 什么让代码成为 thread-safe？

### Q76.2 — 内部机制

> 解释 atomicity、visibility、immutability 和 shared mutable state。

### Q76.3 — 生产场景

> singleton cache 在测试正常，但生产并发下数据损坏。检查什么？

### Q76.4 — 故障排查

> 如何通过 stress tests、thread analyzers 和 memory-model reasoning 找 bug？

### Q76.5 — Senior Trade-off / Edge Case

> 哪些设计选择能减少显式 locking？

---

## Q77 — Database Concurrency / Lost Update

### Q77.1 — 基础定义

> 两个 writers 如何导致 lost update？

### Q77.2 — 内部机制

> 解释 optimistic lock、pessimistic lock、MVCC、compare-and-set 和 version column。

### Q77.3 — 生产场景

> 两个 service instances 同时更新一个 order。如何保证 correctness？

### Q77.4 — 故障排查

> 如何复现 race、选择控制机制并验证 fix？

### Q77.5 — Senior Trade-off / Edge Case

> 什么时候 application-level lock 不如 database invariant？

---

## Q78 — Distributed Lock

### Q78.1 — 基础定义

> 什么时候需要 distributed lock？

### Q78.2 — 内部机制

> 解释 lease expiry、fencing token、partition、clock 和 stale holder 风险。

### Q78.3 — 生产场景

> lock holder pause 超过 lease，恢复后继续写旧数据。发生了什么？

### Q78.4 — 故障排查

> 如何让 expired holder 无法破坏数据？

### Q78.5 — Senior Trade-off / Edge Case

> 什么时候应该 redesign 以完全避免 distributed lock？

---

## Q79 — Idempotency

### Q79.1 — 基础定义

> 什么是 idempotency？为什么 distributed systems 需要它？

### Q79.2 — 内部机制

> 解释 idempotency key、dedup state、replay semantics 和 response persistence。

### Q79.3 — 生产场景

> 设计一个可能因 timeout 被 retry 的 idempotent payment API。

### Q79.4 — 故障排查

> 如何处理 concurrent duplicates、partial downstream success 和 key expiry？

### Q79.5 — Senior Trade-off / Edge Case

> 跨多个独立系统时，现实中能提供什么级别的 guarantee？

---

## Q80 — Retry Storm

### Q80.1 — 基础定义

> dependency 变慢，所有 clients 都 retry 3 次，会发生什么？

### Q80.2 — 内部机制

> 解释 retry amplification、queue growth、timeout、pool exhaustion 和 cascading failure。

### Q80.3 — 生产场景

> 下游从 50ms 变成 2s，上游 QPS 因 retries 变成三倍。立即怎么做？

### Q80.4 — 故障排查

> 如何配置 timeout、backoff、jitter、retry budget、circuit breaker 和 load shedding？

### Q80.5 — Senior Trade-off / Edge Case

> 多层架构中 retry 应放在哪里，避免层层相乘？

---

# 11 — 软件工程基础

## Q81 — SOLID

### Q81.1 — 基础定义

> 你最认可哪个 SOLID principle？为什么？

### Q81.2 — 内部机制

> 不要背定义，解释它如何影响 dependency structure。

### Q81.3 — 生产场景

> 举一个违反该原则导致 production change/testing 困难的真实例子。

### Q81.4 — 故障排查

> 如何在不引入大规模 rewrite 的情况下安全 refactor？

### Q81.5 — Senior Trade-off / Edge Case

> 什么时候严格套用 SOLID 反而会让系统更糟？

---

## Q82 — Maintainable Code

### Q82.1 — 基础定义

> 什么是 maintainable code？

### Q82.2 — 内部机制

> 从 cohesion、coupling、naming、tests、boundaries、observability 和 simplicity 解释。

### Q82.3 — 生产场景

> 接手一个稳定但极难修改的服务，如何判断 maintainability 是否真的伤害业务？

### Q82.4 — 故障排查

> 如何 incremental refactor 而不变成 risky rewrite？

### Q82.5 — Senior Trade-off / Edge Case

> 如何平衡 maintainability、performance、delivery speed 和团队 skill level？

---

## Q83 — Test-first 与 Test-second

### Q83.1 — 基础定义

> test-first 和 test-second 各有什么优缺点？

### Q83.2 — 内部机制

> 它们如何影响 design feedback、coverage、coupling 和 developer flow？

### Q83.3 — 生产场景

> 生产 incident fix 时你会选哪种？为什么？

### Q83.4 — 故障排查

> legacy code 很难 isolate，如何加入 regression test？

### Q83.5 — Senior Trade-off / Edge Case

> 什么时候坚持严格 TDD 会变得 counterproductive？

---

## Q84 — Unit Test 与 Integration Test

### Q84.1 — 基础定义

> 哪些内容适合 unit test，哪些适合 integration test？

### Q84.2 — 内部机制

> 解释 confidence、speed、dependency realism 和 failure localization 的 trade-off。

### Q84.3 — 生产场景

> 几千 unit tests 全绿，但 production 总因 config/dependency 出问题。缺什么？

### Q84.4 — 故障排查

> 如何重构 test pyramid/test portfolio 来捕获真实故障？

### Q84.5 — Senior Trade-off / Edge Case

> 每 commit、pre-merge、pre-deploy、post-deploy 分别跑什么？

---

## Q85 — Mocking

### Q85.1 — 基础定义

> 什么时候 mocking 有用？

### Q85.2 — 内部机制

> mock、stub、fake 有什么区别？

### Q85.3 — 生产场景

> test suite 有大量脆弱 mocks，全部通过，但 production contract 已经 drift。问题在哪里？

### Q85.4 — 故障排查

> 如何用 contract test、fake 或真实 integration 替换高风险 mocks，同时避免 CI 过慢？

### Q85.5 — Senior Trade-off / Edge Case

> 哪些 boundary 适合 mock，哪些更应该 against real implementation 测试？

---

## Q86 — API Versioning

### Q86.1 — 基础定义

> 如何修改被广泛使用的 API 而不破坏现有 consumers？

### Q86.2 — 内部机制

> 解释 additive change、deprecation、versioning、compatibility 和 schema evolution。

### Q86.3 — 生产场景

> 一个 field semantics 必须改变，但数千 clients 无法快速升级。怎么做？

### Q86.4 — 故障排查

> 如何测量 usage、roll out compatibility logic、检测 breakage 并 retire old contract？

### Q86.5 — Senior Trade-off / Edge Case

> 什么时候值得开一个新 API version，而不是继续 backward-compatible evolution？

---

## Q87 — REST → GraphQL Migration

### Q87.1 — 基础定义

> 如何从 REST 迁移到 GraphQL？

### Q87.2 — 内部机制

> 解释 schema、resolver、authorization、DataLoader/N+1、caching 和 query complexity。

### Q87.3 — 生产场景

> 已有 REST clients 无法同时迁移，如何安全双栈？

### Q87.4 — 故障排查

> 如何观察 resolver latency、query shape、backend load 和 regression？

### Q87.5 — Senior Trade-off / Edge Case

> 什么时候 GraphQL 其实不是好选择？

---

## Q88 — Technical Debt

### Q88.1 — 基础定义

> 如何判断 technical debt 值不值得修？

### Q88.2 — 内部机制

> 解释 debt principal、interest、risk 和 opportunity cost。

### Q88.3 — 生产场景

> 团队想花 3 个月重写，因为当前 service “很乱”。如何评估？

### Q88.4 — 故障排查

> 如何利用 incident、change-failure、delivery 和 maintenance data 排优先级？

### Q88.5 — Senior Trade-off / Edge Case

> 什么时候主动保留 technical debt 是正确决定？

---

# 12 — 数据库 / 分布式系统

## Q89 — Database Suddenly Slow

### Q89.1 — 基础定义

> database-backed requests 突然变慢。你先查什么？

### Q89.2 — 内部机制

> 解释 query plan、locks、I/O、cache、connection pool、statistics 和 workload change。

### Q89.3 — 生产场景

> DB CPU 很低但 latency 很高。哪些 hypotheses 更强？

### Q89.4 — 故障排查

> 如何检查 waits、locks、disk latency、network、connection queue 和 recent schema/data changes？

### Q89.5 — Senior Trade-off / Edge Case

> 事故中哪些 mitigation 较安全？哪些优化应该放到事后测试？

---

## Q90 — Database Index

### Q90.1 — 基础定义

> database index 到底做什么？

### Q90.2 — 内部机制

> 解释 B-tree lookup、selectivity、ordering、write amplification 和 optimizer。

### Q90.3 — 生产场景

> 为什么加 index 可能让 workload 更差？

### Q90.4 — 故障排查

> 如何判断 slow query 是需要 index、改 query、更新 statistics 还是 schema change？

### Q90.5 — Senior Trade-off / Edge Case

> 如何在 read performance 与 write cost 之间设计 indexing strategy？

---

## Q91 — Database Connection Pool Exhaustion

### Q91.1 — 基础定义

> 为什么 DB CPU 很低，但应用会 timeout 等待 connections？

### Q91.2 — 内部机制

> 解释 pool sizing、connection leak、long transaction、queueing 和 DB max connections。

### Q91.3 — 生产场景

> 所有 connections 都 busy，但 SQL 执行很快。这说明什么？

### Q91.4 — 故障排查

> 如何调查 pool wait、transaction duration、leak、thread dump 和 DB session state？

### Q91.5 — Senior Trade-off / Edge Case

> 多个 replicas 下如何正确设计 pool size？

---

## Q92 — Transaction Isolation

### Q92.1 — 基础定义

> transaction isolation levels 是什么？

### Q92.2 — 内部机制

> 解释 dirty read、non-repeatable read、phantom、snapshot/MVCC 与 serialization anomalies。

### Q92.3 — 生产场景

> 金融流程并发时偶尔 double-process，isolation 可能如何导致？

### Q92.4 — 故障排查

> 如何复现并选择 stronger isolation、explicit lock、constraint 或 idempotency？

### Q92.5 — Senior Trade-off / Edge Case

> 什么时候 serializable 值得付出 throughput/contention 成本？

---

## Q93 — Redis / Cache Failure

### Q93.1 — 基础定义

> Redis 不可用时，整个 application 应该不可用吗？

### Q93.2 — 内部机制

> 解释 cache-aside、TTL、fallback、cache miss 和 stampede。

### Q93.3 — 生产场景

> cache outage 后所有流量打到 DB，DB 也挂了。发生了什么？

### Q93.4 — 故障排查

> 如何使用 stale reads、request coalescing、rate limit、circuit breaker 和 staged recovery？

### Q93.5 — Senior Trade-off / Edge Case

> 什么时候一个“只是 cache”的 Redis 实际上已经是 critical dependency？

---

## Q94 — Duplicate Messages

### Q94.1 — 基础定义

> consumer 收到同一 message 两次怎么办？

### Q94.2 — 内部机制

> 解释 at-least-once、ack、deduplication、idempotent consumer 和 transactional outbox/inbox。

### Q94.3 — 生产场景

> 两个 duplicate messages 同时被不同 replicas 处理，需要什么保护？

### Q94.4 — 故障排查

> 如何处理 crash 发生在 side effect 与 ack 之间？

### Q94.5 — Senior Trade-off / Edge Case

> dedup key 的 retention window 和 key design 如何选择？

---

## Q95 — Exactly-once Processing

### Q95.1 — 基础定义

> distributed messaging 真能保证 exactly-once processing 吗？

### Q95.2 — 内部机制

> 区分 exactly-once delivery、processing semantics 和 business effect。

### Q95.3 — 生产场景

> broker 声称 exactly-once，但 consumer 还写 external DB。duplicate 在哪里出现？

### Q95.4 — 故障排查

> 如何跨 broker 与 DB failure boundary 设计 replay-safe workflow？

### Q95.5 — Senior Trade-off / Edge Case

> 什么时候 at-least-once + idempotency 反而更简单可靠？

---

## Q96 — Cascading Failure

### Q96.1 — 基础定义

> Service D 变慢为什么最终可能把 Service A 也拖垮？

### Q96.2 — 内部机制

> 解释 timeout stacking、pool exhaustion、retry amplification、queue growth 和 backpressure。

### Q96.3 — 生产场景

> D 从 100ms 变成 3s 但没有完全 down，为什么反而危险？

### Q96.4 — 故障排查

> 如何用 timeout、bulkhead、circuit breaker、load shedding 和 bounded queue 控制 blast radius？

### Q96.5 — Senior Trade-off / Edge Case

> 多级 call chain 的 timeout budget 应如何分配？

---

# 13 — Incident Management

## Q97 — Production Outage 的第一步

### Q97.1 — 基础定义

> production down 了，你第一件事做什么？

### Q97.2 — 内部机制

> 解释 impact assessment、severity、ownership、stabilization、communication 和 evidence preservation。

### Q97.3 — 生产场景

> 多个 dashboards 都红，但 customer impact 不清楚。优先做什么？

### Q97.4 — 故障排查

> 如何建立 scope、incident commander、timeline，并停止 uncoordinated changes？

### Q97.5 — Senior Trade-off / Edge Case

> 怎样的 incident process 才既有结构又不会拖慢 responders？

---

## Q98 — Rollback 还是先 Debug

### Q98.1 — 基础定义

> release 后 error rate 立刻上升。先 rollback 还是先调查？

### Q98.2 — 内部机制

> 决策要考虑哪些因素？

### Q98.3 — 生产场景

> release 包含 backward-incompatible DB migration，会如何影响？

### Q98.4 — 故障排查

> 如何在准备 rollback 的同时保留 evidence 和做 parallel diagnosis？

### Q98.5 — Senior Trade-off / Edge Case

> deployment design 如何让 rollback 真正可靠？

---

## Q99 — 未知 Root Cause 的 Incident

### Q99.1 — 基础定义

> 不知道 outage 原因时，你的 troubleshooting method 是什么？

### Q99.2 — 内部机制

> 解释 symptom、scope、timeline、recent changes、fault-domain narrowing、hypothesis 和 evidence。

### Q99.3 — 生产场景

> 前三个 hypotheses 都被证伪后，如何避免 random-walk debugging？

### Q99.4 — 故障排查

> 如何使用 binary reduction、comparative analysis、controlled experiment 和 known-good baseline？

### Q99.5 — Senior Trade-off / Edge Case

> 优秀 incident reasoning 与“会很多命令”最大的区别是什么？

---

## Q100 — 多个相关 Symptoms

### Q100.1 — 基础定义

> CPU high、DB latency high、5xx 上升、queue depth 增长。哪个是 root cause？

### Q100.2 — 内部机制

> 为什么 correlation 不能直接证明 causality？

### Q100.3 — 生产场景

> timeline 显示先 queue growth，再 DB latency，再 CPU。你会形成什么 hypothesis？

### Q100.4 — 故障排查

> 如何用 timestamps、telemetry 和 controlled mitigation 验证 causal chain？

### Q100.5 — Senior Trade-off / Edge Case

> 如何在不确定时向 stakeholders 表达，而不是显得没判断力？

---

## Q101 — 先 Mitigation 再永久修复

### Q101.1 — 基础定义

> 已知 likely root cause，但 permanent fix 需要两小时。怎么办？

### Q101.2 — 内部机制

> 为什么 incident mitigation 与 root-cause fix 是两个目标？

### Q101.3 — 生产场景

> 可以减流、disable feature 或加 capacity。如何选择？

### Q101.4 — 故障排查

> 执行 mitigation 前如何评估 risk、reversibility 和 secondary effects？

### Q101.5 — Senior Trade-off / Edge Case

> 什么条件说明可以从 incident response 转向 recovery/postmortem？

---

## Q102 — Rollback 后仍然故障

### Q102.1 — 基础定义

> release 导致 outage，但 rollback 后问题仍存在。下一步？

### Q102.2 — 内部机制

> 哪些 irreversible side effects 会让旧版本也继续失败？

### Q102.3 — 生产场景

> old version 现在和 new version 一样失败，这如何更新 hypothesis？

### Q102.4 — 故障排查

> 如何比较 before/after state、migration、cache、queue、config 和 dependency？

### Q102.5 — Senior Trade-off / Edge Case

> release controls 如何减少不可逆 changes？

---

## Q103 — Partial Outage

### Q103.1 — 基础定义

> 只有 5% users 受影响。怎么调查？

### Q103.2 — 内部机制

> 为什么 tenant、AZ、node、version、ISP、shard、endpoint 等 segmentation 很重要？

### Q103.3 — 生产场景

> 故障集中在一个 customer shard，但 global infra metrics 健康。查什么？

### Q103.4 — 故障排查

> 如何找到 affected users 的最小共同维度？

### Q103.5 — Senior Trade-off / Edge Case

> 怎样设计 telemetry，既支持 partial failure 调试又不爆 cardinality？

---

## Q104 — Incident Commander

### Q104.1 — 基础定义

> Incident Commander 到底应该做什么？

### Q104.2 — 内部机制

> 解释 coordination、decision ownership、communication 和 role separation。

### Q104.3 — 生产场景

> IC 是现场技术最强的人，是否应该亲自做最深 debugging？

### Q104.4 — 故障排查

> 如何分配 operations、investigation、communications、scribe 和 SMEs？

### Q104.5 — Senior Trade-off / Edge Case

> 怎样避免 IC 变成压制专业意见的 command-and-control？

---

# 14 — Hands-on / Day in the Office

## Q105 — Broken Kubernetes Service — 12% HTTP 504

### Q105.1 — 基础定义

> ALB → Ingress → Service → Pods → PostgreSQL 链路中，12% requests 返回 504。你从哪里开始？

### Q105.2 — 内部机制

> 如何画出每一 hop 的 timeout budget 与 observable boundary？

### Q105.3 — 生产场景

> 故障只集中在两个 Pods。你会和健康 Pods 比什么？

### Q105.4 — 故障排查

> 如何使用 metrics、logs、traces、Endpoint state、node/network 和 DB sessions 找到 bottleneck？

### Q105.5 — Senior Trade-off / Edge Case

> mitigation 后应加入哪些 design、alert 和 test，避免同类 partial timeout 再出现？

---

## Q106 — Release Regression Timeline

### Q106.1 — 基础定义

> 13:04 deploy，13:08 errors 上升，13:10 CPU 上升，13:12 queue depth 上升。你如何解释？

### Q106.2 — 内部机制

> 如何构建 causal chain，而不是把四个 metrics 当独立问题？

### Q106.3 — 生产场景

> 只有 new version 的 request duration 先变高。leading hypothesis 是什么？

### Q106.4 — 故障排查

> 如何验证是慢代码导致 queue/CPU amplification，还是 external dependency 先变慢？

### Q106.5 — Senior Trade-off / Edge Case

> 哪些 release guardrails 可以在 full rollout 前阻止它？

---

## Q107 — Intermittent DNS — 2% Failure

### Q107.1 — 基础定义

> 98% requests 成功，2% 报 `Temporary failure in name resolution`。第一步怎么查？

### Q107.2 — 内部机制

> 哪些 DNS layers 和 retry/caching behaviour 可以产生间歇 failure？

### Q107.3 — 生产场景

> 故障集中在一部分 Kubernetes nodes。什么原因更可能？

### Q107.4 — 故障排查

> 如何检查 CoreDNS、node resolver path、conntrack、packet loss、`ndots` 和 upstream DNS？

### Q107.5 — Senior Trade-off / Edge Case

> 如何提高 resilience，同时避免过度 caching/stale discovery？

---

## Q108 — 一个坏 Kubernetes Node

### Q108.1 — 基础定义

> 只有某个 worker node 上的 Pods 都很慢。怎么办？

### Q108.2 — 内部机制

> 哪些 node-local resources/datapaths 会造成这种问题？

### Q108.3 — 生产场景

> CPU/memory 正常，但所有 Pods 都 network latency 高。下一步？

### Q108.4 — 故障排查

> 如何检查 NIC、CNI、route、MTU、conntrack、kernel logs 和 interrupts？

### Q108.5 — Senior Trade-off / Edge Case

> 什么时候应立即 cordon/drain，什么时候值得继续在线调查？

---

## Q109 — JVM Heap 60%，Container Memory 98%

### Q109.1 — 基础定义

> JVM heap 60%，container memory 98%。有哪些原因？

### Q109.2 — 内部机制

> 拆解 native memory、metaspace、direct buffer、thread stack、code cache、mmap 和 page cache。

### Q109.3 — 生产场景

> GC metrics 正常但 Pod 快 OOM。收集什么 evidence？

### Q109.4 — 故障排查

> 如何结合 NMT、`/proc`、cgroup counters、thread count、direct-buffer usage？

### Q109.5 — Senior Trade-off / Edge Case

> 如何建立 Java-on-Kubernetes memory budget policy？

---

## Q110 — 所有 Services Healthy，但 User Journey 失败

### Q110.1 — 基础定义

> A、B、C 三个 services 都 healthy，但 end-to-end user journey 失败。为什么可能？

### Q110.2 — 内部机制

> 解释 component health 与 interaction health 的区别。

### Q110.3 — 生产场景

> 每个 service health check 都通过，但组合 transaction error。需要什么 evidence？

### Q110.4 — 故障排查

> 如何检查 trace、contract、auth context、state transition 和 timing？

### Q110.5 — Senior Trade-off / Edge Case

> 应加入什么 synthetic/business transaction check？

---

## Q111 — 危险的 Terraform Apply

### Q111.1 — 基础定义

> 接手 terminal 时发现 `terraform apply` 准备 recreate 一个关键 production resource。第一步做什么？

### Q111.2 — 内部机制

> replacement 通常由哪些 Terraform/provider 机制触发？

### Q111.3 — 生产场景

> 如果某 attribute 看起来可以手工改来避免 replacement，应该直接改吗？

### Q111.4 — 故障排查

> 如何安全 stop、保存 plan/state、比较 real infra 并找 recovery path？

### Q111.5 — Senior Trade-off / Edge Case

> 怎样的组织 controls 能让 accidental destructive apply 极难发生？

---

## Q112 — Database Connection Exhaustion Hands-on

### Q112.1 — 基础定义

> DB CPU 30%、connections 100%、app latency 15 秒。第一 hypothesis 是什么？

### Q112.2 — 内部机制

> 为什么 pool exhaustion/queueing 可以发生而 DB CPU 不高？

### Q112.3 — 生产场景

> 一旦拿到 connection，queries 都很快。哪些 application behaviours 更可疑？

### Q112.4 — 故障排查

> 如何检查 pool wait、leak/long-held connections、transactions、thread dumps 和 replica count？

### Q112.5 — Senior Trade-off / Edge Case

> 哪些 pool sizing、timeout、leak detection 和 backpressure policy 可以防止 cascade？

---

# 15 — SRE Scripting 与 Operational Coding

## Q113 — Bash 执行模型与安全 Shell 设置

### Q113.1 — 基础定义

> Bash 中 exit code、`set -e`、`set -u`、`set -o pipefail` 分别做什么？

### Q113.2 — 内部机制

> 为什么 `set -e` 在 conditionals、pipelines、subshells 和 command substitutions 中仍可能出现反直觉行为？

### Q113.3 — 生产场景

> 你接手一个 deployment script，某个命令失败后脚本仍然静默继续。如何让 failure handling 更明确、更可观测？

### Q113.4 — 故障排查

> 一个 Bash script 本地正常，但 CI 中偶发提前退出。你会如何 debug？

### Q113.5 — Senior Trade-off / Edge Case

> 哪些 shell scripting practices 值得标准化？什么时候应该停止用 Bash，改用通用编程语言？

---

## Q114 — grep / awk / sed / jq / xargs 流式处理

### Q114.1 — 基础定义

> 在 SRE workflow 中，什么时候分别使用 `grep`、`awk`、`sed`、`jq` 和 `xargs`？

### Q114.2 — 内部机制

> 为什么 Unix pipeline 可以处理大文件而不一次性加载到内存？哪些地方仍可能因为 buffering 出问题？

### Q114.3 — 生产场景

> 有一个 50GB log file，需要找出 error 最多的 endpoints，同时不能 OOM。你怎么做？

### Q114.4 — 故障排查

> 一个 pipeline 遇到包含空格、换行或特殊字符的 filename 就坏了，怎么修？

### Q114.5 — Senior Trade-off / Edge Case

> 复杂 one-liner 与小型 tested script 在 correctness 和 maintainability 上怎么取舍？

---

## Q115 — Process、Signal、Pipe 与 Subprocess 控制

### Q115.1 — 基础定义

> Unix shell 中 foreground jobs、background jobs、pipes、process groups 和 signals 是什么关系？

### Q115.2 — 内部机制

> pipeline 中一个 process 提前退出，而另一个还在写，会发生什么？

### Q115.3 — 生产场景

> automation script 在 deployment 中被 terminate，但它启动的 child processes 还在运行，会有什么风险？

### Q115.4 — 故障排查

> 一个 subprocess 看起来 hang，但 parent 仍正常运行。怎么诊断？

### Q115.5 — Senior Trade-off / Edge Case

> production automation 应如何管理 cancellation、timeouts、cleanup 和 process ownership？

---

## Q116 — 可靠 SRE Automation：Retry、Timeout、Locking、Idempotency

### Q116.1 — 基础定义

> 什么特征让一个 operational script 可以安全 rerun？

### Q116.2 — 内部机制

> retry、timeout、jitter 和 idempotency 在 automation 中如何互相作用？

### Q116.3 — 生产场景

> 同一个 maintenance job 可能并发运行两个实例，如何避免 unsafe overlap？

### Q116.4 — 故障排查

> 脚本调用 cloud API 后 timeout，但不知道 remote operation 是否成功。怎么安全恢复？

### Q116.5 — Senior Trade-off / Edge Case

> production-grade automation 与 throwaway script 的核心区别是什么？

---

## Q117 — Operational Coding 的数据结构与复杂度

### Q117.1 — 基础定义

> SRE 在 coding interview 和 automation 中至少应熟悉哪些基础数据结构？

### Q117.2 — 内部机制

> time/space complexity 如何影响处理百万级 records 的 operational tool？

### Q117.3 — 生产场景

> 需要找出 error 最多的 top 100 hosts，你会选择什么数据结构？

### Q117.4 — 故障排查

> 脚本从 1 万 records 扩到 1000 万后突然很慢，如何判断是不是 algorithmic complexity？

### Q117.5 — Senior Trade-off / Edge Case

> 什么时候理论上更优的 algorithm 反而不是 production 最佳选择？

---

## Q118 — 超大文件 Streaming 与 OOM 避免

### Q118.1 — 基础定义

> 如何处理比可用内存更大的文件？

### Q118.2 — 内部机制

> streaming、memory mapping 和一次性 load 整个 file 有什么区别？

### Q118.3 — 生产场景

> 要解析 200GB newline-delimited JSON 并统计每日 errors，怎么设计？

### Q118.4 — 故障排查

> 程序明明是 streaming，但运行几小时后 memory 仍缓慢增长。查什么？

### Q118.5 — Senior Trade-off / Edge Case

> 如何让任务失败后可以 resume，而不是从头重跑？

---

## Q119 — 可靠的 HTTP API Client

### Q119.1 — 基础定义

> production SRE HTTP client 除了“能调用接口”之外还应该处理什么？

### Q119.2 — 内部机制

> connect timeout、read timeout、total deadline、retry、connection pooling 有什么区别？

### Q119.3 — 生产场景

> automation client 面对 rate-limited API，应如何处理 429 和 transient 5xx？

### Q119.4 — 故障排查

> client 在 timeout 后偶尔创建 duplicate resources，如何诊断并修复？

### Q119.5 — Senior Trade-off / Edge Case

> 如何安全管理 credentials，并让 client 可观测但不泄露 secrets？

---

## Q120 — Worker Pool、Rate Limit 与 Backpressure

### Q120.1 — 基础定义

> 为什么 bounded worker pool 通常比每个 task 创建一个 thread/process 更安全？

### Q120.2 — 内部机制

> concurrency limiting、rate limiting 和 backpressure 有什么区别？

### Q120.3 — 生产场景

> maintenance tool 的处理速度快于 downstream API 限制，worker model 怎么设计？

### Q120.4 — 故障排查

> queue 长度持续增长，但 workers 看起来健康。如何决定 scale、throttle producers 还是 shed work？

### Q120.5 — Senior Trade-off / Edge Case

> 给 worker pool 加 retry 后会出现哪些 failure modes？

---

## Q121 — Operational CLI 的 Testing 与 UX

### Q121.1 — 基础定义

> 如何组织一个小型 production CLI，使其容易测试？

### Q121.2 — 内部机制

> 哪些部分适合 unit test，哪些适合 integration test？

### Q121.3 — 生产场景

> CLI 在 mocks 下通过，但真实 cloud API 失败，说明什么？

### Q121.4 — 故障排查

> 如何测试 timeout、partial success、retry、SIGTERM 和 duplicate execution？

### Q121.5 — Senior Trade-off / Edge Case

> 危险 operations CLI 应具备哪些 human-safety UX？

---

# 16 — CI/CD 与 Release Engineering

## Q122 — GitHub Actions Workflow、Jobs、Runners 与 Dependencies

### Q122.1 — 基础定义

> 解释 GitHub Actions workflow 的 execution model：events、jobs、steps、runners 和 artifacts。

### Q122.2 — 内部机制

> job dependencies、matrix、cache、artifact 和 reusable workflow 分别有什么作用？

### Q122.3 — 生产场景

> workflow 是 green，但部署 artifact 不是 review 的那个 commit。可能发生了什么？

### Q122.4 — 故障排查

> self-hosted runner 偶尔残留 state 污染后续 builds。怎么调查和缓解？

### Q122.5 — Senior Trade-off / Edge Case

> production delivery system 中什么时候选 hosted runners，什么时候选 self-hosted runners？

---

## Q123 — GitHub Actions Permissions、OIDC、Secrets 与 Deployment Concurrency

### Q123.1 — 基础定义

> `GITHUB_TOKEN` permissions 和 workflow/repository 权限应该如何设计？

### Q123.2 — 内部机制

> 为什么 OIDC federation 通常比 CI 中长期 cloud access keys 更安全？

### Q123.3 — 生产场景

> 一个 PR workflow 可以执行不可信代码，同时读取 production secrets。问题是什么？

### Q123.4 — 故障排查

> 两个 production deployment workflows 并发运行发生 race，如何防止？

### Q123.5 — Senior Trade-off / Edge Case

> 对 production environments、approvals、secrets 和 third-party actions 应加什么 controls？

---

## Q124 — Jenkins Controller、Agents 与 Pipeline Failure

### Q124.1 — 基础定义

> 解释 Jenkins controller/agent 架构，以及 Pipeline 的作用。

### Q124.2 — 内部机制

> long-lived Jenkins agents 有哪些 reliability/security risks？

### Q124.3 — 生产场景

> agent 在 deployment 中途挂掉，如何判断是否可以 safe retry？

### Q124.4 — 故障排查

> Jenkins queue 越来越长，但部分 agents idle。怎么调查？

### Q124.5 — Senior Trade-off / Edge Case

> 如何逐步现代化脆弱 Jenkins 系统，而不是 big-bang migration？

---

## Q125 — Artifact Provenance、Reproducible Build 与 Deployment Race

### Q125.1 — 基础定义

> 什么叫 build once, promote the same artifact？为什么重要？

### Q125.2 — 内部机制

> artifact provenance 是什么？什么让 build 更 reproducible？

### Q125.3 — 生产场景

> staging 与 production 都从同一个 Git tag rebuild，但得到不同 binaries。原因可能是什么？

### Q125.4 — 故障排查

> version label 显示 commit A，但 binary 行为像 commit B。如何调查？

### Q125.5 — Senior Trade-off / Edge Case

> artifact promotion 到 production 前应有哪些 supply-chain/release controls？

---

# 17 — Security / PCI / Software Supply Chain

## Q126 — PCI DSS Scope 与 Cardholder Data Boundary

### Q126.1 — 基础定义

> 高层来看，哪些因素决定一个系统是否进入 PCI DSS scope？

### Q126.2 — 内部机制

> PAN、cardholder data、sensitive authentication data 和 payment token 有什么区别？

### Q126.3 — 生产场景

> 你的应用从不存 PAN，但可以影响处理 PAN 的系统安全。它是否仍可能 in scope？

### Q126.4 — 故障排查

> 在 application logs 中发现敏感 payment data，立即优先做什么？

### Q126.5 — Senior Trade-off / Edge Case

> 如何通过 architecture 缩小 PCI scope，同时不牺牲 reliability 与 observability？

---

## Q127 — Authentication、Authorization、IAM 与 Least Privilege

### Q127.1 — 基础定义

> authentication 与 authorization 有什么区别？

### Q127.2 — 内部机制

> RBAC、ABAC、service identity 和 least privilege 如何关联？

### Q127.3 — 生产场景

> 应用 role 因历史 IAM 问题直接用了 `AdministratorAccess`。你会怎么处理？

### Q127.4 — 故障排查

> 如何调查跨 CI、cloud IAM、Kubernetes 的 privilege escalation path？

### Q127.5 — Senior Trade-off / Edge Case

> 事故中如何兼顾 least privilege 与 operational usability？

---

## Q128 — Secrets、KMS、Encryption 与 Rotation

### Q128.1 — 基础定义

> encryption at rest、encryption in transit 和 secret management 有什么区别？

### Q128.2 — 内部机制

> 高层解释 KMS-style envelope encryption。

### Q128.3 — 生产场景

> 一个 database password 被 commit 到 Git 且已经用于 production。下一步？

### Q128.4 — 故障排查

> 如何给数千 application instances rotate secret 而不 outage？

### Q128.5 — Senior Trade-off / Edge Case

> workload 什么时候应该用 long-lived secret，什么时候优先 short-lived identity credentials？

---

## Q129 — Network Security、TLS、mTLS 与 Segmentation

### Q129.1 — 基础定义

> TLS 提供哪些 security properties？它本身不能解决什么？

### Q129.2 — 内部机制

> mTLS 比普通 server-authenticated TLS 多了什么 guarantee？

### Q129.3 — 生产场景

> 团队认为 private network 足够安全，因此建议 service-to-service 明文。你怎么评估？

### Q129.4 — 故障排查

> certificate rotation 导致 mTLS outage，怎么诊断？

### Q129.5 — Senior Trade-off / Edge Case

> network segmentation 如何减少 blast radius，同时避免变得不可运维？

---

## Q130 — Software Supply Chain 与 Vulnerability Management

### Q130.1 — 基础定义

> CI/CD pipeline 的主要 software supply-chain risks 有哪些？

### Q130.2 — 内部机制

> 按 version pin dependency 与按 immutable digest/commit pin 有什么区别？

### Q130.3 — 生产场景

> 数百 services 使用的 base image 出现 critical vulnerability，怎么响应？

### Q130.4 — 故障排查

> 如何判断 vulnerability 需要 emergency patch 还是 normal remediation？

### Q130.5 — Senior Trade-off / Edge Case

> 哪些 controls 可以降低恶意/被攻陷 dependency 进入 production 的风险？

---

## Q131 — Audit Logs、PII、Patching 与 Security Evidence

### Q131.1 — 基础定义

> audit log 与普通 application debug log 有什么区别？

### Q131.2 — 内部机制

> PII 和敏感字段在 observability data 中应如何处理？

### Q131.3 — 生产场景

> production privileged change 没有可靠 audit trail，为什么既是 compliance problem，也是 operational problem？

### Q131.4 — 故障排查

> 如何低风险 patch security-sensitive production fleet？

### Q131.5 — Senior Trade-off / Edge Case

> security incident 中 evidence preservation 与普通 SRE recovery 目标什么时候会冲突？

---

# 18 — Document Database / NoSQL

## Q132 — Document Database Data Modelling、Index 与 Query

### Q132.1 — 基础定义

> document-oriented data modelling 与 normalized relational modelling 有什么区别？

### Q132.2 — 内部机制

> 什么时候应该 embed related data，什么时候单独 reference？

### Q132.3 — 生产场景

> collection 增长后 document DB query 越来越慢。检查什么？

### Q132.4 — 故障排查

> 为什么 index 可以让某个 query 更快，却让整体 workload 变差？

### Q132.5 — Senior Trade-off / Edge Case

> 新服务什么时候选择 document database，而不是 PostgreSQL？

---

## Q133 — Document DB Replication、Consistency 与 Failover

### Q133.1 — 基础定义

> replica set 或 replicated document DB cluster 主要想提供什么能力？

### Q133.2 — 内部机制

> primary/leader reads/writes、replicas、replication lag 和 consistency 怎么互相影响？

### Q133.3 — 生产场景

> failover 后 client 暂时看到 stale data 或 write errors，为什么？

### Q133.4 — 故障排查

> replication lag 持续增长怎么调查？

### Q133.5 — Senior Trade-off / Edge Case

> payment-adjacent critical state 与 non-critical metadata 应如何选择 read/write consistency？

---

## Q134 — Document DB Sharding、Hot Partition、Schema Evolution 与 Backup

### Q134.1 — 基础定义

> 为什么 document DB 要 sharding？什么是好 shard/partition key？

### Q134.2 — 内部机制

> 什么是 hot partition？错误 shard key 如何制造它？

### Q134.3 — 生产场景

> traffic 增长后只有一个 shard saturation，其他都 idle。怎么诊断？

### Q134.4 — 故障排查

> old/new application versions 同时运行时，document schema 如何演进？

### Q134.5 — Senior Trade-off / Edge Case

> 怎样测试才能真正信任 document DB backup/restore？

---

# 19 — Architecture / Technical Leadership

## Q135 — End-to-End System Architecture Reasoning

### Q135.1 — 基础定义

> review production architecture 时，除了 components 能连通，还应该看哪些维度？

### Q135.2 — 内部机制

> 如何发现 distributed cloud system 中隐藏的 single points of failure？

### Q135.3 — 生产场景

> compute layer 很 HA，但依赖单 region DB 和一个 external API。你会怎么挑战这个设计？

### Q135.4 — 故障排查

> 上线前如何验证 architecture 的 failure assumptions？

### Q135.5 — Senior Trade-off / Edge Case

> 如何平衡 availability、consistency、latency、security、cost 和 operational complexity？

---

## Q136 — ADR、Architecture Trade-off、Cost 与 Business Impact

### Q136.1 — 基础定义

> 一个好的 Architecture Decision Record 应包含什么？

### Q136.2 — 内部机制

> decision reversibility 应如何影响架构决策过程？

### Q136.3 — 生产场景

> 两个设计都满足 SLO，其中一个贵一倍但更容易运维。怎么比较？

### Q136.4 — 故障排查

> 如何向非技术 stakeholders 解释 reliability investment？

### Q136.5 — Senior Trade-off / Edge Case

> 什么时候 Senior SRE 应接受技术上不那么优雅的设计？

---

## Q137 — Mentoring、Code Review、Influence 与 Technical Leadership

### Q137.1 — 基础定义

> Senior SRE 做 code/infra review 的目标，除了找错误还有什么？

### Q137.2 — 内部机制

> 一个 engineer 反复做高风险 production changes，你如何 mentor？

### Q137.3 — 生产场景

> 你非常不同意 Tech Lead 的 architecture，但项目归他负责。怎么办？

### Q137.4 — 故障排查

> 如何提高 engineering standards，又不把自己变成 bottleneck/gatekeeper？

### Q137.5 — Senior Trade-off / Edge Case

> 面试另一个 Senior SRE 时你会重点看什么？

---

# 20 — API Semantics / GraphQL / Disaster Recovery

## Q138 — HTTP API Semantics：Caching、Pagination、Rate Limit、Idempotency

### Q138.1 — 基础定义

> 可靠 API operation 中，哪些 HTTP method/status semantics 最重要？

### Q138.2 — 内部机制

> cache headers、ETag、conditional request 和 pagination 如何影响 correctness 与 operability？

### Q138.3 — 生产场景

> offset pagination 在数据持续变化时出现 duplicate/missing records，为什么？

### Q138.4 — 故障排查

> 如何设计 rate limiting 与 client behaviour，避免 overload 演化成 retry storm？

### Q138.5 — Senior Trade-off / Edge Case

> create/update API 如何做到对 retry 和 concurrent clients 安全？

---

## Q139 — GraphQL Resolver、N+1、Complexity 与 Security

### Q139.1 — 基础定义

> GraphQL execution 在运维上与固定 REST endpoint 有什么不同？

### Q139.2 — 内部机制

> 什么是 N+1 problem？batching/DataLoader-style pattern 如何解决？

### Q139.3 — 生产场景

> 单个 GraphQL query 导致数千 DB calls 和高 CPU，incident 中怎么先止血？

### Q139.4 — 故障排查

> 如何让 GraphQL 足够 observable，同时避免把 raw query text 作为高 cardinality metric label？

### Q139.5 — Senior Trade-off / Edge Case

> public GraphQL endpoint 应加哪些 security/reliability controls？

---

## Q140 — Disaster Recovery：Backup、Restore、RTO、RPO 与 Failover Drill

### Q140.1 — 基础定义

> RTO 和 RPO 是什么？区别在哪里？

### Q140.2 — 内部机制

> 为什么“有 backup”不等于“有 disaster recovery capability”？

### Q140.3 — 生产场景

> database backup 还在，但 encryption key 和 IAM config 都丢了，意味着什么？

### Q140.4 — 故障排查

> 如何做 realistic DR exercise，同时避免给 production 带来不可接受风险？

### Q140.5 — Senior Trade-off / Edge Case

> 如何选择 active-active、warm standby、pilot light、backup/restore 或更简单 single-region recovery？

---

# Mock Interview 使用规则

- 面试官不要一次显示五题，应该逐层追问。
- Candidate 回答后，再根据回答进入下一层。
- 如果 Candidate 在 `.1` 或 `.2` 已经暴露概念错误，应继续追根究底，而不是快速换题。
- `.4` 要求 hypothesis-driven troubleshooting，不接受只列命令。
- `.5` 重点观察 trade-off、blast radius、failure mode、reversibility 和 operational judgement。

推荐回答结构：

```text
Impact → Scope → Timeline → Hypotheses → Evidence → Mitigation → Root Cause → Prevention
```